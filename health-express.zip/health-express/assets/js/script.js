;(function ($) {
    $.fn.placehold = function (placeholderClassName) {
        var placeholderClassName = placeholderClassName || "placeholder",
			supported = $.fn.placehold.is_supported();

        function toggle() {
            for (i = 0; i < arguments.length; i++) {
                arguments[i].toggle();
            }
        }

        return supported ? this : this.each(function () {
            var $elem = $(this),
				placeholder_attr = $elem.attr("placeholder");

            if (placeholder_attr) {
                if ($elem.val() === "" || $elem.val() == placeholder_attr) {
                    $elem.addClass(placeholderClassName).val(placeholder_attr);
                }

                if ($elem.is(":password")) {
                    var $pwd_shiv = $("<input />", {
                        "class": $elem.attr("class") + " " + placeholderClassName,
                        "value": placeholder_attr
                    });

                    $pwd_shiv.bind("focus.placehold", function () {
                        toggle($elem, $pwd_shiv);
                        $elem.focus();
                    });

                    $elem.bind("blur.placehold", function () {
                        if ($elem.val() === "") {
                            toggle($elem, $pwd_shiv);
                        }
                    });

                    $elem.hide().after($pwd_shiv);
                }

                $elem.bind({
                    "focus.placehold": function () {
                        if ($elem.val() == placeholder_attr) {
                            $elem.removeClass(placeholderClassName).val("");
                        }
                    },
                    "blur.placehold": function () {
                        if ($elem.val() === "") {
                            $elem.addClass(placeholderClassName).val(placeholder_attr);
                        }
                    }
                });

                $elem.closest("form").bind("submit.placehold", function () {
                    if ($elem.val() == placeholder_attr) {
                        $elem.val("");
                    }

                    return true;
                });
            }
        });
    };

    $.fn.placehold.is_supported = function () {
        return "placeholder" in document.createElement("input");
    };
})(jQuery);



$(document).ready(function () {
    var flag = 0;
    $('.searchmain').click(function () {
        $(this).toggleClass('active');
        $('.search-form').animate({ opacity: 'toggle' });
        return false;
    });

    // mobile-navigation
    $('.nav-btn').click(function () {
        $('nav').slideToggle(400);
        $(this).toggleClass('active');
        return false;
    });

    $('.prox').click(function () {
        $(this).toggleClass('active');
        $('.left-nav').toggle(200);
        return false;
    });

    $('.zipcode').click(function () {
        $('.personalized-core').slideToggle(400);
        $(this).toggleClass('active');
        return false;
    });

    $('.ziptext').click(function () {
        $('.personalized-core').slideToggle(400);
        $(this).toggleClass('active');
        return false;
    });

    $(".top-nav li:last-child").addClass('search');
    $(".top-nav li li:last-child").removeClass('search');
    $(".drop section:first-child").addClass('first');
    $(".data-grid tr:even").addClass("odd");

    $(".accordion > div").each(function () { var prev = $(this).prev(); if (prev.is('h3')) { prev.addClass('enabled'); } });
    $(".accordion").accordion({ header: "h3.enabled", autoHeight: false, clearStyle: true, collapsible: true });
    $("footer .accordion").accordion({ active: false, collapsible: true });



    /*Ic_menu();*/
    $(".row:nth-child(odd)").addClass("odd");
    $('.hero-slide').carousel();
    $('.callout-phone a').before("<span>Phone </span>");
    $('.callout-fax a').before("<span>Fax </span>");
    //$('.crsl-items').carousel({ overflow: true, visible: 3, itemMinWidth: 180, itemMargin: 10 });
    $('.crsl-items').carousel({ overflow: true, visible: 3, itemMinWidth: 140, itemMargin: 15 });
    $('.crsl-items2').carousel({ overflow: true, visible: 2, itemMinWidth: 220, itemMargin: 15 });
    $('.crsl-items3').carousel({ overflow: true, visible: 3, itemMinWidth: 180, itemMargin: 15 });
    $('.crsl-items4').carousel({ overflow: true, visible: 4, itemMinWidth: 140, itemMargin: 20 });
    $('.base-container .grid-1-quarter:visible').each(function (i) {
        if (i % 4 == 0) $(this).addClass('first');
    });

    $('.main-content .inner .grid-half:visible').each(function (i) {
        if (i % 2 == 0) $(this).addClass('first');
    });
    $('footer li a').append('&nbsp;&nbsp;&rsaquo;');
    $('.on a').append('&nbsp;&nbsp;&rsaquo;');
    $('.callout .listing-item-more-link a').append('&nbsp;&nbsp;&rsaquo;');
    $('.callout li').append('&nbsp;&nbsp;&rsaquo;');
    $('.read-arrow').append('<span>&rsaquo;</span>');
    $('.plus').append('<span>&#43;</span>');
    $('.arrow').append('&nbsp;&nbsp;&rsaquo;');
    $('.nav-item').wrapInner('<span></span>');
    $(".tip").tooltip({
        track: true,
        delay: 0,
        showURL: false,
        opacity: 1,
        fixPNG: true,
        showBody: " - ",
        extraClass: "pretty fancy",
        top: 0,
        left: 5
    });

    $('.flyout .heading a').on('click', function () {
        var target = $(this).attr('rel');

        $('#' + target).fadeIn(800);
        $('#' + target).show().siblings("div").hide();

        // Added to redirect when link has href and remove hash from URL
        if (target != undefined) { return false; }
        else { return true; }
    });

    $(function stay() {
        $('.flyout .heading a').click(function () {
            $('.flyout .heading a').removeClass('active');
            $(this).addClass('active');
            return true;

        });
    });

    $('body').on('click', '.flyout-mobile .heading a', function () {
        var target = $(this).attr('rel');

        $(this).parents('h3').next('.flyout-content').slideDown().siblings("div").slideUp();
        // Added to redirect when link has href and remove hash from URL
        if (target != undefined) { return false; }
        else { return true; }
    });

    $(function stay() {
        $('body').on('click', '.flyout-mobile .heading a', function () {
            $('.flyout-mobile .heading a').removeClass('active');
            $('.flyout-mobile .heading a').parent('h3').removeClass('ui-state-active');
            $(this).addClass('active');
            return true;

        });
    });

    $(".close").click(function (e) {
        e.preventDefault();
        $(this).parent().fadeOut();
        $('.flyout .heading a, .flyout-mobile .heading a').removeClass('active');
        //$('iframe').attr('src', $('iframe').attr('src'));
        return false;

    });


});

$(function () {
    $(".services-custom ul.mt li a").each(function (index) {
        $(this).attr("href", "#spec" + index.toString());
    });
    $(".services-custom > div").each(function (index) {
        $(this).attr("id", "spec" + index.toString());
    });
    $(".tabs").tabs();
});


(function ($) {
    $.fn.extend({
        MTtabs: function (options) {
            //Set the default values, use comma to separate the settings, blah blah blah:
            var defaults = {
                type: 'default', //default
                width: 'auto',
                fit: true,
                closed: false,
                activate: function () { }
            }
            //Variables
            var options = $.extend(defaults, options);
            var opt = options, jtype = opt.type, jfit = opt.fit, jwidth = opt.width, vtabs = 'vertical', accord = 'accordion';

            //Events
            $(this).bind('tabactivate', function (e, currentTab) {
                if (typeof options.activate === 'function') {
                    options.activate.call(currentTab, e)
                }
            });

            //Main function
            this.each(function () {
                var $respTabs = $(this);
                var $respTabsList = $respTabs.find('ul.mt-tabs-list');
                $respTabs.find('ul.mt-tabs-list li').addClass('mt-tab-item');
                $respTabs.css({
                    'display': 'block',
                    'width': jwidth
                });

                $respTabs.find('.mt-tabs-container > div').addClass('mt-tab-content');
                jtab_options();
                //Properties Function
                function jtab_options() {
                    if (jtype == vtabs) {
                        $respTabs.addClass('mt-vtabs');
                    }
                    if (jfit == true) {
                        $respTabs.css({ width: '100%', margin: '0px' });
                    }
                    if (jtype == accord) {
                        $respTabs.addClass('mt-htag-accordion');
                        $respTabs.find('.mt-tabs-list').css('display', 'none');
                    }
                }

                //Assigning the h2 markup to accordion title
                var $tabItemh2;
                $respTabs.find('.mt-tab-content').before("<h3 class='mt-accordion' role='tab'><span class='mt-arrow'></span></h3>");

                var itemCount = 0;
                $respTabs.find('.mt-accordion').each(function () {
                    $tabItemh2 = $(this);
                    var innertext = $respTabs.find('.mt-tab-item:eq(' + itemCount + ')').html();
                    $respTabs.find('.mt-accordion:eq(' + itemCount + ')').append(innertext);
                    $tabItemh2.attr('aria-controls', 'tab_item-' + (itemCount));
                    itemCount++;
                });

                //Assigning the 'aria-controls' to Tab items
                var count = 0,
                    $tabContent;
                $respTabs.find('.mt-tab-item').each(function () {
                    $tabItem = $(this);
                    $tabItem.attr('aria-controls', 'tab_item-' + (count));
                    $tabItem.attr('role', 'tab');

                    //First active tab, keep closed if option = 'closed' or option is 'accordion' and the element is in accordion mode 
                    if (options.closed !== true && !(options.closed === 'accordion' && !$respTabsList.is(':visible')) && !(options.closed === 'tabs' && $respTabsList.is(':visible'))) {
                        $respTabs.find('.mt-tab-item').first().addClass('mt-tab-active');
                        $respTabs.find('.mt-accordion').first().addClass('mt-tab-active');
                        $respTabs.find('.mt-tab-content').first().addClass('mt-tab-content-active').attr('style', 'display:block');
                    }

                    //Assigning the 'aria-labelledby' attr to tab-content
                    var tabcount = 0;
                    $respTabs.find('.mt-tab-content').each(function () {
                        $tabContent = $(this);
                        $tabContent.attr('aria-labelledby', 'tab_item-' + (tabcount));
                        tabcount++;
                    });
                    count++;
                });

                //Tab Click action function
                $respTabs.find("[role=tab]").each(function () {
                    var $currentTab = $(this);
                    $currentTab.click(function () {

                        var $tabAria = $currentTab.attr('aria-controls');

                        if ($currentTab.hasClass('mt-accordion') && $currentTab.hasClass('mt-tab-active')) {
                            $respTabs.find('.mt-tab-content-active').slideUp('', function () { $(this).addClass('mt-accordion-closed'); });
                            $currentTab.removeClass('mt-tab-active');
                            return false;
                        }
                        if (!$currentTab.hasClass('mt-tab-active') && $currentTab.hasClass('mt-accordion')) {
                            $respTabs.find('.mt-tab-active').removeClass('mt-tab-active');
                            $respTabs.find('.mt-tab-content-active').slideUp().removeClass('mt-tab-content-active mt-accordion-closed');
                            $respTabs.find("[aria-controls=" + $tabAria + "]").addClass('mt-tab-active');

                            $respTabs.find('.mt-tab-content[aria-labelledby = ' + $tabAria + ']').slideDown().addClass('mt-tab-content-active');
                        } else {
                            $respTabs.find('.mt-tab-active').removeClass('mt-tab-active');
                            $respTabs.find('.mt-tab-content-active').removeAttr('style').removeClass('mt-tab-content-active').removeClass('mt-accordion-closed');
                            $respTabs.find("[aria-controls=" + $tabAria + "]").addClass('mt-tab-active');
                            $respTabs.find('.mt-tab-content[aria-labelledby = ' + $tabAria + ']').addClass('mt-tab-content-active').attr('style', 'display:block');
                        }
                        //Trigger tab activation event
                        $currentTab.trigger('tabactivate', $currentTab);
                    });
                    //Window resize function                   
                    $(window).resize(function () {
                        $respTabs.find('.mt-accordion-closed').removeAttr('style');
                    });
                });
            });
        }
    });
})(jQuery);

$(document).ready(function () {
    // Datepicker
    $('#datepicker').datepicker({
        inline: true
    });
    $("#datepicker").datepicker("option", "dayNamesMin", ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']);

    $(function () {
        $(".dp_input").datepicker({
            inline: true,
            buttonImageOnly: true,
            dateFormat: 'mm/dd/yy',
            showAnim: 'slideDown'
            /*showOn: "button",
            buttonImage: "/assets/default/images/calendar.jpg",*/
        });
    });

});


$(function () {
    $('.tick').each(function () {
        var ticker = $(this);
        var fader = $('<div class="fader">&nbsp;</div>').css({ display: 'inline-block' });
        var links = ticker.find('ul>li');

		 ticker.find('ul').replaceWith(fader);
		
        var counter = 0;
        var curLink;
        var fadeSpeed = 500;
        var showLink = function () {
            var newLinkIndex = (counter++) % links.length;
            var newLink = $(links[newLinkIndex]);
            var fadeInFunction = function () {
                curLink = newLink;
                fader.append(curLink).fadeIn(fadeSpeed);
            };
            if (curLink && (links.length > 1)) {
                fader.fadeOut(fadeSpeed, function () {
                    curLink.remove();
                    setTimeout(fadeInFunction, 0);
                });
            }
            else {
                fadeInFunction();
            }
        };


        var speed = 6000;
        var autoInterval;

        var startTimer = function () {
            autoInterval = setInterval(showLink, speed);
        };
        ticker.hover(function () {
            clearInterval(autoInterval);
        }, startTimer);

        fader.fadeOut(0, function () {
            fader.text('');
            showLink();
        });
        startTimer();

    });
});


function isIE() {
    var myNav = navigator.userAgent.toLowerCase();
    return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
}



$(document).ready(function () {
    var html = $("html");
    if (isIE() == 6) {
        html.addClass("no-js lt-ie9 lt-ie8 lt-ie7");
    } else if (isIE() == 7) {
        html.addClass("no-js lt-ie9 lt-ie8");
    } else if (isIE() == 8) {
        html.addClass("no-js lt-ie9");
    }

    $('a[name=modal]').click(function (e) {
        e.preventDefault();

        var id = $(this).attr('href');

        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        $('.mask').css({ 'width': maskWidth, 'height': maskHeight });

        $('.mask').fadeIn(1000);
        $('.mask').fadeTo("slow", 0.8);

        var winH = $(window).height();
        var winW = $(window).width();

        $(id).css('top', winH / 2 - $(id).height() / 2);
        $(id).css('left', winW / 2 - $(id).width() / 2);

        $(id).fadeIn(2000);
        $('.closetag').show();

    });

    $('.window .close').click(function (e) {
        e.preventDefault();
        $('.mask').hide();
        $('.window').hide();
        $('.closetag').show();
        var url = $('#video0').attr('src');
        $('#video0').attr('src', '');
        $('#video0').attr('src', url);

        var url = $('#video1').attr('src');
        $('#video1').attr('src', '');
        $('#video1').attr('src', url);

        var url = $('#video2').attr('src');
        $('#video2').attr('src', '');
        $('#video2').attr('src', url);

        var url = $('#video3').attr('src');
        $('#video3').attr('src', '');
        $('#video3').attr('src', url);
    });

    $('.mask').click(function () {
        $('.mask').hide();
        $('.window').hide();
        var url = $('#video0').attr('src');
        $('#video0').attr('src', '');
        $('#video0').attr('src', url);

        var url = $('#video1').attr('src');
        $('#video1').attr('src', '');
        $('#video1').attr('src', url);

        var url = $('#video2').attr('src');
        $('#video2').attr('src', '');
        $('#video2').attr('src', url);

        var url = $('#video3').attr('src');
        $('#video3').attr('src', '');
        $('#video3').attr('src', url);

    });

    $(window).resize(function () {

        var box = $('.boxes .window');

        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        $('.mask').css({ 'width': maskWidth, 'height': maskHeight });

        var winH = $(window).height();
        var winW = $(window).width();

        box.css('top', winH / 2 - box.height() / 2);
        box.css('left', winW / 2 - box.width() / 2);

    });

});

(function ($) {
    $.fn.extend({

        customSelect: function (options) {
            if (!$.browser.msie || ($.browser.msie && $.browser.version > 6)) {
                return this.each(function () {

                    var currentSelected = $(this).find(':selected');
                    var html = currentSelected.html();
                    if (!html) { html = '&nbsp;'; }
                    $(this).after('<span class="customStyleSelectBox"><span class="customStyleSelectBoxInner">' + html + '</span></span>').css({ position: 'absolute', opacity: 0, fontSize: $(this).next().css('font-size') });
                    var selectBoxSpan = $(this).next();

                    var selectBoxSpanInner = selectBoxSpan.find(':first-child');
                    selectBoxSpan.css({ display: 'inline-block' });
                    selectBoxSpanInner.css({ display: 'inline-block' });
                    var selectBoxHeight = parseInt(selectBoxSpan.height()) + parseInt(selectBoxSpan.css('padding-top')) + parseInt(selectBoxSpan.css('padding-bottom'));
                    $(this).height(selectBoxHeight).change(function () {
                        // selectBoxSpanInner.text($(this).val()).parent().addClass('changed');   This was not ideal
                        selectBoxSpanInner.text($(this).find(':selected').text()).parent().addClass('changed');
                    });

                });
            }
        }
    });
})(jQuery);

$(function () {
    $('select.styled').customSelect();
    $('select.scfDropList').customSelect();
    $('select.ddlSendTo').customSelect();
    $('select.scfPaymentMethod').customSelect();
    $('select.scfDateSelectorDay').customSelect();
    $('select.scfDateSelectorMonth').customSelect();
    $('select.scfDateSelectorYear').customSelect();
});

$(document).ready(function () {


    var currentTallest = 0,
     currentRowStart = 0,
     rowDivs = new Array(),
     $el,
     topPosition = 0;

    $('.blocks').each(function () {

        $el = $(this);
        topPostion = $el.position().top;

        if (currentRowStart != topPostion) {

            // we just came to a new row.  Set all the heights on the completed row
            for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                rowDivs[currentDiv].height(currentTallest);
            }

            // set the variables for the new row
            rowDivs.length = 0; // empty the array
            currentRowStart = topPostion;
            currentTallest = $el.height();
            rowDivs.push($el);

        } else {

            // another div on the current row.  Add it to the list and check if it's taller
            rowDivs.push($el);
            currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);

        }

        // do the last row
        for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
            rowDivs[currentDiv].height(currentTallest);
        }

    });

});

//** Start Module
// Reset Fields either textbox or dropdown
function ResetField(field) {
    if (field.is('input:text')) {
        $(field).val('');
    } else if (field.is('select')) {
        // This is the only selection changed that worked!!
        $(field[0]).val("").change();
    }
}
//** Ends Module


$(document).ready(function () {
    RESPONSIVEUI.responsiveTabs();

    $('.open-tab').click(function () {
        $('.responsive-tabs__list__item:contains("Care Locations")').trigger('click');
        return false;
    });

    $($('.location-contact-us').html()).appendTo('.location-contact-us-move');
    $($('.flyout-mobile').html()).appendTo('.flyout-mobile-move');
    if ($('.flyout-mobile-move .mt-box').children().length == 0) { $('.flyout-mobile-move').addClass('empty') }

    $('.alphalist').on('click', function () {
        var whereTo = $(this).attr('goto');
        $tabs = $(".mt li");
        $tabs.find('a[href=#' + whereTo + ']').trigger('click');
        $('html, body').animate({
            scrollTop: $('#' + whereTo + ' a').offset().top
        });
    });

    $(".header-mobile").click(function () {
        $(this).toggleClass('active');
        $(this).parent().children(".location-contact-us-move .inner").slideToggle();
        return false;
    });
});


$(function () {
    if (navigator.userAgent.match(/iPad/i)) {
        viewport = document.querySelector("meta[name=viewport]");
        viewport.setAttribute('content', 'width=1024');
    }
});

; (function ($) {
    var helper = {}, current, title, tID, IE = $.browser.msie && /MSIE\s(5\.5|6\.)/.test(navigator.userAgent), track = false; $.tooltip = { blocked: false, defaults: { delay: 200, fade: false, showURL: true, extraClass: "", top: 15, left: 15, id: "tooltip" }, block: function () { $.tooltip.blocked = !$.tooltip.blocked; } }; $.fn.extend({ tooltip: function (settings) { settings = $.extend({}, $.tooltip.defaults, settings); createHelper(settings); return this.each(function () { $.data(this, "tooltip", settings); this.tOpacity = helper.parent.css("opacity"); this.tooltipText = this.title; $(this).removeAttr("title"); this.alt = ""; }).mouseover(save).mouseout(hide).click(hide); }, fixPNG: IE ? function () { return this.each(function () { var image = $(this).css('backgroundImage'); if (image.match(/^url\(["']?(.*\.png)["']?\)$/i)) { image = RegExp.$1; $(this).css({ 'backgroundImage': 'none', 'filter': "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=crop, src='" + image + "')" }).each(function () { var position = $(this).css('position'); if (position != 'absolute' && position != 'relative') $(this).css('position', 'relative'); }); } }); } : function () { return this; }, unfixPNG: IE ? function () { return this.each(function () { $(this).css({ 'filter': '', backgroundImage: '' }); }); } : function () { return this; }, hideWhenEmpty: function () { return this.each(function () { $(this)[$(this).html() ? "show" : "hide"](); }); }, url: function () { return this.attr('href') || this.attr('src'); } }); function createHelper(settings) { if (helper.parent) return; helper.parent = $('<div id="' + settings.id + '"><h3></h3><div class="body"></div><div class="url"></div></div>').appendTo(document.body).hide(); if ($.fn.bgiframe) helper.parent.bgiframe(); helper.title = $('h3', helper.parent); helper.body = $('div.body', helper.parent); helper.url = $('div.url', helper.parent); } function settings(element) { return $.data(element, "tooltip"); } function handle(event) {
        if (settings(this).delay) tID = setTimeout(show, settings(this).delay); else
            show(); track = !!settings(this).track; $(document.body).bind('mousemove', update); update(event);
    } function save() {
        if ($.tooltip.blocked || this == current || (!this.tooltipText && !settings(this).bodyHandler)) return; current = this; title = this.tooltipText; if (settings(this).bodyHandler) { helper.title.hide(); var bodyContent = settings(this).bodyHandler.call(this); if (bodyContent.nodeType || bodyContent.jquery) { helper.body.empty().append(bodyContent) } else { helper.body.html(bodyContent); } helper.body.show(); } else if (settings(this).showBody) { var parts = title.split(settings(this).showBody); helper.title.html(parts.shift()).show(); helper.body.empty(); for (var i = 0, part; (part = parts[i]); i++) { if (i > 0) helper.body.append("<br/>"); helper.body.append(part); } helper.body.hideWhenEmpty(); } else { helper.title.html(title).show(); helper.body.hide(); } if (settings(this).showURL && $(this).url()) helper.url.html($(this).url().replace('http://', '')).show(); else
            helper.url.hide(); helper.parent.addClass(settings(this).extraClass); if (settings(this).fixPNG) helper.parent.fixPNG(); handle.apply(this, arguments);
    } function show() {
        tID = null; if ((!IE || !$.fn.bgiframe) && settings(current).fade) {
            if (helper.parent.is(":animated")) helper.parent.stop().show().fadeTo(settings(current).fade, current.tOpacity); else
                helper.parent.is(':visible') ? helper.parent.fadeTo(settings(current).fade, current.tOpacity) : helper.parent.fadeIn(settings(current).fade);
        } else { helper.parent.show(); } update();
    } function update(event) { if ($.tooltip.blocked) return; if (event && event.target.tagName == "OPTION") { return; } if (!track && helper.parent.is(":visible")) { $(document.body).unbind('mousemove', update) } if (current == null) { $(document.body).unbind('mousemove', update); return; } helper.parent.removeClass("viewport-right").removeClass("viewport-bottom"); var left = helper.parent[0].offsetLeft; var top = helper.parent[0].offsetTop; if (event) { left = event.pageX + settings(current).left; top = event.pageY + settings(current).top; var right = 'auto'; if (settings(current).positionLeft) { right = $(window).width() - left; left = 'auto'; } helper.parent.css({ left: left, right: right, top: top }); } var v = viewport(), h = helper.parent[0]; if (v.x + v.cx < h.offsetLeft + h.offsetWidth) { left -= h.offsetWidth + 20 + settings(current).left; helper.parent.css({ left: left + 'px' }).addClass("viewport-right"); } if (v.y + v.cy < h.offsetTop + h.offsetHeight) { top -= h.offsetHeight + 20 + settings(current).top; helper.parent.css({ top: top + 'px' }).addClass("viewport-bottom"); } } function viewport() { return { x: $(window).scrollLeft(), y: $(window).scrollTop(), cx: $(window).width(), cy: $(window).height() }; } function hide(event) {
        if ($.tooltip.blocked) return; if (tID) clearTimeout(tID); current = null; var tsettings = settings(this); function complete() { helper.parent.removeClass(tsettings.extraClass).hide().css("opacity", ""); } if ((!IE || !$.fn.bgiframe) && tsettings.fade) {
            if (helper.parent.is(':animated')) helper.parent.stop().fadeTo(tsettings.fade, 0, complete); else
                helper.parent.stop().fadeOut(tsettings.fade, complete);
        } else
            complete(); if (settings(this).fixPNG) helper.parent.unfixPNG();
    }
})(jQuery);



(function (e) { e.mtslider = function (t, n) { var r = e(t); r.vars = e.extend({}, e.mtslider.defaults, n); var i = r.vars.namespace, s = window.navigator && window.navigator.msPointerEnabled && window.MSGesture, o = ("ontouchstart" in window || s || window.DocumentTouch && document instanceof DocumentTouch) && r.vars.touch, u = "click touchend MSPointerUp", a = "", f, l = r.vars.direction === "vertical", c = r.vars.reverse, h = r.vars.itemWidth > 0, p = r.vars.animation === "fade", d = r.vars.asNavFor !== "", v = {}, m = !0; e.data(t, "mtslider", r); v = { init: function () { r.animating = !1; r.currentSlide = parseInt(r.vars.startAt ? r.vars.startAt : 0); isNaN(r.currentSlide) && (r.currentSlide = 0); r.animatingTo = r.currentSlide; r.atEnd = r.currentSlide === 0 || r.currentSlide === r.last; r.containerSelector = r.vars.selector.substr(0, r.vars.selector.search(" ")); r.slides = e(r.vars.selector, r); r.container = e(r.containerSelector, r); r.count = r.slides.length; r.syncExists = e(r.vars.sync).length > 0; r.vars.animation === "slide" && (r.vars.animation = "swing"); r.prop = l ? "top" : "marginLeft"; r.args = {}; r.manualPause = !1; r.stopped = !1; r.started = !1; r.startTimeout = null; r.transitions = !r.vars.video && !p && r.vars.useCSS && function () { var e = document.createElement("div"), t = ["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"]; for (var n in t) if (e.style[t[n]] !== undefined) { r.pfx = t[n].replace("Perspective", "").toLowerCase(); r.prop = "-" + r.pfx + "-transform"; return !0 } return !1 } (); r.vars.controlsContainer !== "" && (r.controlsContainer = e(r.vars.controlsContainer).length > 0 && e(r.vars.controlsContainer)); r.vars.manualControls !== "" && (r.manualControls = e(r.vars.manualControls).length > 0 && e(r.vars.manualControls)); if (r.vars.randomize) { r.slides.sort(function () { return Math.round(Math.random()) - .5 }); r.container.empty().append(r.slides) } r.doMath(); r.setup("init"); r.vars.controlNav && v.controlNav.setup(); r.vars.directionNav && v.directionNav.setup(); r.vars.keyboard && (e(r.containerSelector).length === 1 || r.vars.multipleKeyboard) && e(document).bind("keyup", function (e) { var t = e.keyCode; if (!r.animating && (t === 39 || t === 37)) { var n = t === 39 ? r.getTarget("next") : t === 37 ? r.getTarget("prev") : !1; r.mtAnimate(n, r.vars.pauseOnAction) } }); r.vars.mousewheel && r.bind("mousewheel", function (e, t, n, i) { e.preventDefault(); var s = t < 0 ? r.getTarget("next") : r.getTarget("prev"); r.mtAnimate(s, r.vars.pauseOnAction) }); r.vars.pausePlay && v.pausePlay.setup(); r.vars.slideshow && r.vars.pauseInvisible && v.pauseInvisible.init(); if (r.vars.slideshow) { r.vars.pauseOnHover && r.hover(function () { !r.manualPlay && !r.manualPause && r.pause() }, function () { !r.manualPause && !r.manualPlay && !r.stopped && r.play() }); if (!r.vars.pauseInvisible || !v.pauseInvisible.isHidden()) r.vars.initDelay > 0 ? r.startTimeout = setTimeout(r.play, r.vars.initDelay) : r.play() } d && v.asNav.setup(); o && r.vars.touch && v.touch(); (!p || p && r.vars.smoothHeight) && e(window).bind("resize orientationchange focus", v.resize); r.find("img").attr("draggable", "false"); setTimeout(function () { r.vars.start(r) }, 200) }, asNav: { setup: function () { r.asNav = !0; r.animatingTo = Math.floor(r.currentSlide / r.move); r.currentItem = r.currentSlide; r.slides.removeClass(i + "active-slide").eq(r.currentItem).addClass(i + "active-slide"); if (!s) r.slides.click(function (t) { t.preventDefault(); var n = e(this), s = n.index(), o = n.offset().left - e(r).scrollLeft(); if (o <= 0 && n.hasClass(i + "active-slide")) r.mtAnimate(r.getTarget("prev"), !0); else if (!e(r.vars.asNavFor).data("mtslider").animating && !n.hasClass(i + "active-slide")) { r.direction = r.currentItem < s ? "next" : "prev"; r.mtAnimate(s, r.vars.pauseOnAction, !1, !0, !0) } }); else { t._slider = r; r.slides.each(function () { var t = this; t._gesture = new MSGesture; t._gesture.target = t; t.addEventListener("MSPointerDown", function (e) { e.preventDefault(); e.currentTarget._gesture && e.currentTarget._gesture.addPointer(e.pointerId) }, !1); t.addEventListener("MSGestureTap", function (t) { t.preventDefault(); var n = e(this), i = n.index(); if (!e(r.vars.asNavFor).data("mtslider").animating && !n.hasClass("active")) { r.direction = r.currentItem < i ? "next" : "prev"; r.mtAnimate(i, r.vars.pauseOnAction, !1, !0, !0) } }) }) } } }, controlNav: { setup: function () { r.manualControls ? v.controlNav.setupManual() : v.controlNav.setupPaging() }, setupPaging: function () { var t = r.vars.controlNav === "thumbnails" ? "control-thumbs" : "control-paging", n = 1, s, o; r.controlNavScaffold = e('<ol class="' + i + "control-nav " + i + t + '"></ol>'); if (r.pagingCount > 1) for (var f = 0; f < r.pagingCount; f++) { o = r.slides.eq(f); s = r.vars.controlNav === "thumbnails" ? '<img src="' + o.attr("data-thumb") + '"/>' : "<a>" + n + "</a>"; if ("thumbnails" === r.vars.controlNav && !0 === r.vars.thumbCaptions) { var l = o.attr("data-thumbcaption"); "" != l && undefined != l && (s += '<span class="' + i + 'caption">' + l + "</span>") } r.controlNavScaffold.append("<li>" + s + "</li>"); n++ } r.controlsContainer ? e(r.controlsContainer).append(r.controlNavScaffold) : r.append(r.controlNavScaffold); v.controlNav.set(); v.controlNav.active(); r.controlNavScaffold.delegate("a, img", u, function (t) { t.preventDefault(); if (a === "" || a === t.type) { var n = e(this), s = r.controlNav.index(n); if (!n.hasClass(i + "active")) { r.direction = s > r.currentSlide ? "next" : "prev"; r.mtAnimate(s, r.vars.pauseOnAction) } } a === "" && (a = t.type); v.setToClearWatchedEvent() }) }, setupManual: function () { r.controlNav = r.manualControls; v.controlNav.active(); r.controlNav.bind(u, function (t) { t.preventDefault(); if (a === "" || a === t.type) { var n = e(this), s = r.controlNav.index(n); if (!n.hasClass(i + "active")) { s > r.currentSlide ? r.direction = "next" : r.direction = "prev"; r.mtAnimate(s, r.vars.pauseOnAction) } } a === "" && (a = t.type); v.setToClearWatchedEvent() }) }, set: function () { var t = r.vars.controlNav === "thumbnails" ? "img" : "a"; r.controlNav = e("." + i + "control-nav li " + t, r.controlsContainer ? r.controlsContainer : r) }, active: function () { r.controlNav.removeClass(i + "active").eq(r.animatingTo).addClass(i + "active") }, update: function (t, n) { r.pagingCount > 1 && t === "add" ? r.controlNavScaffold.append(e("<li><a>" + r.count + "</a></li>")) : r.pagingCount === 1 ? r.controlNavScaffold.find("li").remove() : r.controlNav.eq(n).closest("li").remove(); v.controlNav.set(); r.pagingCount > 1 && r.pagingCount !== r.controlNav.length ? r.update(n, t) : v.controlNav.active() } }, directionNav: { setup: function () { var t = e('<ul class="' + i + 'direction-nav"><li><a class="' + i + 'prev" href="#">' + r.vars.prevText + '</a></li><li><a class="' + i + 'next" href="#">' + r.vars.nextText + "</a></li></ul>"); if (r.controlsContainer) { e(r.controlsContainer).append(t); r.directionNav = e("." + i + "direction-nav li a", r.controlsContainer) } else { r.append(t); r.directionNav = e("." + i + "direction-nav li a", r) } v.directionNav.update(); r.directionNav.bind(u, function (t) { t.preventDefault(); var n; if (a === "" || a === t.type) { n = e(this).hasClass(i + "next") ? r.getTarget("next") : r.getTarget("prev"); r.mtAnimate(n, r.vars.pauseOnAction) } a === "" && (a = t.type); v.setToClearWatchedEvent() }) }, update: function () { var e = i + "disabled"; r.pagingCount === 1 ? r.directionNav.addClass(e).attr("tabindex", "-1") : r.vars.animationLoop ? r.directionNav.removeClass(e).removeAttr("tabindex") : r.animatingTo === 0 ? r.directionNav.removeClass(e).filter("." + i + "prev").addClass(e).attr("tabindex", "-1") : r.animatingTo === r.last ? r.directionNav.removeClass(e).filter("." + i + "next").addClass(e).attr("tabindex", "-1") : r.directionNav.removeClass(e).removeAttr("tabindex") } }, pausePlay: { setup: function () { var t = e('<div class="' + i + 'pauseplay"><a></a></div>'); if (r.controlsContainer) { r.controlsContainer.append(t); r.pausePlay = e("." + i + "pauseplay a", r.controlsContainer) } else { r.append(t); r.pausePlay = e("." + i + "pauseplay a", r) } v.pausePlay.update(r.vars.slideshow ? i + "pause" : i + "play"); r.pausePlay.bind(u, function (t) { t.preventDefault(); if (a === "" || a === t.type) if (e(this).hasClass(i + "pause")) { r.manualPause = !0; r.manualPlay = !1; r.pause() } else { r.manualPause = !1; r.manualPlay = !0; r.play() } a === "" && (a = t.type); v.setToClearWatchedEvent() }) }, update: function (e) { e === "play" ? r.pausePlay.removeClass(i + "pause").addClass(i + "play").html(r.vars.playText) : r.pausePlay.removeClass(i + "play").addClass(i + "pause").html(r.vars.pauseText) } }, touch: function () { var e, n, i, o, u, a, f = !1, d = 0, v = 0, m = 0; if (!s) { t.addEventListener("touchstart", g, !1); function g(s) { if (r.animating) s.preventDefault(); else if (window.navigator.msPointerEnabled || s.touches.length === 1) { r.pause(); o = l ? r.h : r.w; a = Number(new Date); d = s.touches[0].pageX; v = s.touches[0].pageY; i = h && c && r.animatingTo === r.last ? 0 : h && c ? r.limit - (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo : h && r.currentSlide === r.last ? r.limit : h ? (r.itemW + r.vars.itemMargin) * r.move * r.currentSlide : c ? (r.last - r.currentSlide + r.cloneOffset) * o : (r.currentSlide + r.cloneOffset) * o; e = l ? v : d; n = l ? d : v; t.addEventListener("touchmove", y, !1); t.addEventListener("touchend", b, !1) } } function y(t) { d = t.touches[0].pageX; v = t.touches[0].pageY; u = l ? e - v : e - d; f = l ? Math.abs(u) < Math.abs(d - n) : Math.abs(u) < Math.abs(v - n); var s = 500; if (!f || Number(new Date) - a > s) { t.preventDefault(); if (!p && r.transitions) { r.vars.animationLoop || (u /= r.currentSlide === 0 && u < 0 || r.currentSlide === r.last && u > 0 ? Math.abs(u) / o + 2 : 1); r.setProps(i + u, "setTouch") } } } function b(s) { t.removeEventListener("touchmove", y, !1); if (r.animatingTo === r.currentSlide && !f && u !== null) { var l = c ? -u : u, h = l > 0 ? r.getTarget("next") : r.getTarget("prev"); r.canAdvance(h) && (Number(new Date) - a < 550 && Math.abs(l) > 50 || Math.abs(l) > o / 2) ? r.mtAnimate(h, r.vars.pauseOnAction) : p || r.mtAnimate(r.currentSlide, r.vars.pauseOnAction, !0) } t.removeEventListener("touchend", b, !1); e = null; n = null; u = null; i = null } } else { t.style.msTouchAction = "none"; t._gesture = new MSGesture; t._gesture.target = t; t.addEventListener("MSPointerDown", w, !1); t._slider = r; t.addEventListener("MSGestureChange", E, !1); t.addEventListener("MSGestureEnd", S, !1); function w(e) { e.stopPropagation(); if (r.animating) e.preventDefault(); else { r.pause(); t._gesture.addPointer(e.pointerId); m = 0; o = l ? r.h : r.w; a = Number(new Date); i = h && c && r.animatingTo === r.last ? 0 : h && c ? r.limit - (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo : h && r.currentSlide === r.last ? r.limit : h ? (r.itemW + r.vars.itemMargin) * r.move * r.currentSlide : c ? (r.last - r.currentSlide + r.cloneOffset) * o : (r.currentSlide + r.cloneOffset) * o } } function E(e) { e.stopPropagation(); var n = e.target._slider; if (!n) return; var r = -e.translationX, s = -e.translationY; m += l ? s : r; u = m; f = l ? Math.abs(m) < Math.abs(-r) : Math.abs(m) < Math.abs(-s); if (e.detail === e.MSGESTURE_FLAG_INERTIA) { setImmediate(function () { t._gesture.stop() }); return } if (!f || Number(new Date) - a > 500) { e.preventDefault(); if (!p && n.transitions) { n.vars.animationLoop || (u = m / (n.currentSlide === 0 && m < 0 || n.currentSlide === n.last && m > 0 ? Math.abs(m) / o + 2 : 1)); n.setProps(i + u, "setTouch") } } } function S(t) { t.stopPropagation(); var r = t.target._slider; if (!r) return; if (r.animatingTo === r.currentSlide && !f && u !== null) { var s = c ? -u : u, l = s > 0 ? r.getTarget("next") : r.getTarget("prev"); r.canAdvance(l) && (Number(new Date) - a < 550 && Math.abs(s) > 50 || Math.abs(s) > o / 2) ? r.mtAnimate(l, r.vars.pauseOnAction) : p || r.mtAnimate(r.currentSlide, r.vars.pauseOnAction, !0) } e = null; n = null; u = null; i = null; m = 0 } } }, resize: function () { if (!r.animating && r.is(":visible")) { h || r.doMath(); if (p) v.smoothHeight(); else if (h) { r.slides.width(r.computedW); r.update(r.pagingCount); r.setProps() } else if (l) { r.viewport.height(r.h); r.setProps(r.h, "setTotal") } else { r.vars.smoothHeight && v.smoothHeight(); r.newSlides.width(r.computedW); r.setProps(r.computedW, "setTotal") } } }, smoothHeight: function (e) { if (!l || p) { var t = p ? r : r.viewport; e ? t.animate({ height: r.slides.eq(r.animatingTo).height() }, e) : t.height(r.slides.eq(r.animatingTo).height()) } }, sync: function (t) { var n = e(r.vars.sync).data("mtslider"), i = r.animatingTo; switch (t) { case "animate": n.mtAnimate(i, r.vars.pauseOnAction, !1, !0); break; case "play": !n.playing && !n.asNav && n.play(); break; case "pause": n.pause() } }, pauseInvisible: { visProp: null, init: function () { var e = ["webkit", "moz", "ms", "o"]; if ("hidden" in document) return "hidden"; for (var t = 0; t < e.length; t++) e[t] + "Hidden" in document && (v.pauseInvisible.visProp = e[t] + "Hidden"); if (v.pauseInvisible.visProp) { var n = v.pauseInvisible.visProp.replace(/[H|h]idden/, "") + "visibilitychange"; document.addEventListener(n, function () { v.pauseInvisible.isHidden() ? r.startTimeout ? clearTimeout(r.startTimeout) : r.pause() : r.started ? r.play() : r.vars.initDelay > 0 ? setTimeout(r.play, r.vars.initDelay) : r.play() }) } }, isHidden: function () { return document[v.pauseInvisible.visProp] || !1 } }, setToClearWatchedEvent: function () { clearTimeout(f); f = setTimeout(function () { a = "" }, 3e3) } }; r.mtAnimate = function (t, n, s, u, a) { !r.vars.animationLoop && t !== r.currentSlide && (r.direction = t > r.currentSlide ? "next" : "prev"); d && r.pagingCount === 1 && (r.direction = r.currentItem < t ? "next" : "prev"); if (!r.animating && (r.canAdvance(t, a) || s) && r.is(":visible")) { if (d && u) { var f = e(r.vars.asNavFor).data("mtslider"); r.atEnd = t === 0 || t === r.count - 1; f.mtAnimate(t, !0, !1, !0, a); r.direction = r.currentItem < t ? "next" : "prev"; f.direction = r.direction; if (Math.ceil((t + 1) / r.visible) - 1 === r.currentSlide || t === 0) { r.currentItem = t; r.slides.removeClass(i + "active-slide").eq(t).addClass(i + "active-slide"); return !1 } r.currentItem = t; r.slides.removeClass(i + "active-slide").eq(t).addClass(i + "active-slide"); t = Math.floor(t / r.visible) } r.animating = !0; r.animatingTo = t; n && r.pause(); r.vars.before(r); r.syncExists && !a && v.sync("animate"); r.vars.controlNav && v.controlNav.active(); h || r.slides.removeClass(i + "active-slide").eq(t).addClass(i + "active-slide"); r.atEnd = t === 0 || t === r.last; r.vars.directionNav && v.directionNav.update(); if (t === r.last) { r.vars.end(r); r.vars.animationLoop || r.pause() } if (!p) { var m = l ? r.slides.filter(":first").height() : r.computedW, g, y, b; if (h) { g = r.vars.itemMargin; b = (r.itemW + g) * r.move * r.animatingTo; y = b > r.limit && r.visible !== 1 ? r.limit : b } else r.currentSlide === 0 && t === r.count - 1 && r.vars.animationLoop && r.direction !== "next" ? y = c ? (r.count + r.cloneOffset) * m : 0 : r.currentSlide === r.last && t === 0 && r.vars.animationLoop && r.direction !== "prev" ? y = c ? 0 : (r.count + 1) * m : y = c ? (r.count - 1 - t + r.cloneOffset) * m : (t + r.cloneOffset) * m; r.setProps(y, "", r.vars.animationSpeed); if (r.transitions) { if (!r.vars.animationLoop || !r.atEnd) { r.animating = !1; r.currentSlide = r.animatingTo } r.container.unbind("webkitTransitionEnd transitionend"); r.container.bind("webkitTransitionEnd transitionend", function () { r.wrapup(m) }) } else r.container.animate(r.args, r.vars.animationSpeed, r.vars.easing, function () { r.wrapup(m) }) } else if (!o) { r.slides.eq(r.currentSlide).css({ zIndex: 1 }).animate({ opacity: 0 }, r.vars.animationSpeed, r.vars.easing); r.slides.eq(t).css({ zIndex: 2 }).animate({ opacity: 1 }, r.vars.animationSpeed, r.vars.easing, r.wrapup) } else { r.slides.eq(r.currentSlide).css({ opacity: 0, zIndex: 1 }); r.slides.eq(t).css({ opacity: 1, zIndex: 2 }); r.wrapup(m) } r.vars.smoothHeight && v.smoothHeight(r.vars.animationSpeed) } }; r.wrapup = function (e) { !p && !h && (r.currentSlide === 0 && r.animatingTo === r.last && r.vars.animationLoop ? r.setProps(e, "jumpEnd") : r.currentSlide === r.last && r.animatingTo === 0 && r.vars.animationLoop && r.setProps(e, "jumpStart")); r.animating = !1; r.currentSlide = r.animatingTo; r.vars.after(r) }; r.animateSlides = function () { !r.animating && m && r.mtAnimate(r.getTarget("next")) }; r.pause = function () { clearInterval(r.animatedSlides); r.animatedSlides = null; r.playing = !1; r.vars.pausePlay && v.pausePlay.update("play"); r.syncExists && v.sync("pause") }; r.play = function () { r.playing && clearInterval(r.animatedSlides); r.animatedSlides = r.animatedSlides || setInterval(r.animateSlides, r.vars.slideshowSpeed); r.started = r.playing = !0; r.vars.pausePlay && v.pausePlay.update("pause"); r.syncExists && v.sync("play") }; r.stop = function () { r.pause(); r.stopped = !0 }; r.canAdvance = function (e, t) { var n = d ? r.pagingCount - 1 : r.last; return t ? !0 : d && r.currentItem === r.count - 1 && e === 0 && r.direction === "prev" ? !0 : d && r.currentItem === 0 && e === r.pagingCount - 1 && r.direction !== "next" ? !1 : e === r.currentSlide && !d ? !1 : r.vars.animationLoop ? !0 : r.atEnd && r.currentSlide === 0 && e === n && r.direction !== "next" ? !1 : r.atEnd && r.currentSlide === n && e === 0 && r.direction === "next" ? !1 : !0 }; r.getTarget = function (e) { r.direction = e; return e === "next" ? r.currentSlide === r.last ? 0 : r.currentSlide + 1 : r.currentSlide === 0 ? r.last : r.currentSlide - 1 }; r.setProps = function (e, t, n) { var i = function () { var n = e ? e : (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo, i = function () { if (h) return t === "setTouch" ? e : c && r.animatingTo === r.last ? 0 : c ? r.limit - (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo : r.animatingTo === r.last ? r.limit : n; switch (t) { case "setTotal": return c ? (r.count - 1 - r.currentSlide + r.cloneOffset) * e : (r.currentSlide + r.cloneOffset) * e; case "setTouch": return c ? e : e; case "jumpEnd": return c ? e : r.count * e; case "jumpStart": return c ? r.count * e : e; default: return e } } (); return i * -1 + "px" } (); if (r.transitions) { i = l ? "translate3d(0," + i + ",0)" : "translate3d(" + i + ",0,0)"; n = n !== undefined ? n / 1e3 + "s" : "0s"; r.container.css("-" + r.pfx + "-transition-duration", n) } r.args[r.prop] = i; (r.transitions || n === undefined) && r.container.css(r.args) }; r.setup = function (t) { if (!p) { var n, s; if (t === "init") { r.viewport = e('<div class="' + i + 'viewport"></div>').css({ overflow: "hidden", position: "relative" }).appendTo(r).append(r.container); r.cloneCount = 0; r.cloneOffset = 0; if (c) { s = e.makeArray(r.slides).reverse(); r.slides = e(s); r.container.empty().append(r.slides) } } if (r.vars.animationLoop && !h) { r.cloneCount = 2; r.cloneOffset = 1; t !== "init" && r.container.find(".clone").remove(); r.container.append(r.slides.first().clone().addClass("clone").attr("aria-hidden", "true")).prepend(r.slides.last().clone().addClass("clone").attr("aria-hidden", "true")) } r.newSlides = e(r.vars.selector, r); n = c ? r.count - 1 - r.currentSlide + r.cloneOffset : r.currentSlide + r.cloneOffset; if (l && !h) { r.container.height((r.count + r.cloneCount) * 200 + "%").css("position", "absolute").width("100%"); setTimeout(function () { r.newSlides.css({ display: "block" }); r.doMath(); r.viewport.height(r.h); r.setProps(n * r.h, "init") }, t === "init" ? 100 : 0) } else { r.container.width((r.count + r.cloneCount) * 200 + "%"); r.setProps(n * r.computedW, "init"); setTimeout(function () { r.doMath(); r.newSlides.css({ width: r.computedW, "float": "left", display: "block" }); r.vars.smoothHeight && v.smoothHeight() }, t === "init" ? 100 : 0) } } else { r.slides.css({ width: "100%", "float": "left", marginRight: "-100%", position: "relative" }); t === "init" && (o ? r.slides.css({ opacity: 0, display: "block", webkitTransition: "opacity " + r.vars.animationSpeed / 1e3 + "s ease", zIndex: 1 }).eq(r.currentSlide).css({ opacity: 1, zIndex: 2 }) : r.slides.css({ opacity: 0, display: "block", zIndex: 1 }).eq(r.currentSlide).css({ zIndex: 2 }).animate({ opacity: 1 }, r.vars.animationSpeed, r.vars.easing)); r.vars.smoothHeight && v.smoothHeight() } h || r.slides.removeClass(i + "active-slide").eq(r.currentSlide).addClass(i + "active-slide") }; r.doMath = function () { var e = r.slides.first(), t = r.vars.itemMargin, n = r.vars.minItems, i = r.vars.maxItems; r.w = r.viewport === undefined ? r.width() : r.viewport.width(); r.h = e.height(); r.boxPadding = e.outerWidth() - e.width(); if (h) { r.itemT = r.vars.itemWidth + t; r.minW = n ? n * r.itemT : r.w; r.maxW = i ? i * r.itemT - t : r.w; r.itemW = r.minW > r.w ? (r.w - t * (n - 1)) / n : r.maxW < r.w ? (r.w - t * (i - 1)) / i : r.vars.itemWidth > r.w ? r.w : r.vars.itemWidth; r.visible = Math.floor(r.w / r.itemW); r.move = r.vars.move > 0 && r.vars.move < r.visible ? r.vars.move : r.visible; r.pagingCount = Math.ceil((r.count - r.visible) / r.move + 1); r.last = r.pagingCount - 1; r.limit = r.pagingCount === 1 ? 0 : r.vars.itemWidth > r.w ? r.itemW * (r.count - 1) + t * (r.count - 1) : (r.itemW + t) * r.count - r.w - t } else { r.itemW = r.w; r.pagingCount = r.count; r.last = r.count - 1 } r.computedW = r.itemW - r.boxPadding }; r.update = function (e, t) { r.doMath(); if (!h) { e < r.currentSlide ? r.currentSlide += 1 : e <= r.currentSlide && e !== 0 && (r.currentSlide -= 1); r.animatingTo = r.currentSlide } if (r.vars.controlNav && !r.manualControls) if (t === "add" && !h || r.pagingCount > r.controlNav.length) v.controlNav.update("add"); else if (t === "remove" && !h || r.pagingCount < r.controlNav.length) { if (h && r.currentSlide > r.last) { r.currentSlide -= 1; r.animatingTo -= 1 } v.controlNav.update("remove", r.last) } r.vars.directionNav && v.directionNav.update() }; r.addSlide = function (t, n) { var i = e(t); r.count += 1; r.last = r.count - 1; l && c ? n !== undefined ? r.slides.eq(r.count - n).after(i) : r.container.prepend(i) : n !== undefined ? r.slides.eq(n).before(i) : r.container.append(i); r.update(n, "add"); r.slides = e(r.vars.selector + ":not(.clone)", r); r.setup(); r.vars.added(r) }; r.removeSlide = function (t) { var n = isNaN(t) ? r.slides.index(e(t)) : t; r.count -= 1; r.last = r.count - 1; isNaN(t) ? e(t, r.slides).remove() : l && c ? r.slides.eq(r.last).remove() : r.slides.eq(t).remove(); r.doMath(); r.update(n, "remove"); r.slides = e(r.vars.selector + ":not(.clone)", r); r.setup(); r.vars.removed(r) }; v.init() }; e(window).blur(function (e) { focused = !1 }).focus(function (e) { focused = !0 }); e.mtslider.defaults = { namespace: "mt-", selector: ".slides > li", animation: "fade", easing: "swing", direction: "horizontal", reverse: !1, animationLoop: !0, smoothHeight: !1, startAt: 0, slideshow: !0, slideshowSpeed: 7e3, animationSpeed: 600, initDelay: 0, randomize: !1, thumbCaptions: !1, pauseOnAction: !0, pauseOnHover: !1, pauseInvisible: !0, useCSS: !0, touch: !0, video: !1, controlNav: !0, directionNav: !0, prevText: "Previous", nextText: "Next", keyboard: !0, multipleKeyboard: !1, mousewheel: !1, pausePlay: !1, pauseText: "Pause", playText: "Play", controlsContainer: "", manualControls: "", sync: "", asNavFor: "", itemWidth: 0, itemMargin: 0, minItems: 1, maxItems: 0, move: 0, allowOneSlide: !0, start: function () { }, before: function () { }, after: function () { }, end: function () { }, added: function () { }, removed: function () { } }; e.fn.mtslider = function (t) { t === undefined && (t = {}); if (typeof t == "object") return this.each(function () { var n = e(this), r = t.selector ? t.selector : ".slides > li", i = n.find(r); if (i.length === 1 && t.allowOneSlide === !0 || i.length === 0) { i.fadeIn(400); t.start && t.start(n) } else n.data("mtslider") === undefined && new e.mtslider(this, t) }); var n = e(this).data("mtslider"); switch (t) { case "play": n.play(); break; case "pause": n.pause(); break; case "stop": n.stop(); break; case "next": n.mtAnimate(n.getTarget("next"), !0); break; case "prev": case "previous": n.mtAnimate(n.getTarget("prev"), !0); break; default: typeof t == "number" && n.mtAnimate(t, !0) } } })(jQuery);

(function (e) { "use strict"; e.fn.carousel = function (t) { var n = { infinite: true, visible: 1, speed: "fast", overflow: false, autoRotate: false, navigation: e(this).data("navigation"), itemMinWidth: 0, itemEqualHeight: false, itemMargin: 0, itemClassActive: "crsl-active" }; return e(this).each(function () { var r = e(this); if (e.isEmptyObject(t) == false) e.extend(n, t); if (e.isEmptyObject(e(r).data("crsl")) == false) e.extend(n, e(r).data("crsl")); e(window).ready(function () { e(r).trigger("initCarousel", [n, r]); r.init(n, r); r.config(n, r); if (n.itemEqualHeight !== false) { e(window).load(function () { r.equalHeights(n, r) }) } e(window).resize(function () { if (this.resizeTO) clearTimeout(this.resizeTO); this.resizeTO = setTimeout(function () { e(this).trigger("resizeEnd") }, 100) }); if (n.autoRotate !== false) { r.rotateTime = window.setInterval(function () { r.rotate(n, r) }, n.autoRotate) } }); e("#" + n.navigation).delegate(".previous, .next", "click", function (t) { t.preventDefault(); r.prepareExecute(n, r); if (e(this).hasClass("previous") && e(".crsl-wrap", r).find(".crsl-item").index(r.itemActive) > 0) { r.previous(n, r) } else if (e(this).hasClass("next") && (!n.infinite && r.wrapWidth - r.wrapMargin == n.itemWidth * n.total || n.infinite)) { r.next(n, r) } }); e(window).on("resizeEnd", function () { if (n.itemWidth !== e(r).outerWidth()) { r.config(n, r) } }); var i = false; e(window).on("mouseover", function (t) { if (t.target) { var n = t.target } else if (t.srcElement) { var n = t.srcElement } if (e(n).parents(".crsl-items").data("navigation") == e(r).data("navigation")) { i = true } else { i = false } return false }); e(window).on("keydown", function (e) { if (e.keyCode === 37 && i === true) { r.prepareExecute(n, r); r.previous(n, r) } else if (e.keyCode === 39 && i === true) { r.prepareExecute(n, r); r.next(n, r) } return }); if (typeof e(document).hammer == "function") { var s = false; e(document).hammer().on("swipe", function (t) { if (t.target) { var i = t.target } else if (t.srcElement) { var i = t.srcElement } if (e(i).parents(".crsl-items").data("navigation") == e(r).data("navigation")) { s = true } else { s = false } if (t.gesture.direction == "left" && s === true) { r.prepareExecute(n, r); r.next(n, r) } else if (t.gesture.direction == "right" && s === true) { r.prepareExecute(n, r); r.previous(n, r) } }) } r.init = function (t, n) { t.total = e(n).find(".crsl-item").length; t.itemWidth = e(n).outerWidth(); t.visibleDefault = t.visible; e(n).css({ width: "100%" }); e(n).find(".crsl-item").css({ position: "relative", "float": "left", overflow: "hidden", height: "auto" }); e(n).find(".wide-image").css({ display: "block", width: "100%", height: "auto" }); e(n).find(".crsl-item iframe").attr({ width: "100%" }); e(n).find(".crsl-item:first-child").addClass(t.itemClassActive); if (t.infinite && t.visible < t.total) { e(n).find(".crsl-item:first-child").before(e(".crsl-item:last-child", n)) } if (t.overflow === false) { e(n).css({ overflow: "hidden" }) } else { e("html, body").css({ "overflow-x": "hidden" }) } }; r.config = function (t, n) { t.itemWidth = Math.floor((e(n).outerWidth() - t.itemMargin * (t.visibleDefault - 1)) / t.visibleDefault); if (t.itemWidth <= t.itemMinWidth) { t.visible = Math.floor((e(n).outerWidth() - t.itemMargin * (t.visible - 1)) / t.itemMinWidth) === 1 ? Math.floor(e(n).outerWidth() / t.itemMinWidth) : Math.floor((e(n).outerWidth() - t.itemMargin) / t.itemMinWidth); t.visible = t.visible < 1 ? 1 : t.visible; t.itemWidth = t.visible === 1 ? Math.floor(e(n).outerWidth()) : Math.floor((e(n).outerWidth() - t.itemMargin * (t.visible - 1)) / t.visible) } else { t.visible = t.visibleDefault } n.wrapWidth = Math.floor((t.itemWidth + t.itemMargin) * t.total); n.wrapMargin = n.wrapMarginDefault = t.infinite && t.visible < t.total ? parseInt((t.itemWidth + t.itemMargin) * -1) : 0; if (t.infinite && t.visible < t.total && e(n).find(".crsl-item." + t.itemClassActive).index() === 0) { e(n).find(".crsl-item:first-child").before(e(".crsl-item:last-child", n)); n.wrapMargin = n.wrapMarginDefault = parseInt((t.itemWidth + t.itemMargin) * -1) } e(n).find(".crsl-wrap").css({ width: n.wrapWidth + "px", marginLeft: n.wrapMargin }); e(n).find(".crsl-item").css({ width: t.itemWidth + "px", marginRight: t.itemMargin + "px" }); n.equalHeights(t, n); if (t.visible >= t.total) { t.autoRotate = false; e("#" + t.navigation).hide() } else { e("#" + t.navigation).show() } }; r.prepareExecute = function (t, n) { if (t.autoRotate !== false) { clearInterval(n.rotateTime) } if (e(n).find(".crsl-wrap:animated").length > 0) { mouseOverCarousel = false; return false } n.itemActive = e(n).find(".crsl-item." + t.itemClassActive); return true }; r.rotate = function (t, n) { if (e(n).find(".crsl-wrap:animated").length > 0) { mouseOverCarousel = false; return false } n.itemActive = e(n).find(".crsl-item." + t.itemClassActive); n.next(t, n); return true }; r.equalHeights = function (t, n) { if (t.itemEqualHeight !== false) { var r = 0; e(n).find(".crsl-item").each(function () { e(this).css({ height: "auto" }); if (e(this).outerHeight() > r) { r = e(this).outerHeight() } }); e(n).find(".crsl-item").css({ height: r + "px" }) } return true }; r.previous = function (t, n) { n.wrapMargin = t.infinite ? n.wrapMarginDefault + e(n.itemActive).outerWidth(true) : n.wrapMargin + e(itemActive).outerWidth(true); var r = e(n.itemActive).index(); var i = e(n.itemActive).prev(".crsl-item"); var s = "previous"; e(n).trigger("beginCarousel", [t, n, s]); e(n).find(".crsl-wrap").animate({ marginLeft: n.wrapMargin + "px" }, t.speed, function () { e(n.itemActive).removeClass(t.itemClassActive); e(i).addClass(t.itemClassActive); if (t.infinite) { e(this).css({ marginLeft: n.wrapMarginDefault }).find(".crsl-item:first-child").before(e(".crsl-item:last-child", n)) } else { if (n.wrapMargin >= n.wrapMarginDefault) e("#" + t.navigation).find(".previous").addClass("previous-inactive"); if (n.wrapWidth - n.wrapMargin == t.itemWidth * t.total) e("#" + t.navigation).find(".next").removeClass("next-inactive") } e(this).trigger("endCarousel", [t, n, s]) }) }; r.next = function (t, n) { n.wrapMargin = t.infinite ? n.wrapMarginDefault - e(n.itemActive).outerWidth(true) : n.wrapMargin - e(itemActive).outerWidth(true); var r = e(n.itemActive).index(); var i = e(n.itemActive).next(".crsl-item"); var s = "next"; e(n).trigger("beginCarousel", [t, n, s]); e(n).find(".crsl-wrap").animate({ marginLeft: n.wrapMargin + "px" }, t.speed, function () { e(n.itemActive).removeClass(t.itemClassActive); e(i).addClass(t.itemClassActive); if (t.infinite) { e(this).css({ marginLeft: n.wrapMarginDefault }).find(".crsl-item:last-child").after(e(".crsl-item:first-child", n)) } else { if (n.wrapMargin < n.wrapMarginDefault) e("#" + t.navigation).find(".previous").removeClass("previous-inactive"); if (n.wrapWidth - n.wrapMargin != t.itemWidth * t.total) e("#" + t.navigation).find(".next").addClass("next-inactive") } e(this).trigger("endCarousel", [t, n, s]) }) } }) } })(jQuery)

$(document).ready(function () {

    var $slideshow = $('.mtslide');

    $slideshow.mtslider({
        animation: "slide",
        directionNav: false,
        controlNav: false,
        slideshow: true,
        slideshowSpeed: 7000,
        start: function (slider) {
            $('.mtslide img').resize();
        }
    });

    $('.mt-next').click(function () { $slideshow.mtslider("next"); });
    $('.mt-prev').click(function () { $slideshow.mtslider("prev"); });
});