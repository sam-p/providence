/* Minification failed. Returning unminified contents.
(409,4834-4851): run-time error JS1300: Strict-mode does not allow assignment to undefined variables: mouseOverCarousel
(409,4636-4653): run-time error JS1300: Strict-mode does not allow assignment to undefined variables: mouseOverCarousel
 */
(function ($) {
 
/*
Plugins & Extensions

Store extensions & 3rd-party tools on in this file for reference & management. All references should be kept track up for upgrading & deprecation purposes

<FORMAT>

//[NAME] =======================================================================
/*
DOCUMENTATION: -Any links or repositories, or anywhere where additional information might be found on this extension-
USAGE: -At a high level, how is this extension called or referenced-
REFERENCES: -Where is this extension used? List all code & modules so that if we delete it, there are no issues downstream. Pipe delimited, ie Pysician Module | Calendar Module | carousel extension | etc-
DEPENDENCIES: -What other libraries or extensions, if deleted, would cause this code to fail? When necessary, be specific to version
NOTES: - Any additional information, or deprecation/upgrade timeline/suggestions
*/

/*
</FORMAT>


<NOTE>
    This library should always contain the un-minified version of a library whenever possible. Minification can occur in production.
</NOTE>

*/


/*
*
* START
*
*/

//imagesLoaded Library:  ================================================================
/* 
DOCUMENTATION: https://github.com/desandro/imagesloaded
USAGE: imagesLoaded( IMAGE, function() {orig.width = IMAGE.width; [etc] });
REFERENCES: mtGallery
DEPENDENCIES: jQUery
NOTES: Should be deleted with mtGallery re-write provided no other dependencies found. IC: This new update will be til phase 2.
*/

(function () { function e() { } function t(e, t) { for (var n = e.length; n--; ) if (e[n].listener === t) return n; return -1 } function n(e) { return function () { return this[e].apply(this, arguments) } } var i = e.prototype, r = this, o = r.EventEmitter; i.getListeners = function (e) { var t, n, i = this._getEvents(); if ("object" == typeof e) { t = {}; for (n in i) i.hasOwnProperty(n) && e.test(n) && (t[n] = i[n]) } else t = i[e] || (i[e] = []); return t }, i.flattenListeners = function (e) { var t, n = []; for (t = 0; e.length > t; t += 1) n.push(e[t].listener); return n }, i.getListenersAsObject = function (e) { var t, n = this.getListeners(e); return n instanceof Array && (t = {}, t[e] = n), t || n }, i.addListener = function (e, n) { var i, r = this.getListenersAsObject(e), o = "object" == typeof n; for (i in r) r.hasOwnProperty(i) && -1 === t(r[i], n) && r[i].push(o ? n : { listener: n, once: !1 }); return this }, i.on = n("addListener"), i.addOnceListener = function (e, t) { return this.addListener(e, { listener: t, once: !0 }) }, i.once = n("addOnceListener"), i.defineEvent = function (e) { return this.getListeners(e), this }, i.defineEvents = function (e) { for (var t = 0; e.length > t; t += 1) this.defineEvent(e[t]); return this }, i.removeListener = function (e, n) { var i, r, o = this.getListenersAsObject(e); for (r in o) o.hasOwnProperty(r) && (i = t(o[r], n), -1 !== i && o[r].splice(i, 1)); return this }, i.off = n("removeListener"), i.addListeners = function (e, t) { return this.manipulateListeners(!1, e, t) }, i.removeListeners = function (e, t) { return this.manipulateListeners(!0, e, t) }, i.manipulateListeners = function (e, t, n) { var i, r, o = e ? this.removeListener : this.addListener, s = e ? this.removeListeners : this.addListeners; if ("object" != typeof t || t instanceof RegExp) for (i = n.length; i--; ) o.call(this, t, n[i]); else for (i in t) t.hasOwnProperty(i) && (r = t[i]) && ("function" == typeof r ? o.call(this, i, r) : s.call(this, i, r)); return this }, i.removeEvent = function (e) { var t, n = typeof e, i = this._getEvents(); if ("string" === n) delete i[e]; else if ("object" === n) for (t in i) i.hasOwnProperty(t) && e.test(t) && delete i[t]; else delete this._events; return this }, i.removeAllListeners = n("removeEvent"), i.emitEvent = function (e, t) { var n, i, r, o, s = this.getListenersAsObject(e); for (r in s) if (s.hasOwnProperty(r)) for (i = s[r].length; i--; ) n = s[r][i], n.once === !0 && this.removeListener(e, n.listener), o = n.listener.apply(this, t || []), o === this._getOnceReturnValue() && this.removeListener(e, n.listener); return this }, i.trigger = n("emitEvent"), i.emit = function (e) { var t = Array.prototype.slice.call(arguments, 1); return this.emitEvent(e, t) }, i.setOnceReturnValue = function (e) { return this._onceReturnValue = e, this }, i._getOnceReturnValue = function () { return this.hasOwnProperty("_onceReturnValue") ? this._onceReturnValue : !0 }, i._getEvents = function () { return this._events || (this._events = {}) }, e.noConflict = function () { return r.EventEmitter = o, e }, "function" == typeof define && define.amd ? define("eventEmitter/EventEmitter", [], function () { return e }) : "object" == typeof module && module.exports ? module.exports = e : this.EventEmitter = e }).call(this), function (e) { function t(t) { var n = e.event; return n.target = n.target || n.srcElement || t, n } var n = document.documentElement, i = function () { }; n.addEventListener ? i = function (e, t, n) { e.addEventListener(t, n, !1) } : n.attachEvent && (i = function (e, n, i) { e[n + i] = i.handleEvent ? function () { var n = t(e); i.handleEvent.call(i, n) } : function () { var n = t(e); i.call(e, n) }, e.attachEvent("on" + n, e[n + i]) }); var r = function () { }; n.removeEventListener ? r = function (e, t, n) { e.removeEventListener(t, n, !1) } : n.detachEvent && (r = function (e, t, n) { e.detachEvent("on" + t, e[t + n]); try { delete e[t + n] } catch (i) { e[t + n] = void 0 } }); var o = { bind: i, unbind: r }; "function" == typeof define && define.amd ? define("eventie/eventie", o) : e.eventie = o } (this), function (e, t) { "function" == typeof define && define.amd ? define(["eventEmitter/EventEmitter", "eventie/eventie"], function (n, i) { return t(e, n, i) }) : "object" == typeof exports ? module.exports = t(e, require("eventEmitter"), require("eventie")) : e.imagesLoaded = t(e, e.EventEmitter, e.eventie) } (this, function (e, t, n) { function i(e, t) { for (var n in t) e[n] = t[n]; return e } function r(e) { return "[object Array]" === d.call(e) } function o(e) { var t = []; if (r(e)) t = e; else if ("number" == typeof e.length) for (var n = 0, i = e.length; i > n; n++) t.push(e[n]); else t.push(e); return t } function s(e, t, n) { if (!(this instanceof s)) return new s(e, t); "string" == typeof e && (e = document.querySelectorAll(e)), this.elements = o(e), this.options = i({}, this.options), "function" == typeof t ? n = t : i(this.options, t), n && this.on("always", n), this.getImages(), a && (this.jqDeferred = new a.Deferred); var r = this; setTimeout(function () { r.check() }) } function c(e) { this.img = e } function f(e) { this.src = e, v[e] = this } var a = e.jQuery, u = e.console, h = u !== void 0, d = Object.prototype.toString; s.prototype = new t, s.prototype.options = {}, s.prototype.getImages = function () { this.images = []; for (var e = 0, t = this.elements.length; t > e; e++) { var n = this.elements[e]; "IMG" === n.nodeName && this.addImage(n); for (var i = n.querySelectorAll("img"), r = 0, o = i.length; o > r; r++) { var s = i[r]; this.addImage(s) } } }, s.prototype.addImage = function (e) { var t = new c(e); this.images.push(t) }, s.prototype.check = function () { function e(e, r) { return t.options.debug && h && u.log("confirm", e, r), t.progress(e), n++, n === i && t.complete(), !0 } var t = this, n = 0, i = this.images.length; if (this.hasAnyBroken = !1, !i) return this.complete(), void 0; for (var r = 0; i > r; r++) { var o = this.images[r]; o.on("confirm", e), o.check() } }, s.prototype.progress = function (e) { this.hasAnyBroken = this.hasAnyBroken || !e.isLoaded; var t = this; setTimeout(function () { t.emit("progress", t, e), t.jqDeferred && t.jqDeferred.notify && t.jqDeferred.notify(t, e) }) }, s.prototype.complete = function () { var e = this.hasAnyBroken ? "fail" : "done"; this.isComplete = !0; var t = this; setTimeout(function () { if (t.emit(e, t), t.emit("always", t), t.jqDeferred) { var n = t.hasAnyBroken ? "reject" : "resolve"; t.jqDeferred[n](t) } }) }, a && (a.fn.imagesLoaded = function (e, t) { var n = new s(this, e, t); return n.jqDeferred.promise(a(this)) }), c.prototype = new t, c.prototype.check = function () { var e = v[this.img.src] || new f(this.img.src); if (e.isConfirmed) return this.confirm(e.isLoaded, "cached was confirmed"), void 0; if (this.img.complete && void 0 !== this.img.naturalWidth) return this.confirm(0 !== this.img.naturalWidth, "naturalWidth"), void 0; var t = this; e.on("confirm", function (e, n) { return t.confirm(e.isLoaded, n), !0 }), e.check() }, c.prototype.confirm = function (e, t) { this.isLoaded = e, this.emit("confirm", this, t) }; var v = {}; return f.prototype = new t, f.prototype.check = function () { if (!this.isChecked) { var e = new Image; n.bind(e, "load", this), n.bind(e, "error", this), e.src = this.src, this.isChecked = !0 } }, f.prototype.handleEvent = function (e) { var t = "on" + e.type; this[t] && this[t](e) }, f.prototype.onload = function (e) { this.confirm(!0, "onload"), this.unbindProxyEvents(e) }, f.prototype.onerror = function (e) { this.confirm(!1, "onerror"), this.unbindProxyEvents(e) }, f.prototype.confirm = function (e, t) { this.isConfirmed = !0, this.isLoaded = e, this.emit("confirm", this, t) }, f.prototype.unbindProxyEvents = function (e) { n.unbind(e.target, "load", this), n.unbind(e.target, "error", this) }, s });



//jQuery selector extensions =======================================================
/*
DOCUMENTATION: 
USAGE: Use as regular jQuery selector, ie $('DIV:first-of-type')
REFERENCES: None Found
DEPENDENCIES: jQuery
NOTES: Patrick 8/26: This can likely be removed, unless dependencies can be found.
*/

(function ($) {
    function getNthIndex(cur, dir) {
        var t = cur, idx = 0;
        while (cur = cur[dir]) {
            if (t.tagName == cur.tagName) {
                idx++;
            }
        }
        return idx;
    }

    function isNthOf(elm, pattern, dir) {
        var position = getNthIndex(elm, dir), loop;
        if (pattern == "odd" || pattern == "even") {
            loop = 2;
            position -= !(pattern == "odd");
        } else {
            var nth = pattern.indexOf("n");
            if (nth > -1) {
                loop = parseInt(pattern, 10) || parseInt(pattern.substring(0, nth) + "1", 10);
                position -= (parseInt(pattern.substring(nth + 1), 10) || 0) - 1;
            } else {
                loop = position + 1;
                position -= parseInt(pattern, 10) - 1;
            }
        }
        return (loop < 0 ? position <= 0 : position >= 0) && position % loop == 0
    }

    var pseudos = {
        "first-of-type": function (elm) {
            return getNthIndex(elm, "previousSibling") == 0;
        },
        "last-of-type": function (elm) {
            return getNthIndex(elm, "nextSibling") == 0;
        },
        "only-of-type": function (elm) {
            return pseudos["first-of-type"](elm) && pseudos["last-of-type"](elm);
        },
        "nth-of-type": function (elm, i, match) {
            return isNthOf(elm, match[3], "previousSibling");
        },
        "nth-last-of-type": function (elm, i, match) {
            return isNthOf(elm, match[3], "nextSibling");
        }
    }
    $.extend($.expr[':'], pseudos);
})(jQuery);


//jQuery Toggle extension ======================================================================================
/*
DOCUMENTATION
USAGE:  
REFERENCES: None Found
DEPENDENCIES: jQuery
NOTES: Patrick 8/26: This can likely be removed as long as no other dependencies exist
*/
(function ($, window, document) {
    $.fn.attachToggle = function(options) {
        var defaults = {
            activeClass: 'active',
            animation: 'toggle', // slideToggle, toggle or custom
            animationOpts: 200,  // animation speed as integer for toggle and slideToggle, or property object for animate
            attachEvent: 'click', // any valid event (i.e. click, hover, focus)
            customFunction: function() {}
        };

        var opts = $.extend( {}, defaults, options),
            $this = $(this);

        if (opts.animateEl !== null) {
            return $this.each( function(index, element) {
                var $t = $(this);
                switch ($t.data("animation") ? $t.data("animation") : opts.animation) {
                    case "custom":
                        $(this).on(opts.attachEvent, opts.customFunction);
                        break;
                    default:
                        $(this).on(opts.attachEvent, function(e) {
                            e.preventDefault;
                            $t.toggleClass(opts.activeClass);
                            switch ($t.data("animation") ? $t.data("animation") : opts.animation) {
                                case "slideToggle":
                                    $($t.data("toggle")).slideToggle($t.data("speed") ? $t.data("speed") : opts.animateOpts);
                                    break;
                                default:
                                    $($t.data("toggle")).toggle($t.data("speed") ? $t.data("speed") : opts.animateOpts);
                            }
                            return false;
                        });
                }
            });
        }
    }
})(jQuery, window, document);


//jQuery List Alphabetizer ======================================================================================
/*
DOCUMENTATION: 
USAGE: $('ul.selector, ol.selector').sortList();
REFERENCES: None Found
DEPENDENCIES: jQuery
NOTES: Patrick 8/26: This can likely be removed pending no other found dependencies
*/
(function ($, window, document) {
    $.fn.sortList = function(sortDescending) {
        var $lists = $(this);
        // Only proceed if there is a list
        if ($lists.length > 0) {
            return $lists.each( function(index, element) {
                var $list = $(this);
                // Get the list items and setup an array for sorting
                var $lis = $list.find("li"),
                    vals = [];

                // Populate the array
                $lis.each( function(index, element) {
                    var $this = $(this);
                    vals.push({ sort: $this.text(), html: $this });
                });

                // Sort it
                vals.sort( function(a,b) {
                    if (a.sort > b.sort) return 1;
                    if (a.sort < b.sort) return -1;
                    // a must be equal to b
                    return 0;
                });

                // Sometimes you gotta DESC
                if(sortDescending) vals.reverse();

                // Empty existing data from UL
                $list.html("");

                // Change the list on the page
                for (var i=0,l=vals.length; i<l; i++) {
                    vals[i].html.appendTo($list);
                }
            });
        } else return false;
    }
})(jQuery, window, document);


//jQuery Tree extension =======================================================================================
/*
DOCUMENTATION:
USAGE:
REFERENCES: Used in Data Tree Mgmt block
DEPENDENCIES: jQuery | jQuery cookie extension
NOTES: 
*/
!function($) {
  $.fn.tree = function(options) {
    if(!options) options = {};
    var default_options = {
      open_char                     : '-',
      close_char                    : '+',
      default_expanded_paths_string : '',
      only_one                      : false,
      animation                     : 'slow'
    };
    var o = {};
    $.extend(o, default_options, options);

    // Get the expanded paths from the current state of tree
    $.fn.save_paths = function() {
      var paths = [],
          path = [],
          open_nodes = $(this).find('li span.open'),
          last_depth = null;
      for(var i = 0; i < open_nodes.length; i++) {
        var depth = $(open_nodes[i]).parents('ul').length-1;
        if((last_depth == null && depth > 0) || (depth > last_depth && depth-last_depth > 1))
          continue;
        var pos = $(open_nodes[i]).parent().prevAll().length;
        if(last_depth == null) {
          path = [pos];
        } else if(depth < last_depth) {
          paths.push(path.join('/'));
          var diff = last_depth - depth;
          path.splice(path.length-diff-1, diff+1);
          path.push(pos);
        } else if(depth == last_depth) {
          paths.push(path.join('/'));
          path.splice(path.length-1, 1);
          path.push(pos);
        } else if(depth > last_depth) {
          path.push(pos);
        }
        last_depth = depth;
      }
      paths.push(path.join('/'));
      // Save state to cookie
      var cookie_key = this.data('cookie');
      if(!cookie_key) cookie_key = 'jtree-cookie';
      try { $.cookie(cookie_key, paths.join(',')); }
      catch(e) {}
    };

    // This function expand the tree with 'path'
    $.fn.restore_paths = function() {
      var paths_string = null;
      var cookie_key = this.data('cookie');
      if(!cookie_key) cookie_key = 'jtree-cookie';
      try { paths_string = $.cookie(cookie_key); }
      catch(e) {}
      if(!paths_string) paths_string = o.default_expanded_paths_string;
      if(paths_string == 'all') {
        $(this).find('span.jtree-arrow').open();
      } else {
        var paths = paths_string.split(',');
        for(var i = 0; i < paths.length; i++) {
          var path = paths[i].split('/'),
              obj = $(this);
          for(var j = 0; j < path.length; j++) {
            obj = $(obj.children('li')[path[j]]);
            obj.children('span.jtree-arrow').open();
            obj = obj.children('ul')
          }
        }
      }
    };

    // Expand the tree (animation bug fixed - @stecb)
    $.fn.expand = function(animation) {
      animation = (animation == 'none') ? undefined : (!animation) ? o.animation : animation;
      // find each :first-child .jtree-arrow.close element (we don't need to care about open elements, they're already open...)
      elems = $(this).find('.jtree-arrow.close:first-child');
      // their childs .jtree-arrow.close need to be opened without animation (!IMPORTANT!)
      elems.siblings('ul').find('.jtree-arrow.close').open(undefined);
      // the :first-child elements now can be opened with animation (height is known now)
      elems.open(animation);
    };

    // Collapse the tree
    $.fn.collapse = function(animation) {
      animation = (animation == 'none') ? undefined : (!animation) ? o.animation : animation;
      $(this).find('.jtree-arrow').close(animation);
    };

    // Open a child
    $.fn.open = function(animation) {
      if($(this).hasClass('jtree-arrow')) {
        $(this).parent().children('ul').show(animation);
        $(this).removeClass('close').addClass('open').html(o.open_char);
      }
    };

    // Close a child
    $.fn.close = function(animation) {
      if($(this).hasClass('jtree-arrow')) {
        $(this).parent().children('ul').hide(animation);
        $(this).removeClass('open').addClass('close').html(o.close_char);
      }
    };

    // Click event on <span class="jtree-arrow"></span>
    $.fn.click_event = function() {
      var button = $(this);
      if(button.hasClass('jtree-arrow')) {
        button[button.hasClass('open') ? 'close' : 'open'](o.animation);
        if(o.only_one) button.closest('li').siblings().children('span.jtree-arrow').close(o.animation);
      }
    };

    for(var i = 0; i < this.length; i++) {
      if(this[i].tagName === 'UL') {
        // Make a tree
        $(this[i]).find('li').has('ul').prepend('<span class="jtree-arrow close" style="cursor:pointer;">' + o.close_char + '</span>');
        $(this[i]).find('ul').hide();
        // Restore cookie expand path
        $(this[i]).restore_paths();
        // Click event for arrow
        $(this[i]).find('li > span.jtree-arrow').on('click', {tree : this[i]}, function(e) {
          $(this).click_event();
          $(e.data.tree).save_paths();
        });
        // Click event for 'jtree-button'
        $(this[i]).find('li .jtree-button').on('click', {tree : this[i]}, function(e) {
          var arrow = $(this).closest('li').children('span.jtree-arrow');
          arrow.click_event();
          $(e.data.tree).save_paths();
        });
      }
    }
  };
}(jQuery);


//jQuery Cookie extension ======================================================================================
/*
DOCUMENTATION:
USAGE: $.cookie(cookie_key)
REFERENCES: jQuery tree extension
DEPENDENCIES: jQuery
NOTES:
*/
jQuery.cookie = function(name, value, options) {
  if (typeof value != 'undefined') { // name and value given, set cookie
    options = options || {};
    if (value === null) {
      value = '';
      options.expires = -1;
    }
    var expires = '';
    if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
      var date;
      if (typeof options.expires == 'number') {
        date = new Date();
        date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
      } else {
        date = options.expires;
      }
      expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
    }
    // CAUTION: Needed to parenthesize options.path and options.domain
    // in the following expressions, otherwise they evaluate to undefined
    // in the packed version for some reason...
    var path = options.path ? '; path=' + (options.path) : '';
    var domain = options.domain ? '; domain=' + (options.domain) : '';
    var secure = options.secure ? '; secure' : '';
    document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
  } else { // only name given, get cookie
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
      var cookies = document.cookie.split(';');
      for (var i = 0; i < cookies.length; i++) {
        var cookie = jQuery.trim(cookies[i]);
        // Does this cookie string begin with the name we want?
        if (cookie.substring(0, name.length + 1) == (name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }
};

//jQuery Carousel ===================================================================================================
/*
DOCUMENTATION:
USAGE:
REFERENCES: Carousel Module $('.crsl-items').carousel()
DEPENDENCIES: jQuery
NOTES:
*/
(function (e) { "use strict"; e.fn.carousel = function (t) { var n = { infinite: true, visible: 1, speed: "fast", overflow: false, autoRotate: false, navigation: e(this).data("navigation"), itemMinWidth: 0, itemEqualHeight: false, itemMargin: 0, itemClassActive: "crsl-active" }; return e(this).each(function () { var r = e(this); if (e.isEmptyObject(t) == false) e.extend(n, t); if (e.isEmptyObject(e(r).data("crsl")) == false) e.extend(n, e(r).data("crsl")); e(window).ready(function () { e(r).trigger("initCarousel", [n, r]); r.init(n, r); r.config(n, r); if (n.itemEqualHeight !== false) { e(window).load(function () { r.equalHeights(n, r) }) } e(window).resize(function () { if (this.resizeTO) clearTimeout(this.resizeTO); this.resizeTO = setTimeout(function () { e(this).trigger("resizeEnd") }, 100) }); if (n.autoRotate !== false) { r.rotateTime = window.setInterval(function () { r.rotate(n, r) }, n.autoRotate) } }); e("#" + n.navigation).delegate(".previous, .next", "click", function (t) { t.preventDefault(); r.prepareExecute(n, r); if (e(this).hasClass("previous") && e(".crsl-wrap", r).find(".crsl-item").index(r.itemActive) > 0) { r.previous(n, r) } else if (e(this).hasClass("next") && (!n.infinite && r.wrapWidth - r.wrapMargin == n.itemWidth * n.total || n.infinite)) { r.next(n, r) } }); e(window).on("resizeEnd", function () { if (n.itemWidth !== e(r).outerWidth()) { r.config(n, r) } }); var i = false; e(window).on("mouseover", function (t) { if (t.target) { var n = t.target } else if (t.srcElement) { var n = t.srcElement } if (e(n).parents(".crsl-items").data("navigation") == e(r).data("navigation")) { i = true } else { i = false } return false }); e(window).on("keydown", function (e) { if (e.keyCode === 37 && i === true) { r.prepareExecute(n, r); r.previous(n, r) } else if (e.keyCode === 39 && i === true) { r.prepareExecute(n, r); r.next(n, r) } return }); if (typeof e(document).hammer == "function") { var s = false; e(document).hammer().on("swipe", function (t) { if (t.target) { var i = t.target } else if (t.srcElement) { var i = t.srcElement } if (e(i).parents(".crsl-items").data("navigation") == e(r).data("navigation")) { s = true } else { s = false } if (t.gesture.direction == "left" && s === true) { r.prepareExecute(n, r); r.next(n, r) } else if (t.gesture.direction == "right" && s === true) { r.prepareExecute(n, r); r.previous(n, r) } }) } r.init = function (t, n) { t.total = e(n).find(".crsl-item").length; t.itemWidth = e(n).outerWidth(); t.visibleDefault = t.visible; e(n).css({ width: "100%" }); e(n).find(".crsl-item").css({ position: "relative", "float": "left", overflow: "hidden", height: "auto" }); e(n).find(".wide-image").css({ display: "block", width: "100%", height: "auto" }); e(n).find(".crsl-item iframe").attr({ width: "100%" }); e(n).find(".crsl-item:first-child").addClass(t.itemClassActive); if (t.infinite && t.visible < t.total) { e(n).find(".crsl-item:first-child").before(e(".crsl-item:last-child", n)) } if (t.overflow === false) { e(n).css({ overflow: "hidden" }) } else { e("html, body").css({ "overflow-x": "initial" }) } }; r.config = function (t, n) { t.itemWidth = Math.floor((e(n).outerWidth() - t.itemMargin * (t.visibleDefault - 1)) / t.visibleDefault); if (t.itemWidth <= t.itemMinWidth) { t.visible = Math.floor((e(n).outerWidth() - t.itemMargin * (t.visible - 1)) / t.itemMinWidth) === 1 ? Math.floor(e(n).outerWidth() / t.itemMinWidth) : Math.floor((e(n).outerWidth() - t.itemMargin) / t.itemMinWidth); t.visible = t.visible < 1 ? 1 : t.visible; t.itemWidth = t.visible === 1 ? Math.floor(e(n).outerWidth()) : Math.floor((e(n).outerWidth() - t.itemMargin * (t.visible - 1)) / t.visible) } else { t.visible = t.visibleDefault } n.wrapWidth = Math.floor((t.itemWidth + t.itemMargin) * t.total); n.wrapMargin = n.wrapMarginDefault = t.infinite && t.visible < t.total ? parseInt((t.itemWidth + t.itemMargin) * -1) : 0; if (t.infinite && t.visible < t.total && e(n).find(".crsl-item." + t.itemClassActive).index() === 0) { e(n).find(".crsl-item:first-child").before(e(".crsl-item:last-child", n)); n.wrapMargin = n.wrapMarginDefault = parseInt((t.itemWidth + t.itemMargin) * -1) } e(n).find(".crsl-wrap").css({ width: n.wrapWidth + "px", marginLeft: n.wrapMargin }); e(n).find(".crsl-item").css({ width: t.itemWidth + "px", marginRight: t.itemMargin + "px" }); n.equalHeights(t, n); if (t.visible >= t.total) { t.autoRotate = false; e("#" + t.navigation).hide() } else { e("#" + t.navigation).show() } }; r.prepareExecute = function (t, n) { if (t.autoRotate !== false) { clearInterval(n.rotateTime) } if (e(n).find(".crsl-wrap:animated").length > 0) { mouseOverCarousel = false; return false } n.itemActive = e(n).find(".crsl-item." + t.itemClassActive); return true }; r.rotate = function (t, n) { if (e(n).find(".crsl-wrap:animated").length > 0) { mouseOverCarousel = false; return false } n.itemActive = e(n).find(".crsl-item." + t.itemClassActive); n.next(t, n); return true }; r.equalHeights = function (t, n) { if (t.itemEqualHeight !== false) { var r = 0; e(n).find(".crsl-item").each(function () { e(this).css({ height: "auto" }); if (e(this).outerHeight() > r) { r = e(this).outerHeight() } }); e(n).find(".crsl-item").css({ height: r + "px" }) } return true }; r.previous = function (t, n) { n.wrapMargin = t.infinite ? n.wrapMarginDefault + e(n.itemActive).outerWidth(true) : n.wrapMargin + e(itemActive).outerWidth(true); var r = e(n.itemActive).index(); var i = e(n.itemActive).prev(".crsl-item"); var s = "previous"; e(n).trigger("beginCarousel", [t, n, s]); e(n).find(".crsl-wrap").animate({ marginLeft: n.wrapMargin + "px" }, t.speed, function () { e(n.itemActive).removeClass(t.itemClassActive); e(i).addClass(t.itemClassActive); if (t.infinite) { e(this).css({ marginLeft: n.wrapMarginDefault }).find(".crsl-item:first-child").before(e(".crsl-item:last-child", n)) } else { if (n.wrapMargin >= n.wrapMarginDefault) e("#" + t.navigation).find(".previous").addClass("previous-inactive"); if (n.wrapWidth - n.wrapMargin == t.itemWidth * t.total) e("#" + t.navigation).find(".next").removeClass("next-inactive") } e(this).trigger("endCarousel", [t, n, s]) }) }; r.next = function (t, n) { n.wrapMargin = t.infinite ? n.wrapMarginDefault - e(n.itemActive).outerWidth(true) : n.wrapMargin - e(itemActive).outerWidth(true); var r = e(n.itemActive).index(); var i = e(n.itemActive).next(".crsl-item"); var s = "next"; e(n).trigger("beginCarousel", [t, n, s]); e(n).find(".crsl-wrap").animate({ marginLeft: n.wrapMargin + "px" }, t.speed, function () { e(n.itemActive).removeClass(t.itemClassActive); e(i).addClass(t.itemClassActive); if (t.infinite) { e(this).css({ marginLeft: n.wrapMarginDefault }).find(".crsl-item:last-child").after(e(".crsl-item:first-child", n)) } else { if (n.wrapMargin < n.wrapMarginDefault) e("#" + t.navigation).find(".previous").removeClass("previous-inactive"); if (n.wrapWidth - n.wrapMargin != t.itemWidth * t.total) e("#" + t.navigation).find(".next").addClass("next-inactive") } e(this).trigger("endCarousel", [t, n, s]) }) } }) } })(jQuery);


//jQuery mtGallery =====================================================================================================
/*
DOCUMENTATION:
USAGE: $(".module-photo-gallery").mtGallery({})
REFERENCES:
DEPENDENCIES: jQuery | imagesLoaded extension
NOTES: This extension is old and should be replaced by something better
*/
(function ($, window, document) {
    $.fn.mtGallery = function(options) {
        // Default Settings
        var defaults = {
            // CSS Namespace
            namespace: "mt-",
            // Gallery Stage Settings
            stageWrap: ".stage",
            imageWrap: ".image-wrap",
            imageTitle: ".image-title",
            imageDesc: ".image-desc",
            animation: "fade", // fade, slide
            preload: 5,
            staticWidth: true,
            staticHeight: true,
            animSpeed: 400,
            attachDetails: true,
            // Gallery Navigation Settings
            navWrap: ".thumbs",
            navElem: "img",
            activeClass: "active",
            navType: "flat", // carousel, flat, custom
            // Navigation Control Options
            addControls: true,
            useControls: true,
            nextButton: "next",
            prevButton: "prev",
            controlsAppend: false,
            // Gallery Behaviors


            // Callbacks
            onInit: function() {},
            onThumbClick: function() {},
            onNextClick: function() {},
            onPrevClick: function() {}
        };

        // Setiup gallery var and return false if it is not on the page
        var $gallery = $(this);
        if ($gallery.length == 0) return false;

        // Apply passed options, get hash, setup vars 
        var opts = $.extend( {}, defaults, options),
            deeplink = _getHash(),
            startSlide;

        // Load applicable elements
        var elements = {},
            current;

        // Initialize gallery
        init();

        // Functions
        function init() {
            // Initialize the Navigation
            elements.nav = _initNavigation();
            // Initialize the Gallery
            elements.gallery = _initGallery(elements.nav);
            // Setup Stage
            _updateStage(startSlide);
        }

        // 
        function _getHash() {
            if (window.location.hash) {
                var hash = (window.location.hash).replace("#","");
                if (!isNaN(parseFloat(hash)) && isFinite(hash)) return Math.floor(Math.abs(hash));
                else return hash;
            } else return false;
        }

        // Set the startSlide variable from the URL hash
        function _setStartSlide(nav) {
            // Set startSlide value from deeplink hash (or 0 by default)
            if (deeplink) {
                switch (typeof deeplink) {
                    case "number": if (nav.items.eq(deeplink).length > 0) startSlide = deeplink; break;
                    case "string":
                        if (nav.wrapper.find("[data-id='" + deeplink + "']") && nav.wrapper.find("[data-id='" + deeplink + "']").index() >= 0) {
                            startSlide = nav.wrapper.find("[data-id='" + deeplink + "']").index();
                        }
                        break;
                    default: startSlide = 0;
                }
            } else startSlide = 0;
            return startSlide;
        }

        function _initGallery(nav) {
            var stage = {};
            stage.wrapper = $gallery.find(opts.stageWrap);
            stage.imgWrap = stage.wrapper.find(opts.imageWrap);
            // Set image total
            stage.wrapper.find("span.total").text(nav.total);
            // Image Positioning
            var wCSS;
            if (opts.animation === "fade") wCSS = "position:absolute;top:0;left:0; display: inline-block;";
            else if (opts.animation === "slide") wCSS = "position:absolute;top:0;  display: inline-block;";
            // Add image elements
            elements.nav.items.each( function(index, element) {
                if ((startSlide === 0 && index < opts.preload) || index === startSlide || (index > (startSlide-opts.preload) && index < (startSlide+opts.preload))) {
                    stage.imgWrap.append('<div class="' + opts.namespace + 'item-wrap" style="' + (index != startSlide ? "display:none;" : "") + wCSS + '"><div><img src="' + ($(this).data("src") ? $(this).data("src") : (element.src !== undefined ? element.src : "")) + '"></div></div>');
                    _imageSize(stage.imgWrap.children().eq(index));
                } else stage.imgWrap.append('<div class="' + opts.namespace + 'item-wrap" style="display:none;' + wCSS + '"><div><img></div></div>');
            });
            // Load images into an object
            stage.items = stage.imgWrap.find("div." + opts.namespace + "item-wrap");
            // Add active class to start slide
            stage.items.eq(startSlide).addClass(opts.activeClass);
            // Setup Image Wrap
            stage.imgWrap.css({'position':'relative'});
            // Return stage objects
            return stage;
        }

        // Initialize the gallery thumbnails
        function _initNavigation() {
            var nav = {};
            nav.wrapper = $gallery.find(opts.navWrap);
            nav.items = nav.wrapper.find(opts.navElem);
            // Setup Nav
            switch (opts.navType) {
                case "carousel":
                    nav.items.css({ "float": "left" }).wrapAll('<div class="' + opts.namespace + 'carousel-inner"></div>');
                    nav.wrapper.find("." + opts.namespace + "carousel-inner").css({ "position": "relative", "width": (nav.items.outerWidth(true) * nav.items.length) }).wrap('<div class="' + opts.namespace + 'carousel-outer"></div>').find("." + opts.namespace + "carousel-outer").css({ "overflow": "hidden" });
                    nav.move = {
                        el: $("." + opts.namespace + "carousel-inner"),
                        dist: nav.items.outerWidth(true)
                    };
                    break;
                case "flat":
                    nav.items.css({ "float": "left" });
                    break;
            }
            // Add controls
            if (opts.addControls !== false && opts.useControls === true) {
                var attachTo =  (typeof opts.controlsAppend == "string" && $(opts.controlsAppend).length > 0) ? $(opts.controlsAppend) : nav.wrapper;
                attachTo.append(
                    $("<div></div>", { 'class': opts.namespace + "gallery-paging" }).append(
                        $("<a>", { 'class': opts.namespace + opts.prevButton + " disabled", text: "Previous" }),
                        $("<a>", { 'class': opts.namespace + opts.nextButton + (nav.items.length < 2 ? " disabled" : ""), text: "Next" })
                    )
                );
            }
            // Bind control actions
            if (opts.useControls === true) {
                // Bind Previous Button Action
                $("." + opts.namespace + opts.prevButton).on("click", gotoPrevious);
                // Bind Next Button Action
                $("." + opts.namespace + opts.nextButton).on("click", gotoNext);
            }
            nav.total = nav.items.length;
            nav.items.on("click", gotoItem);
            // Set appropriate thumbnail class to active on init
            nav.items.eq(_setStartSlide(nav)).addClass(opts.activeClass);
            // Return nav objects
            return nav;
        }

        // Move to a specified gallery item
        function gotoItem() {
            var item = _gotoSupport($(this).index());
            if (item.cIndex !== item.nIndex) {
                if (opts.navType === "carousel") {
                    var move = {};
                    move.direction = item.cIndex < item.nIndex ? "-=" : "+=";
                    move.distance = (Math.abs(item.cIndex - item.nIndex))*elements.nav.move.dist;
                    // Move Carousel
                    elements.nav.move.el.animate({ "left": move.direction + move.distance + "px" });
                }
                // Update Navigation Item Classes
                _navClassUpdate(item.cEl, item.nEl);
                // Update Stage
                _updateStage(item.nIndex);
            }
            // Next Event Callback
            opts.onThumbClick.call(this);
            return false;
        }

        // Move to the previous gallery item
        function gotoPrevious() {
            var item = _gotoSupport("prev");
            // Move to Next Gallery Image
            if (item.cIndex > 0) {
                // Update Navigatiom
                if (opts.navType === "carousel") elements.nav.move.el.animate({ "left": "+=" + elements.nav.move.dist + "px" });
                // Update Navigation Item Classes
                _navClassUpdate(item.cEl, item.nEl);
                // Update Stage
                _updateStage(item.nIndex);
            }
            // Prev Event Callback
            opts.onPrevClick.call(this);
            return false;
        }
        
        // Move to the next gallery item
        function gotoNext() {
            var item = _gotoSupport("next");
            // Move to Next Gallery Image
            if (item.cIndex < (elements.nav.items.length-1)) {
                // Update Navigatiom
                if (opts.navType === "carousel") elements.nav.move.el.animate({ "left": "-=" + elements.nav.move.dist + "px" });
                // Update Navigation Item Classes
                _navClassUpdate(item.cEl, item.nEl);
                // Update Stage
                _updateStage(item.nIndex);
            }
            // Next Event Callback
            opts.onNextClick.call(this);
            return false;
        }

        // Return Indexes and Elements for current and next gallery items
        function _gotoSupport(item) {
            var data = {};
            data.cIndex = elements.nav.items.index($(opts.navWrap + " > ." + opts.activeClass));
            data.cEl = elements.nav.items.eq(data.cIndex);
            data.nIndex = item === "prev" ? data.cIndex - 1 : (item === "next" ? data.cIndex + 1 : item);
            data.nEl = elements.nav.items.eq(data.nIndex);
            _getImageSrc(data.nIndex);
            return data;
        }

        // Update the active class on the navigation items
        function _navClassUpdate(currentEl, nextEl) {
            nextEl.addClass(opts.activeClass);
            currentEl.removeClass(opts.activeClass);
        }

        function _updateStage(index) {
            // If current/next are the same, exit
            if (current === index) return false;
            // Start image preload
            _preLoad(index);
            // Set variables
            var $item = elements.nav.items.eq(index),
                $current = elements.gallery.items.eq(current),
                $next = elements.gallery.items.eq(index),
                title = $item.data("title") !== undefined ? $item.data("title") : "",
                description = $item.data("description") !== undefined ? $item.data("description") : "";
            // Size Image
            _imageSize($next);
            // Update title, description, and image count
            if (opts.attachDetails === true) $next.find("img").parent().css({ "position": "relative" }).append($(".image-overlay"));
            $(opts.imageTitle).html(title);
            $(opts.imageDesc).html(description);
            $(opts.stageWrap).find("span.current").text(index+1);
            // Animate Slides
            switch (opts.animation) {
                case "fade":
                    $next.fadeIn(opts.animSpeed).addClass(opts.activeClass);
                    $current.fadeOut(opts.animSpeed).removeClass(opts.activeClass);
                    break;
                case "push":
                    if (index < elements.nav.items.index("." + opts.activeClass)) {
                        var nCSS = { "left": "100%", "right": "auto", "display": "block" },
                            nAnim = { "left": "0", "right": "auto", "display": "block" },
                            cAnim = { "right": "100%", "left": "auto", "display": "none" };
                    } else {
                        var nCSS = { "right": "100%", "right": "auto", "display": "block" },
                            nAnim = { "right": "0", "right": "auto", "display": "block" },
                            cAnim = { "left": "100%", "left": "auto", "display": "none" };
                    }
                    $next.css(nCSS).animate(nAnim).addClass(opts.activeClass);
                    $current.animate(cAnim).removeClass(opts.activeClass);
                    break;
            }
            //if (opts.staticWidth && opts.staticHeight) $gallery.find(".image-overlay").css({ "width": size.width + "px" });
            current = index;
        }

        function _scaleImage(img,orig) {
            var size = {};
            // Set new image size
            switch (true) {
                case opts.staticWidth && opts.staticHeight:
                    var wS = elements.gallery.imgWrap.width()/orig.width,
                        hS = elements.gallery.imgWrap.height()/orig.height,
                        ratio = wS <= hS ? wS : hS;
                    size.width = Math.round(orig.width*ratio);
                    size.height = Math.round(orig.height*ratio);
                    img.css({ "width": size.width + "px", "height": "100%" }).parent().css({ "width": size.width + "px", "height": size.height + "px" });
                    break;
                case opts.staticWidth:
                    size.width = elements.gallery.imgWrap.width();
                    size.height = Math.round(orig.ratio*size.width);
                    img.css({ "width": size.width + "px", "height": "100%" }).parent().css({ "height": size.height + "px" });
                    $gallery.find(opts.imageWrap).css({"height":size.height});
                    break;
                case opts.staticHeight:
                    var ratio = orig.width/orig.height;
                    size.height = elements.gallery.imgWrap.height();
                    size.width = Math.round(ratio*size.height);
                    img.css({ "width": size.width + "px", "height": "100%" }).parent().css({ "width": size.width + "px" });
                    break;
                default:
                    var biggerSide = orig.width >= orig.height ? "w" : "h",
                        wS = elements.gallery.imgWrap.width()/orig.width,
                        hS = elements.gallery.imgWrap.height()/orig.height,
                        ratio = wS <= hS ? wS : hS,
                        wrapCSS = {};
                    size.width = biggerSide === "w" ? "100%" : "auto";
                    size.height = biggerSide === "w" ? "auto" : "100%";
                    wrapCSS.width = biggerSide === "w" ? "100%" : "";
                    wrapCSS.height = biggerSide === "w" ? "" : "100%";
                    img.css({ "width": size.width, "height": size.height }).parents(opts.imageWrap).css({});
            }
            return size;
        }

        function _imageSize(el) {
            var orig = {},
                $img = el.find("img"),
                test = new Image();
            // Get Image Size and Determine Ratio
            switch (true) {
                case (el.data("processed") == true && el.data("ratio") > 0):
                    orig.width = el.data("width");
                    orig.height = el.data("height");
                    orig.ratio = el.data("ratio");
                    return _scaleImage($img,orig);
                default:
                    test.src = $img.attr("src");
                    imagesLoaded( test, function() {
                        orig.width = test.width;
                        orig.height = test.height;
                        orig.ratio = orig.height/orig.width;
                        el.attr({ "data-ratio": orig.ratio, "data-width": orig.width, "data-height": orig.height, "data-processed": true });
                        return _scaleImage($img,orig);
                    });
            }
        }

        function _getImageSrc(index) {
            return elements.nav.items.eq(index).data("src") !== undefined ? elements.nav.items.eq(index).data("src") : elements.nav.items.eq(index).attr("src");
        }
        
        function _preLoad(index,init) {
           // Check if image source is loaded for selected image, if not load
            if (elements.gallery.items.eq(index).find("img").attr("src") === undefined) {
                elements.gallery.items.eq(index).find("img").attr("src", _getImageSrc(index));
                _imageSize(elements.gallery.items.eq(index));
            }
            // Determine appropriate starting image index for pre-loading
            var plStart;
            switch (true) {
                case index === 0: plStart = 0; break;
                case (index-(Math.ceil(opts.preload/2))) < 0: plStart = 0; break;
                default: plStart = (index-(Math.ceil(opts.preload/2)));
            }
            var i = plStart,
                l = i + opts.preload;
            // Check if image is loaded, if not load it
            for (; i<l; i++) {
                if (elements.gallery.items.eq(i).find("img").attr("src") === undefined) {
                    elements.gallery.items.eq(i).find("img").attr("src", _getImageSrc(i));
                    _imageSize(elements.gallery.items.eq(i));
                } else l++;
            }
        }

    };
})(jQuery, window, document);

//jQuery mtSlider extension ===========================================================================================
/*
DOCUMENTATION
USAGE:  $('.mtslide').mtslider({});
REFERENCES: Landing Slider Module
DEPENDENCIES: jQuery
NOTES: Patrick 8/26: Has some touch capability, but overall should be upgraded soon
*/
(function (e, window, document) {
    e.mtslider = function (t, n) {
        var r = e(t);
        r.vars = e.extend({}, e.mtslider.defaults, n);
        var i = r.vars.namespace,
            s = window.navigator && window.navigator.msPointerEnabled && window.MSGesture,
            o = ("ontouchstart" in window || s || window.DocumentTouch && document instanceof DocumentTouch) && r.vars.touch,
            u = "click touchend MSPointerUp",
            a = "",
            f, l = r.vars.direction === "vertical",
            c = r.vars.reverse,
            h = r.vars.itemWidth > 0,
            p = r.vars.animation === "fade",
            d = r.vars.asNavFor !== "",
            v = {}, m = !0;
        e.data(t, "mtslider", r);
        v = {
            init: function () {
                r.animating = !1;
                r.currentSlide = parseInt(r.vars.startAt ? r.vars.startAt : 0);
                isNaN(r.currentSlide) && (r.currentSlide = 0);
                r.animatingTo = r.currentSlide;
                r.atEnd = r.currentSlide === 0 || r.currentSlide === r.last;
                r.containerSelector = r.vars.selector.substr(0, r.vars.selector.search(" "));
                r.slides = e(r.vars.selector, r);
                r.container = e(r.containerSelector, r);
                r.count = r.slides.length;
                r.syncExists = e(r.vars.sync).length > 0;
                r.vars.animation === "slide" && (r.vars.animation = "swing");
                r.prop = l ? "top" : "marginLeft";
                r.args = {};
                r.manualPause = !1;
                r.stopped = !1;
                r.started = !1;
                r.startTimeout = null;
                r.transitions = !r.vars.video && !p && r.vars.useCSS && function () {
                    var e = document.createElement("div"),
                        t = ["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"];
                    for (var n in t)
                        if (e.style[t[n]] !== undefined) {
                            r.pfx = t[n].replace("Perspective", "").toLowerCase();
                            r.prop = "-" + r.pfx + "-transform";
                            return !0
                        }
                    return !1
                }();
                r.vars.controlsContainer !== "" && (r.controlsContainer = e(r.vars.controlsContainer).length > 0 && e(r.vars.controlsContainer));
                r.vars.manualControls !== "" && (r.manualControls = e(r.vars.manualControls).length > 0 && e(r.vars.manualControls));
                if (r.vars.randomize) {
                    r.slides.sort(function () {
                        return Math.round(Math.random()) - .5
                    });
                    r.container.empty().append(r.slides)
                }
                r.doMath();
                r.setup("init");
                r.vars.controlNav && v.controlNav.setup();
                r.vars.directionNav && v.directionNav.setup();
                r.vars.keyboard && (e(r.containerSelector).length === 1 || r.vars.multipleKeyboard) && e(document).bind("keyup", function (e) {
                    var t = e.keyCode;
                    if (!r.animating && (t === 39 || t === 37)) {
                        var n = t === 39 ? r.getTarget("next") : t === 37 ? r.getTarget("prev") : !1;
                        r.mtAnimate(n, r.vars.pauseOnAction)
                    }
                });
                r.vars.mousewheel && r.bind("mousewheel", function (e, t, n, i) {
                    e.preventDefault();
                    var s = t < 0 ? r.getTarget("next") : r.getTarget("prev");
                    r.mtAnimate(s, r.vars.pauseOnAction)
                });
                r.vars.pausePlay && v.pausePlay.setup();
                r.vars.slideshow && r.vars.pauseInvisible && v.pauseInvisible.init();
                if (r.vars.slideshow) {
                    r.vars.pauseOnHover && r.hover(function () {
                        !r.manualPlay && !r.manualPause && r.pause()
                    }, function () {
                        !r.manualPause && !r.manualPlay && !r.stopped && r.play()
                    });
                    if (!r.vars.pauseInvisible || !v.pauseInvisible.isHidden()) r.vars.initDelay > 0 ? r.startTimeout = setTimeout(r.play, r.vars.initDelay) : r.play()
                }
                d && v.asNav.setup();
                o && r.vars.touch && v.touch();
                (!p || p && r.vars.smoothHeight) && e(window).bind("resize orientationchange focus", v.resize);
                r.find("img").attr("draggable", "false");
                setTimeout(function () {
                    r.vars.start(r)
                }, 200)
            },
            asNav: {
                setup: function () {
                    r.asNav = !0;
                    r.animatingTo = Math.floor(r.currentSlide / r.move);
                    r.currentItem = r.currentSlide;
                    r.slides.removeClass(i + "active-slide").eq(r.currentItem).addClass(i + "active-slide");
                    if (!s) r.slides.click(function (t) {
                        t.preventDefault();
                        var n = e(this),
                            s = n.index(),
                            o = n.offset().left - e(r).scrollLeft();
                        if (o <= 0 && n.hasClass(i + "active-slide")) r.mtAnimate(r.getTarget("prev"), !0);
                        else if (!e(r.vars.asNavFor).data("mtslider").animating && !n.hasClass(i + "active-slide")) {
                            r.direction = r.currentItem < s ? "next" : "prev";
                            r.mtAnimate(s, r.vars.pauseOnAction, !1, !0, !0)
                        }
                    });
                    else {
                        t._slider = r;
                        r.slides.each(function () {
                            var t = this;
                            t._gesture = new MSGesture;
                            t._gesture.target = t;
                            t.addEventListener("MSPointerDown", function (e) {
                                e.preventDefault();
                                e.currentTarget._gesture && e.currentTarget._gesture.addPointer(e.pointerId)
                            }, !1);
                            t.addEventListener("MSGestureTap", function (t) {
                                t.preventDefault();
                                var n = e(this),
                                    i = n.index();
                                if (!e(r.vars.asNavFor).data("mtslider").animating && !n.hasClass("active")) {
                                    r.direction = r.currentItem < i ? "next" : "prev";
                                    r.mtAnimate(i, r.vars.pauseOnAction, !1, !0, !0)
                                }
                            })
                        })
                    }
                }
            },
            controlNav: {
                setup: function () {
                    r.manualControls ? v.controlNav.setupManual() : v.controlNav.setupPaging()
                },
                setupPaging: function () {
                    var t = r.vars.controlNav === "thumbnails" ? "control-thumbs" : "control-paging",
                        n = 1,
                        s, o;
                    r.controlNavScaffold = e('<ol class="' + i + "control-nav " + i + t + '"></ol>');
                    if (r.pagingCount > 1)
                        for (var f = 0; f < r.pagingCount; f++) {
                            o = r.slides.eq(f);
                            s = r.vars.controlNav === "thumbnails" ? '<img src="' + o.attr("data-thumb") + '"/>' : "<a>" + n + "</a>";
                            if ("thumbnails" === r.vars.controlNav && !0 === r.vars.thumbCaptions) {
                                var l = o.attr("data-thumbcaption");
                                "" != l && undefined != l && (s += '<span class="' + i + 'caption">' + l + "</span>")
                            }
                            r.controlNavScaffold.append("<li>" + s + "</li>");
                            n++
                        }
                    r.controlsContainer ? e(r.controlsContainer).append(r.controlNavScaffold) : r.append(r.controlNavScaffold);
                    v.controlNav.set();
                    v.controlNav.active();
                    r.controlNavScaffold.delegate("a, img", u, function (t) {
                        t.preventDefault();
                        if (a === "" || a === t.type) {
                            var n = e(this),
                                s = r.controlNav.index(n);
                            if (!n.hasClass(i + "active")) {
                                r.direction = s > r.currentSlide ? "next" : "prev";
                                r.mtAnimate(s, r.vars.pauseOnAction)
                            }
                        }
                        a === "" && (a = t.type);
                        v.setToClearWatchedEvent()
                    })
                },
                setupManual: function () {
                    r.controlNav = r.manualControls;
                    v.controlNav.active();
                    r.controlNav.bind(u, function (t) {
                        t.preventDefault();
                        if (a === "" || a === t.type) {
                            var n = e(this),
                                s = r.controlNav.index(n);
                            if (!n.hasClass(i + "active")) {
                                s > r.currentSlide ? r.direction = "next" : r.direction = "prev";
                                r.mtAnimate(s, r.vars.pauseOnAction)
                            }
                        }
                        a === "" && (a = t.type);
                        v.setToClearWatchedEvent()
                    })
                },
                set: function () {
                    var t = r.vars.controlNav === "thumbnails" ? "img" : "a";
                    r.controlNav = e("." + i + "control-nav li " + t, r.controlsContainer ? r.controlsContainer : r)
                },
                active: function () {
                    r.controlNav.removeClass(i + "active").eq(r.animatingTo).addClass(i + "active")
                },
                update: function (t, n) {
                    r.pagingCount > 1 && t === "add" ? r.controlNavScaffold.append(e("<li><a>" + r.count + "</a></li>")) : r.pagingCount === 1 ? r.controlNavScaffold.find("li").remove() : r.controlNav.eq(n).closest("li").remove();
                    v.controlNav.set();
                    r.pagingCount > 1 && r.pagingCount !== r.controlNav.length ? r.update(n, t) : v.controlNav.active()
                }
            },
            directionNav: {
                setup: function () {
                    var t = e('<ul class="' + i + 'direction-nav"><li><a class="' + i + 'prev" href="#">' + r.vars.prevText + '</a></li><li><a class="' + i + 'next" href="#">' + r.vars.nextText + "</a></li></ul>");
                    if (r.controlsContainer) {
                        e(r.controlsContainer).append(t);
                        r.directionNav = e("." + i + "direction-nav li a", r.controlsContainer)
                    } else {
                        r.append(t);
                        r.directionNav = e("." + i + "direction-nav li a", r)
                    }
                    v.directionNav.update();
                    r.directionNav.bind(u, function (t) {
                        t.preventDefault();
                        var n;
                        if (a === "" || a === t.type) {
                            n = e(this).hasClass(i + "next") ? r.getTarget("next") : r.getTarget("prev");
                            r.mtAnimate(n, r.vars.pauseOnAction)
                        }
                        a === "" && (a = t.type);
                        v.setToClearWatchedEvent()
                    })
                },
                update: function () {
                    var e = i + "disabled";
                    r.pagingCount === 1 ? r.directionNav.addClass(e).attr("tabindex", "-1") : r.vars.animationLoop ? r.directionNav.removeClass(e).removeAttr("tabindex") : r.animatingTo === 0 ? r.directionNav.removeClass(e).filter("." + i + "prev").addClass(e).attr("tabindex", "-1") : r.animatingTo === r.last ? r.directionNav.removeClass(e).filter("." + i + "next").addClass(e).attr("tabindex", "-1") : r.directionNav.removeClass(e).removeAttr("tabindex")
                }
            },
            pausePlay: {
                setup: function () {
                    var t = e('<div class="' + i + 'pauseplay"><a></a></div>');
                    if (r.controlsContainer) {
                        r.controlsContainer.append(t);
                        r.pausePlay = e("." + i + "pauseplay a", r.controlsContainer)
                    } else {
                        r.append(t);
                        r.pausePlay = e("." + i + "pauseplay a", r)
                    }
                    v.pausePlay.update(r.vars.slideshow ? i + "pause" : i + "play");
                    r.pausePlay.bind(u, function (t) {
                        t.preventDefault();
                        if (a === "" || a === t.type)
                            if (e(this).hasClass(i + "pause")) {
                                r.manualPause = !0;
                                r.manualPlay = !1;
                                r.pause()
                            } else {
                                r.manualPause = !1;
                                r.manualPlay = !0;
                                r.play()
                            }
                        a === "" && (a = t.type);
                        v.setToClearWatchedEvent()
                    })
                },
                update: function (e) {
                    e === "play" ? r.pausePlay.removeClass(i + "pause").addClass(i + "play").html(r.vars.playText) : r.pausePlay.removeClass(i + "play").addClass(i + "pause").html(r.vars.pauseText)
                }
            },
            touch: function () {
                var e, n, i, o, u, a, f = !1,
                    d = 0,
                    v = 0,
                    m = 0;
                if (!s) {
                    t.addEventListener("touchstart", g, !1);

                    function g(s) {
                        if (r.animating) s.preventDefault();
                        else if (window.navigator.msPointerEnabled || s.touches.length === 1) {
                            r.pause();
                            o = l ? r.h : r.w;
                            a = Number(new Date);
                            d = s.touches[0].pageX;
                            v = s.touches[0].pageY;
                            i = h && c && r.animatingTo === r.last ? 0 : h && c ? r.limit - (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo : h && r.currentSlide === r.last ? r.limit : h ? (r.itemW + r.vars.itemMargin) * r.move * r.currentSlide : c ? (r.last - r.currentSlide + r.cloneOffset) * o : (r.currentSlide + r.cloneOffset) * o;
                            e = l ? v : d;
                            n = l ? d : v;
                            t.addEventListener("touchmove", y, !1);
                            t.addEventListener("touchend", b, !1)
                        }
                    }

                    function y(t) {
                        d = t.touches[0].pageX;
                        v = t.touches[0].pageY;
                        u = l ? e - v : e - d;
                        f = l ? Math.abs(u) < Math.abs(d - n) : Math.abs(u) < Math.abs(v - n);
                        var s = 500;
                        if (!f || Number(new Date) - a > s) {
                            t.preventDefault();
                            if (!p && r.transitions) {
                                r.vars.animationLoop || (u /= r.currentSlide === 0 && u < 0 || r.currentSlide === r.last && u > 0 ? Math.abs(u) / o + 2 : 1);
                                r.setProps(i + u, "setTouch")
                            }
                        }
                    }

                    function b(s) {
                        t.removeEventListener("touchmove", y, !1);
                        if (r.animatingTo === r.currentSlide && !f && u !== null) {
                            var l = c ? -u : u,
                                h = l > 0 ? r.getTarget("next") : r.getTarget("prev");
                            r.canAdvance(h) && (Number(new Date) - a < 550 && Math.abs(l) > 50 || Math.abs(l) > o / 2) ? r.mtAnimate(h, r.vars.pauseOnAction) : p || r.mtAnimate(r.currentSlide, r.vars.pauseOnAction, !0)
                        }
                        t.removeEventListener("touchend", b, !1);
                        e = null;
                        n = null;
                        u = null;
                        i = null
                    }
                } else {
                    t.style.msTouchAction = "none";
                    t._gesture = new MSGesture;
                    t._gesture.target = t;
                    t.addEventListener("MSPointerDown", w, !1);
                    t._slider = r;
                    t.addEventListener("MSGestureChange", E, !1);
                    t.addEventListener("MSGestureEnd", S, !1);

                    function w(e) {
                        e.stopPropagation();
                        if (r.animating) e.preventDefault();
                        else {
                            r.pause();
                            t._gesture.addPointer(e.pointerId);
                            m = 0;
                            o = l ? r.h : r.w;
                            a = Number(new Date);
                            i = h && c && r.animatingTo === r.last ? 0 : h && c ? r.limit - (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo : h && r.currentSlide === r.last ? r.limit : h ? (r.itemW + r.vars.itemMargin) * r.move * r.currentSlide : c ? (r.last - r.currentSlide + r.cloneOffset) * o : (r.currentSlide + r.cloneOffset) * o
                        }
                    }

                    function E(e) {
                        e.stopPropagation();
                        var n = e.target._slider;
                        if (!n) return;
                        var r = -e.translationX,
                            s = -e.translationY;
                        m += l ? s : r;
                        u = m;
                        f = l ? Math.abs(m) < Math.abs(-r) : Math.abs(m) < Math.abs(-s);
                        if (e.detail === e.MSGESTURE_FLAG_INERTIA) {
                            setImmediate(function () {
                                t._gesture.stop()
                            });
                            return
                        }
                        if (!f || Number(new Date) - a > 500) {
                            e.preventDefault();
                            if (!p && n.transitions) {
                                n.vars.animationLoop || (u = m / (n.currentSlide === 0 && m < 0 || n.currentSlide === n.last && m > 0 ? Math.abs(m) / o + 2 : 1));
                                n.setProps(i + u, "setTouch")
                            }
                        }
                    }

                    function S(t) {
                        t.stopPropagation();
                        var r = t.target._slider;
                        if (!r) return;
                        if (r.animatingTo === r.currentSlide && !f && u !== null) {
                            var s = c ? -u : u,
                                l = s > 0 ? r.getTarget("next") : r.getTarget("prev");
                            r.canAdvance(l) && (Number(new Date) - a < 550 && Math.abs(s) > 50 || Math.abs(s) > o / 2) ? r.mtAnimate(l, r.vars.pauseOnAction) : p || r.mtAnimate(r.currentSlide, r.vars.pauseOnAction, !0)
                        }
                        e = null;
                        n = null;
                        u = null;
                        i = null;
                        m = 0
                    }
                }
            },
            resize: function () {
                if (!r.animating && r.is(":visible")) {
                    h || r.doMath();
                    if (p) v.smoothHeight();
                    else if (h) {
                        r.slides.width(r.computedW);
                        r.update(r.pagingCount);
                        r.setProps()
                    } else if (l) {
                        r.viewport.height(r.h);
                        r.setProps(r.h, "setTotal")
                    } else {
                        r.vars.smoothHeight && v.smoothHeight();
                        r.newSlides.width(r.computedW);
                        r.setProps(r.computedW, "setTotal")
                    }
                }
            },
            smoothHeight: function (e) {
                if (!l || p) {
                    var t = p ? r : r.viewport;
                    e ? t.animate({
                        height: r.slides.eq(r.animatingTo).height()
                    }, e) : t.height(r.slides.eq(r.animatingTo).height())
                }
            },
            sync: function (t) {
                var n = e(r.vars.sync).data("mtslider"),
                    i = r.animatingTo;
                switch (t) {
                case "animate":
                    n.mtAnimate(i, r.vars.pauseOnAction, !1, !0);
                    break;
                case "play":
                    !n.playing && !n.asNav && n.play();
                    break;
                case "pause":
                    n.pause()
                }
            },
            pauseInvisible: {
                visProp: null,
                init: function () {
                    var e = ["webkit", "moz", "ms", "o"];
                    if ("hidden" in document) return "hidden";
                    for (var t = 0; t < e.length; t++) e[t] + "Hidden" in document && (v.pauseInvisible.visProp = e[t] + "Hidden");
                    if (v.pauseInvisible.visProp) {
                        var n = v.pauseInvisible.visProp.replace(/[H|h]idden/, "") + "visibilitychange";
                        document.addEventListener(n, function () {
                            v.pauseInvisible.isHidden() ? r.startTimeout ? clearTimeout(r.startTimeout) : r.pause() : r.started ? r.play() : r.vars.initDelay > 0 ? setTimeout(r.play, r.vars.initDelay) : r.play()
                        })
                    }
                },
                isHidden: function () {
                    return document[v.pauseInvisible.visProp] || !1
                }
            },
            setToClearWatchedEvent: function () {
                clearTimeout(f);
                f = setTimeout(function () {
                    a = ""
                }, 3e3)
            }
        };
        r.mtAnimate = function (t, n, s, u, a) {
            !r.vars.animationLoop && t !== r.currentSlide && (r.direction = t > r.currentSlide ? "next" : "prev");
            d && r.pagingCount === 1 && (r.direction = r.currentItem < t ? "next" : "prev");
            if (!r.animating && (r.canAdvance(t, a) || s) && r.is(":visible")) {
                if (d && u) {
                    var f = e(r.vars.asNavFor).data("mtslider");
                    r.atEnd = t === 0 || t === r.count - 1;
                    f.mtAnimate(t, !0, !1, !0, a);
                    r.direction = r.currentItem < t ? "next" : "prev";
                    f.direction = r.direction;
                    if (Math.ceil((t + 1) / r.visible) - 1 === r.currentSlide || t === 0) {
                        r.currentItem = t;
                        r.slides.removeClass(i + "active-slide").eq(t).addClass(i + "active-slide");
                        return !1
                    }
                    r.currentItem = t;
                    r.slides.removeClass(i + "active-slide").eq(t).addClass(i + "active-slide");
                    t = Math.floor(t / r.visible)
                }
                r.animating = !0;
                r.animatingTo = t;
                n && r.pause();
                r.vars.before(r);
                r.syncExists && !a && v.sync("animate");
                r.vars.controlNav && v.controlNav.active();
                h || r.slides.removeClass(i + "active-slide").eq(t).addClass(i + "active-slide");
                r.atEnd = t === 0 || t === r.last;
                r.vars.directionNav && v.directionNav.update();
                if (t === r.last) {
                    r.vars.end(r);
                    r.vars.animationLoop || r.pause()
                }
                if (!p) {
                    var m = l ? r.slides.filter(":first").height() : r.computedW,
                        g, y, b;
                    if (h) {
                        g = r.vars.itemMargin;
                        b = (r.itemW + g) * r.move * r.animatingTo;
                        y = b > r.limit && r.visible !== 1 ? r.limit : b
                    } else r.currentSlide === 0 && t === r.count - 1 && r.vars.animationLoop && r.direction !== "next" ? y = c ? (r.count + r.cloneOffset) * m : 0 : r.currentSlide === r.last && t === 0 && r.vars.animationLoop && r.direction !== "prev" ? y = c ? 0 : (r.count + 1) * m : y = c ? (r.count - 1 - t + r.cloneOffset) * m : (t + r.cloneOffset) * m;
                    r.setProps(y, "", r.vars.animationSpeed);
                    if (r.transitions) {
                        if (!r.vars.animationLoop || !r.atEnd) {
                            r.animating = !1;
                            r.currentSlide = r.animatingTo
                        }
                        r.container.unbind("webkitTransitionEnd transitionend");
                        r.container.bind("webkitTransitionEnd transitionend", function () {
                            r.wrapup(m)
                        })
                    } else r.container.animate(r.args, r.vars.animationSpeed, r.vars.easing, function () {
                        r.wrapup(m)
                    })
                } else if (!o) {
                    r.slides.eq(r.currentSlide).css({
                        zIndex: 1
                    }).animate({
                        opacity: 0
                    }, r.vars.animationSpeed, r.vars.easing);
                    r.slides.eq(t).css({
                        zIndex: 2
                    }).animate({
                        opacity: 1
                    }, r.vars.animationSpeed, r.vars.easing, r.wrapup)
                } else {
                    r.slides.eq(r.currentSlide).css({
                        opacity: 0,
                        zIndex: 1
                    });
                    r.slides.eq(t).css({
                        opacity: 1,
                        zIndex: 2
                    });
                    r.wrapup(m)
                }
                r.vars.smoothHeight && v.smoothHeight(r.vars.animationSpeed)
            }
        };
        r.wrapup = function (e) {
            !p && !h && (r.currentSlide === 0 && r.animatingTo === r.last && r.vars.animationLoop ? r.setProps(e, "jumpEnd") : r.currentSlide === r.last && r.animatingTo === 0 && r.vars.animationLoop && r.setProps(e, "jumpStart"));
            r.animating = !1;
            r.currentSlide = r.animatingTo;
            r.vars.after(r)
        };
        r.animateSlides = function () {
            !r.animating && m && r.mtAnimate(r.getTarget("next"))
        };
        r.pause = function () {
            clearInterval(r.animatedSlides);
            r.animatedSlides = null;
            r.playing = !1;
            r.vars.pausePlay && v.pausePlay.update("play");
            r.syncExists && v.sync("pause")
        };
        r.play = function () {
            r.playing && clearInterval(r.animatedSlides);
            r.animatedSlides = r.animatedSlides || setInterval(r.animateSlides, r.vars.slideshowSpeed);
            r.started = r.playing = !0;
            r.vars.pausePlay && v.pausePlay.update("pause");
            r.syncExists && v.sync("play")
        };
        r.stop = function () {
            r.pause();
            r.stopped = !0
        };
        r.canAdvance = function (e, t) {
            var n = d ? r.pagingCount - 1 : r.last;
            return t ? !0 : d && r.currentItem === r.count - 1 && e === 0 && r.direction === "prev" ? !0 : d && r.currentItem === 0 && e === r.pagingCount - 1 && r.direction !== "next" ? !1 : e === r.currentSlide && !d ? !1 : r.vars.animationLoop ? !0 : r.atEnd && r.currentSlide === 0 && e === n && r.direction !== "next" ? !1 : r.atEnd && r.currentSlide === n && e === 0 && r.direction === "next" ? !1 : !0
        };
        r.getTarget = function (e) {
            r.direction = e;
            return e === "next" ? r.currentSlide === r.last ? 0 : r.currentSlide + 1 : r.currentSlide === 0 ? r.last : r.currentSlide - 1
        };
        r.setProps = function (e, t, n) {
            var i = function () {
                var n = e ? e : (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo,
                    i = function () {
                        if (h) return t === "setTouch" ? e : c && r.animatingTo === r.last ? 0 : c ? r.limit - (r.itemW + r.vars.itemMargin) * r.move * r.animatingTo : r.animatingTo === r.last ? r.limit : n;
                        switch (t) {
                        case "setTotal":
                            return c ? (r.count - 1 - r.currentSlide + r.cloneOffset) * e : (r.currentSlide + r.cloneOffset) * e;
                        case "setTouch":
                            return c ? e : e;
                        case "jumpEnd":
                            return c ? e : r.count * e;
                        case "jumpStart":
                            return c ? r.count * e : e;
                        default:
                            return e
                        }
                    }();
                return i * -1 + "px"
            }();
            if (r.transitions) {
                i = l ? "translate3d(0," + i + ",0)" : "translate3d(" + i + ",0,0)";
                n = n !== undefined ? n / 1e3 + "s" : "0s";
                r.container.css("-" + r.pfx + "-transition-duration", n)
            }
            r.args[r.prop] = i;
            (r.transitions || n === undefined) && r.container.css(r.args)
        };
        r.setup = function (t) {
            if (!p) {
                var n, s;
                if (t === "init") {
                    r.viewport = e('<div class="' + i + 'viewport"></div>').css({
                        overflow: "hidden",
                        position: "relative"
                    }).appendTo(r).append(r.container);
                    r.cloneCount = 0;
                    r.cloneOffset = 0;
                    if (c) {
                        s = e.makeArray(r.slides).reverse();
                        r.slides = e(s);
                        r.container.empty().append(r.slides)
                    }
                }
                if (r.vars.animationLoop && !h) {
                    r.cloneCount = 2;
                    r.cloneOffset = 1;
                    t !== "init" && r.container.find(".clone").remove();
                    r.container.append(r.slides.first().clone().addClass("clone").attr("aria-hidden", "true")).prepend(r.slides.last().clone().addClass("clone").attr("aria-hidden", "true"))
                }
                r.newSlides = e(r.vars.selector, r);
                n = c ? r.count - 1 - r.currentSlide + r.cloneOffset : r.currentSlide + r.cloneOffset;
                if (l && !h) {
                    r.container.height((r.count + r.cloneCount) * 200 + "%").css("position", "absolute").width("100%");
                    setTimeout(function () {
                        r.newSlides.css({
                            display: "block"
                        });
                        r.doMath();
                        r.viewport.height(r.h);
                        r.setProps(n * r.h, "init")
                    }, t === "init" ? 100 : 0)
                } else {
                    r.container.width((r.count + r.cloneCount) * 200 + "%");
                    r.setProps(n * r.computedW, "init");
                    setTimeout(function () {
                        r.doMath();
                        r.newSlides.css({
                            width: r.computedW,
                            "float": "left",
                            display: "block"
                        });
                        r.vars.smoothHeight && v.smoothHeight()
                    }, t === "init" ? 100 : 0)
                }
            } else {
                r.slides.css({
                    width: "100%",
                    "float": "left",
                    marginRight: "-100%",
                    position: "relative"
                });
                t === "init" && (o ? r.slides.css({
                    opacity: 0,
                    display: "block",
                    webkitTransition: "opacity " + r.vars.animationSpeed / 1e3 + "s ease",
                    zIndex: 1
                }).eq(r.currentSlide).css({
                    opacity: 1,
                    zIndex: 2
                }) : r.slides.css({
                    opacity: 0,
                    display: "block",
                    zIndex: 1
                }).eq(r.currentSlide).css({
                    zIndex: 2
                }).animate({
                    opacity: 1
                }, r.vars.animationSpeed, r.vars.easing));
                r.vars.smoothHeight && v.smoothHeight()
            }
            h || r.slides.removeClass(i + "active-slide").eq(r.currentSlide).addClass(i + "active-slide")
        };
        r.doMath = function () {
            var e = r.slides.first(),
                t = r.vars.itemMargin,
                n = r.vars.minItems,
                i = r.vars.maxItems;
            r.w = r.viewport === undefined ? r.width() : r.viewport.width();
            r.h = e.height();
            r.boxPadding = e.outerWidth() - e.width();
            if (h) {
                r.itemT = r.vars.itemWidth + t;
                r.minW = n ? n * r.itemT : r.w;
                r.maxW = i ? i * r.itemT - t : r.w;
                r.itemW = r.minW > r.w ? (r.w - t * (n - 1)) / n : r.maxW < r.w ? (r.w - t * (i - 1)) / i : r.vars.itemWidth > r.w ? r.w : r.vars.itemWidth;
                r.visible = Math.floor(r.w / r.itemW);
                r.move = r.vars.move > 0 && r.vars.move < r.visible ? r.vars.move : r.visible;
                r.pagingCount = Math.ceil((r.count - r.visible) / r.move + 1);
                r.last = r.pagingCount - 1;
                r.limit = r.pagingCount === 1 ? 0 : r.vars.itemWidth > r.w ? r.itemW * (r.count - 1) + t * (r.count - 1) : (r.itemW + t) * r.count - r.w - t
            } else {
                r.itemW = r.w;
                r.pagingCount = r.count;
                r.last = r.count - 1
            }
            r.computedW = r.itemW - r.boxPadding
        };
        r.update = function (e, t) {
            r.doMath();
            if (!h) {
                e < r.currentSlide ? r.currentSlide += 1 : e <= r.currentSlide && e !== 0 && (r.currentSlide -= 1);
                r.animatingTo = r.currentSlide
            }
            if (r.vars.controlNav && !r.manualControls)
                if (t === "add" && !h || r.pagingCount > r.controlNav.length) v.controlNav.update("add");
                else if (t === "remove" && !h || r.pagingCount < r.controlNav.length) {
                if (h && r.currentSlide > r.last) {
                    r.currentSlide -= 1;
                    r.animatingTo -= 1
                }
                v.controlNav.update("remove", r.last)
            }
            r.vars.directionNav && v.directionNav.update()
        };
        r.addSlide = function (t, n) {
            var i = e(t);
            r.count += 1;
            r.last = r.count - 1;
            l && c ? n !== undefined ? r.slides.eq(r.count - n).after(i) : r.container.prepend(i) : n !== undefined ? r.slides.eq(n).before(i) : r.container.append(i);
            r.update(n, "add");
            r.slides = e(r.vars.selector + ":not(.clone)", r);
            r.setup();
            r.vars.added(r)
        };
        r.removeSlide = function (t) {
            var n = isNaN(t) ? r.slides.index(e(t)) : t;
            r.count -= 1;
            r.last = r.count - 1;
            isNaN(t) ? e(t, r.slides).remove() : l && c ? r.slides.eq(r.last).remove() : r.slides.eq(t).remove();
            r.doMath();
            r.update(n, "remove");
            r.slides = e(r.vars.selector + ":not(.clone)", r);
            r.setup();
            r.vars.removed(r)
        };
        v.init()
    };
    e(window).blur(function (e) {
        focused = !1
    }).focus(function (e) {
        focused = !0
    });
    e.mtslider.defaults = {
        namespace: "mt-",
        selector: ".slides > li",
        animation: "fade",
        easing: "swing",
        direction: "horizontal",
        reverse: !1,
        animationLoop: !0,
        smoothHeight: !1,
        startAt: 0,
        slideshow: !0,
        slideshowSpeed: 7e3,
        animationSpeed: 600,
        initDelay: 0,
        randomize: !1,
        thumbCaptions: !1,
        pauseOnAction: !0,
        pauseOnHover: !1,
        pauseInvisible: !0,
        useCSS: !0,
        touch: !0,
        video: !1,
        controlNav: !0,
        directionNav: !0,
        prevText: "Previous",
        nextText: "Next",
        keyboard: !0,
        multipleKeyboard: !1,
        mousewheel: !1,
        pausePlay: !1,
        pauseText: "Pause",
        playText: "Play",
        controlsContainer: "",
        manualControls: "",
        sync: "",
        asNavFor: "",
        itemWidth: 0,
        itemMargin: 0,
        minItems: 1,
        maxItems: 0,
        move: 0,
        allowOneSlide: !0,
        start: function () {},
        before: function () {},
        after: function () {},
        end: function () {},
        added: function () {},
        removed: function () {}
    };
    e.fn.mtslider = function (t) {
        t === undefined && (t = {});
        if (typeof t == "object") return this.each(function () {
            var n = e(this),
                r = t.selector ? t.selector : ".slides > li",
                i = n.find(r);
            if (i.length === 1 && t.allowOneSlide === !0 || i.length === 0) {
                i.fadeIn(400);
                t.start && t.start(n)
            } else n.data("mtslider") === undefined && new e.mtslider(this, t)
        });
        var n = e(this).data("mtslider");
        switch (t) {
        case "play":
            n.play();
            break;
        case "pause":
            n.pause();
            break;
        case "stop":
            n.stop();
            break;
        case "next":
            n.mtAnimate(n.getTarget("next"), !0);
            break;
        case "prev":
        case "previous":
            n.mtAnimate(n.getTarget("prev"), !0);
            break;
        default:
            typeof t == "number" && n.mtAnimate(t, !0)
        }
    }
})(jQuery, window, document);

//jQuery mtMobileNav =============================================================================================
/*
DOCUMENTATION:
USAGE: $("nav.main-nav").mtMobileNav({})
REFERENCES: PrimaryNavigation module
DEPENDENCIES: jQuery
NOTES: 
*/
(function ($, window, document) {
    $.fn.mtMobileNav = function ( options ) {
        // Default Settings
        var defaults = {
            // Menu Positioning
            position: "right", // right, left, top
            action: "slide", // slide or push
            // Menu Insertion
            attachment: "append", // append, before, after
            container: "header", // the container to append to or insert before/after
            // Menu Wrapper Opts
            wrapperAttr: {
                cssClass: "mobile-nav"
            }, // the class to assign the wrapper
            // Menu Toggle
            toggleBtn: "section.mobile-menu .toggle",
            activeClass: "active",
            // Misc Opts
            overlayColor: "rgba(0,0,0,.8)", // the overlay color to insert over the site content (slide only)
            topToggleMode: "slide", // slide, showhide, or a custom function
            topToggleSpeed: 0, // the speed of the slide or showhide transition for top positioned menu
            appendSearch: null, // set to the selector for the search form if you would like it appended to the menu
            prependSearch: null, // set to the selector for the search form if you would like it prepended to the menu
            // Callbacks
            onAttach: function() {},
            onMenuOpen: function() {},
            onMenuClose: function() {}
        };

        // Apply passed options and clone nav
        var opts = $.extend( {}, defaults, options);

        
        // Setup Menu Toggle and related vars
        var init = init(this),
            $toggleBtn = $(opts.toggleBtn),
            $menu = init.menu,
            menuWidth = init.menuWidth;

        // Append Overlay for Slide Nav
        if (opts.action == "slide") {
            $("body").append('<div class="mtMobileNavOverlay" style="background:'+ opts.overlayColor +';position:absolute;top:0;left:0;width:100%;height:' + $(document).height() + 'px;display:none;z-index:999998;"></div>');
            $toggleBtn.css({"z-index": 999999});
            $overlay = $(".mtMobileNavOverlay");
            $overlay.on("click", menuToggle);
        }

        // Attach menu toggle event
        $toggleBtn.on("click", menuToggle);

        // Return the mobile menu for chainability
        return $menu;

        // Private functions
        function attach (nav) {
            // Attach Nav per Opts
            switch (opts.attachment) {
                case "append": $(opts.container).append('<section class="' + opts.wrapperAttr.cssClass + '" role="navigation">' + nav.html() + '</section>'); break;
                case "before": $(opts.container).before('<section class="' + opts.wrapperAttr.cssClass + '" role="navigation">' + nav.html() + '</section>'); break;
                case "after":  $(opts.container).after('<section class="' + opts.wrapperAttr.cssClass + '" role="navigation">' + nav.html() + '</section>'); break;
            }
            // If we are attaching the site search
            switch (true) {
                case (opts.appendSearch != null && $(opts.appendSearch).length > 0): $("." + opts.wrapperAttr.cssClass).append($(opts.appendSearch)); break;
                case (opts.prependSearch != null && $(opts.prependSearch).length > 0): $("." + opts.wrapperAttr.cssClass).prepend($(opts.prependSearch)); break;
                //removed .clone() from the end of the append/prepend statements to avoid duplication of fields, which get sent to search results as an array
            }
            // Fire Callback
            opts.onAttach.call(this);
        }

        function init(nav) {
            // Clone Nav and attach
            var $nav = nav.clone().unwrap();
            attach($nav);

            // Get inserted nav and set positioning
            var $mobileNav = $("." + opts.wrapperAttr.cssClass),
                 mnavWidth = $mobileNav.outerWidth();

            position($mobileNav, mnavWidth);

            // Return objects for variable assignment
            return {
                menu: $mobileNav,
                menuWidth: mnavWidth
            }
        }

        function position(menu, width) {
            switch (opts.position) {
                case "left":
                    menu.css({ position: "fixed", height: "100%", top: 0, left: 0, marginLeft: "-" + width + "px", zIndex: 999999 });
                    break;
                case "right":
                    menu.css({ position: "fixed", height: "100%", top: 0, right: 0, marginRight: "-" + width + "px", zIndex: 999999 });
                    break;
                case "top":
                    menu.css({ display: "none" });
                    break;
            }
        }

        function slideMenu() {
            // Get Current Menu State
            if ($menu.css("margin-" + opts.position) >= "0px") {
                // menu is OPEN - now CLOSE it
                var anim = function() {
                    if (opts.position == "left") return { "margin-left": "-=" + menuWidth };
                    else if (opts.position == "right") return { "margin-right": "-=" + menuWidth };
                    else console.log("The position passed is not valid for use with this method.");
                }
                if (opts.action == "slide") { 
                    $overlay.fadeOut('fast'); 
                    $toggleBtn.animate(anim());
                }
                else if (opts.action == "push") { 
                    var moveBody = function() {
                        if (opts.position == "left") return { "left": 0 };
                        else if (opts.position == "right") return { "right": 0 };
                    }
                    $("body").animate(moveBody(), function() {
                        $(this).css({ "position": "static" });
                    }); 
                }
                $menu.animate(anim());
                // Fire callback
                opts.onMenuClose.call(this);
            } 
            else {
                // menu is CLOSED - now OPEN it
                var anim = function() {
                    if (opts.position == "left") return { "margin-left": "+=" + menuWidth };
                    else if (opts.position == "right") return { "margin-right": "+=" + menuWidth };
                    else console.log("The position passed, " +  + " , is not valid for use with this method.")
                }
                if (opts.action == "slide") { 
                    $overlay.fadeIn('fast'); 
                    $toggleBtn.animate(anim());
                }
                else if (opts.action == "push") {
                    var moveBody = function() {
                        if (opts.position == "left") return { "left": menuWidth + "px" };
                        else if (opts.position == "right") return { "right": menuWidth + "px" };
                    }
                    $("body").css({ "position": "relative" }).animate(moveBody()); 
                }
                $menu.animate(anim());
                // Fire callback
                opts.onMenuOpen.call(this);
            }
        }

        function menuToggle() {
            switch (opts.position) {
                case "top": 
                    // Use specified top menu display method
                    if (opts.topToggleMode == "showhide") $menu.toggle(opts.topToggleSpeed);
                    else if ($.isFunction(opts.topToggleMode)) opts.topToggleMode.call(this);
                    else $menu.slideToggle(opts.topToggleSpeed);
                    // Check toggleBtn class and fire appropriate callback
                    if ($toggleBtn.hasClass(opts.activeClass)) opts.onMenuClose.call(this);
                    else opts.onMenuOpen.call(this);
                    break;
                default: slideMenu(); break;
            }
            // Toggle Class on Button
            $toggleBtn.toggleClass(opts.activeClass);
            return false;
        }
    }
})(jQuery, window, document);

//Placeholder Polyfill =============================================================================================
/*
DOCUMENTATION:
USAGE: $("input, textarea").placehold();
REFERENCES: script.js
DEPENDENCIES jQuery
NOTES: Patrick 8/26- references should be removed and this should be deprecated, as all current browsers now support placeholder
*/
(function ($, window, document) {
    $.fn.placehold = function (placeholderClassName) {
        var placeholderClassName = placeholderClassName || "placeholder",
            supported = $.fn.placehold.is_supported();

        function toggle() {
            for (i = 0; i < arguments.length; i++) {
                arguments[i].toggle();
            }
        }

        return supported ? this : this.each(function () {
            var $elem = $(this),
                placeholder_attr = $elem.attr("placeholder");

            if (placeholder_attr) {
                if ($elem.val() === "" || $elem.val() == placeholder_attr) {
                    $elem.addClass(placeholderClassName).val(placeholder_attr);
                }

                if ($elem.is(":password")) {
                    var $pwd_shiv = $("<input />", {
                        "class": $elem.attr("class") + " " + placeholderClassName,
                        "value": placeholder_attr
                    });

                    $pwd_shiv.bind("focus.placehold", function () {
                        toggle($elem, $pwd_shiv);
                        $elem.focus();
                    });

                    $elem.bind("blur.placehold", function () {
                        if ($elem.val() === "") {
                            toggle($elem, $pwd_shiv);
                        }
                    });

                    $elem.hide().after($pwd_shiv);
                }

                $elem.bind({
                    "focus.placehold": function () {
                        if ($elem.val() == placeholder_attr) {
                            $elem.removeClass(placeholderClassName).val("");
                        }
                    },
                    "blur.placehold": function () {
                        if ($elem.val() === "") {
                            $elem.addClass(placeholderClassName).val(placeholder_attr);
                        }
                    }
                });

                $elem.closest("form").bind("submit.placehold", function () {
                    if ($elem.val() == placeholder_attr) {
                        $elem.val("");
                    }

                    return true;
                });
            }
        });
    };

    $.fn.placehold.is_supported = function () {
        return "placeholder" in document.createElement("input");
    };
})(jQuery, window, document);

//jQuery Responsive Tables====================================================================================
/*
DOCUMENTATION:
USAGE: finds tables with class "restable" and resizes according to viewport
REFERENCES: called on all pages
DEPENDENCIES jQuery
NOTES: Patrick 8/26: This should be re-written and encapsulated into an mtUtilities function.
*/
$(function() {
  var switched = false;
  var updateTables = function() {
    if (($(window).width() < 767) && !switched ){
      switched = true;
      $("table.restable").each(function(i, element) {
        splitTable($(element));
      });
      return true;
    }
    else if (switched && ($(window).width() > 767)) {
      switched = false;
      $("table.restable").each(function(i, element) {
        unsplitTable($(element));
      });
    }
  };
   
  $(window).load(updateTables);
  $(window).on("redraw",function(){switched=false;updateTables();}); // An event to listen for
  $(window).on("resize", updateTables);
   
    
    function splitTable(original) {
        original.wrap("<div class='table-wrapper' />");
        
        var copy = original.clone();
        copy.find("td:not(:first-child), th:not(:first-child)").css("display", "none");
        copy.removeClass("restable");
        
        original.closest(".table-wrapper").append(copy);
        copy.wrap("<div class='pinned' />");
        original.wrap("<div class='scrollable' />");

    setCellHeights(original, copy);
    }
    
    function unsplitTable(original) {
    original.closest(".table-wrapper").find(".pinned").remove();
    original.unwrap();
    original.unwrap();
    }

  function setCellHeights(original, copy) {
    var tr = original.find('tr'),
        tr_copy = copy.find('tr'),
        heights = [];

    tr.each(function (index) {
      var self = $(this),
          tx = self.find('th, td');

      tx.each(function () {
        var height = $(this).outerHeight(true);
        heights[index] = heights[index] || 0;
        if (height > heights[index]) heights[index] = height;
      });

    });

    tr_copy.each(function (index) {
      $(this).height(heights[index]);
    });
  }
});

//Collapsible Callouts ========================================================================================================
/*
DOCUMENTATION:
USAGE: $(".collapse-for-mobile").mtMobileCallouts();
REFERENCES: script.js
DEPENDENCIES: Called on all pages
NOTES: Patrick 8/26: Can this be accomplished with jQueryUI accordion?
*/
(function ($, window, document) {
    $.fn.mtMobileCallouts = function(options) {
        // Default Settings
        var defaults = {
            wrapperElem: "div",
            wrapperAttr: {
                cssClass: "mobile-callout-header"
            }, // the class to assign the wrapper
            activeClass: "open", // the class that will be assigned to the header when the callout is open
            calloutHeader: "h3", // the header element of the toggle that contains the header text 
            // Misc Opts
            toggleSpeed: 400, // the speed of the collapsible menu toggle animation
            // Callbacks
            onCalloutOpen: function() {}, // Fired after callout is opened
            onCalloutClose: function() {} // Fired after callout is closed
        };

        // Apply passed options and clone nav
        var opts = $.extend( {}, defaults, options),
            $callouts = $(this);
        
        if ($callouts.length > 0) {
            // Iterate over callouts and insert mobile headers
            $callouts.each( function(index, element){
                var $this = $(this),
                    $header = $('<' + opts.wrapperElem + ' class="' + opts.wrapperAttr.cssClass + '">' + $this.find(opts.calloutHeader).text() + '</' + opts.wrapperElem + '>');
                $this.prepend($header);
            });
            // Attach header click event
            $(opts.wrapperElem + "." + opts.wrapperAttr.cssClass).on("click", function (e) {
                e.preventDefault();
                // Get current state
                var state = $(this).hasClass(opts.activeClass) ? "close" : "open";
                // Change state and fire appropriate callback
                $(this).toggleClass(opts.activeClass).next().slideToggle(opts.toggleSpeed, function (e){
                    if (state === "open") opts.onCalloutOpen.call(this);
                    else opts.onCalloutClose.call(this);
                });
                return false;
            });
        }
    };
})(jQuery, window, document);

//jQuery Video Modal hook==========================================================================================
/*
DOCUMENTATION:
USAGE: <a name="modal" href="[YouTube or Vimeo Video Embed URL]" data-width="[video width]" data-height="[video height]">[img, etc.]</a>
REFERENCES: Loads on all pages
DEPENDENCIES: jQuery
NOTES: Patrick 8/26: This should either be replaced with a different library, or re-written into a jQUery extension for better mgmt
*/
$(window).load( function() {
    var $modals = $("a[name=modal]");

    if ($modals.length > 0) {
        if (!$("html").hasClass("touch")) {
            // Setup vars
            var winWidth = function() { return $(window).width(); },
                winHeight = function() { return $(window).height() },
                maskWidth = function() { return winWidth(); },
                maskHeight = function() { return $(document).height() },
                $mask = $("<div></div>", { "class": "mask" }).css({ "position": "absolute", "top": 0, "left": 0, "z-index": 999998, "display": "none", "background-color": "rgba(0,0,0,.8)", "-webkit-transform": "translateZ(0)" }).appendTo("body"),
                $wrap = $('<div class="video-modal"><div class="closetag"><a href="#" class="close" data-dismiss="boxes">&nbsp;<span>X</span></a></div><iframe src="" frameborder="0" allowfullscreen></iframe></div>').css({ "z-index": 999999, "position": "fixed" }).appendTo(".mask"),
                $iframe = $wrap.find("iframe");

            // Video Link Click
            $modals.append('<span class="icon"></span>').on("click", function (e) {
                e.preventDefault();
                var $this = $(this),
                    src = $this.attr("href"),
                    width = $this.data("width") !== undefined ? $this.data("width") : "420",
                    height = $this.data("height") !== undefined ? $this.data("height") : "315",
                    opts = src.search(/youtube.com/) !== -1 ? "?showinfo=0&controls=2&rel=0&modestbranding=1" : (src.search(/vimeo.com/) !== -1 ? "?portrait=0&title=0&byline=0&badge=0" : "");
                $iframe.attr({ "src": src + opts, "width": width, "height": height });
                $wrap.css({ "top": (winHeight()/2)-(height/2) + "px", "left": (winWidth()/2)-(width/2) + "px" }).parents(".mask").css({ "width": maskWidth() + "px", "height": maskHeight() + "px" }).fadeIn(400);
            });

            // Close Video Modal
            function closeVideoModal(e) {
                e.preventDefault;
                $mask.fadeOut(400);
                $iframe.attr({ "src": "" });
            }
            
            $mask.on("click", function (e) { closeVideoModal(e); });
            $wrap.find(".close").on("click", function (e) { closeVideoModal(e); });

            // Window Resize
            $(window).on("resize", function() {
                $mask.css({ "width": maskWidth() + "px", "height": maskHeight() + "px" });
                $wrap.css({ "top": (winHeight()/2)-($wrap.find("iframe").height()/2) + "px", "left": (winWidth()/2)-($wrap.find("iframe").width()/2) + "px" });
            });
        } else {
            $modals.each( function (index, element) {
                var $this = $(this),
                    src = element.href,
                    width = $this.find("img").width(),
                    height = $this.find("img").height(),
                    opts = src.search(/youtube.com/) !== -1 ? "?showinfo=0&controls=2&rel=0&modestbranding=1" : (src.search(/vimeo.com/) !== -1 ? "?portrait=0&title=0&byline=0&badge=0" : ""),
                    cover = $this.find("img"),
                    cHeight = cover.height(),
                    cWidth = cover.width();
                
                // Append cover image and span.icon (play button) to modal parent (div.video)
                // Then set CSS positioning
                $this.closest(".video").append(cover).append('<span class="icon"></span>').css({
                    "position": "relative",
                    "width": cWidth + "px",
                    "height": cHeight + "px"
                }).find("img").css( { "position": "absolute", "z-index": 2 } );
                // Replace modal link (a[rel=modal]) with inline iframe
                $this.replaceWith('<iframe src="' + src + opts + '" width="' + width + '" height="' + height + '" frameborder="0" style="position:absolute;z-index:1;" allowfullscreen></iframe>');
            });
            
            // Attach event handler to div.video wrapper to hide cover (img) and play button (span.icon)
            $("body").on("click", ".video", function (e) {
                $(this).find("img,span").fadeOut();
            });
        }
    }
});

//Additional Feature Detection=======================================================
/*
DOCUMENTATION:
USAGE: 
REFERENCES: Runs on all pages
DEPENDENCIES: 
NOTES: Patrick 8/26: Could be redundant or unnecessary w/ Modernizr
*/
$(function () {
    var $html = $("html");
    if (!!navigator.userAgent.match(/Trident.*rv[ :]*11\./)) $html.addClass("ie11");
    if (!!navigator.userAgent.match(/MSIE 10\./)) $html.addClass("ie10 lt-ie11");
    if (!!navigator.userAgent.match(/MSIE 9\./)) $html.addClass("ie9 lt-ie11 lt-ie10");
    if (!!navigator.userAgent.match(/Gecko.*Firefox/)) $html.addClass("firefox");
    if (!!navigator.userAgent.match(/iPad/i)) $html.addClass("ipad ios");
    if (!!navigator.userAgent.match(/iPod/i)) $html.addClass("ipod ios");
    if (!!navigator.userAgent.match(/iPhone/i)) $html.addClass("iphone ios");
}); 


//Console Polyfill ==========================================================================================================
/*
DOCUMENTATION:
USAGE: 
REFERENCES: Loads on all pages
DEPENDENCIES: 
NOTES: Patrick 8/26: Is this necessary? There don't seem to be any current calls to the console
*/
(function() {
    var method;
    var noop = function () {};
    var methods = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeStamp', 'trace', 'warn'
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
}());


})(jQuery);

//[NAME] be nice and replace me at the bottom for the next person!=======================================================
/*
DOCUMENTATION:
USAGE: 
REFERENCES: 
DEPENDENCIES: 
NOTES: 
*/



/*
* MedTouch Helper Utilities
*/
var mtUtilities = {
    /*
    * Shopping Cart Promo Handling
    */
    calendarModule: function () {
        var $cePromoMap = jQuery("#hdnPromoCodesAvail"),
            $instructorListing = jQuery(".module-ce-instructors-listing"),
            $checkoutHeader = jQuery(".module-ce-checkout-header"),
            $cartSummary = jQuery(".module-ce-session-shoppingcart-summary"),
            $customForm = jQuery(".module-ce-customform");

        if ($cePromoMap.length > 0) {

            var cePromoMap = $cePromoMap.val().toUpperCase().split(","),
                flag = false,
                $promoInput = jQuery("input.promo-input"),
                $promoBtn = jQuery("div.add-promo-panel").find("input[type=submit]");

            jQuery(".add-promo-link").children("a").on("click", function (e) {
                e.preventDefault();
                var $this = jQuery(this);
                $this.toggleClass("active").parent().next().find("span.error").hide().parent().slideToggle(400);
                if ($this.hasClass("active")) $promoInput.val("").focus();
                return false;
            });

            $promoBtn.on("click", function (e) {
                if (flag === false) {
                    e.preventDefault();
                    switch (true) {
                        case $promoInput.val() === "" || $promoInput.val() === "Enter Promo Code":
                            jQuery("span[data-reason='blank']").show();
                            return false;
                            break;
                        case $.inArray($promoInput.val().toUpperCase(), cePromoMap) === -1:
                            jQuery("span[data-reason='invalid']").show();
                            return false;
                            break;
                        default:
                            flag = true;
                            break;
                    }
                    if (flag === true) jQuery(this).click();
                }
            });

            $promoInput.keyup(function (e) {
                var $this = jQuery(this);
                // If the invalid code message is showing, hide on typing
                if ($.inArray(e.keyCode, [37, 38, 39, 40, 16]) === -1 && ($this.val() === "" || $this.val().length === 1)) jQuery("span[data-reason='invalid']:visible").hide();
                // Add enable/disable class to Apply link        
                if ($.inArray($this.val().toUpperCase(), cePromoMap) === -1) $promoBtn.addClass("disabled");
                else {
                    $promoBtn.removeClass("disabled");
                    jQuery("span[data-reason='invalid']:visible").hide();
                }
                // If the blank error is up and text has been entered, hide it
                if ($this.val() !== "") jQuery("span[data-reason='blank']:visible").hide();
                // If the user pressed the enter key, trigger a click on the Apply button
                if (e.keyCode == 13) {
                    $promoBtn.click();
                }
            });
        }

        if ($instructorListing.length > 0) {
            if ($instructorListing.length > 0) {
                jQuery(".hide-onload").hide();
                $instructorListing.each(function (i, el) {
                    var $this = jQuery(this),
                                $toggleBtn = $this.find(".toggle-hide-show"),
                                $togglePanel = $this.find(".instructor-item");

                    if ($toggleBtn.length > 0) {
                        $togglePanel.eq(0).show().prev(".toggle-hide-show").children("a").addClass("open").children("span").html("-");
                    }
                });
                jQuery(".toggle-hide-show a").unbind("click").on("click", function (e) {
                    e.preventDefault();
                    var $this = jQuery(this).hasClass("toggle-hide-show") ? jQuery(this).children("a") : jQuery(this);
                    if ($this.hasClass("open")) {
                        $this.toggleClass("open").children("span").html("+").end().parent().next(".instructor-item").slideToggle();
                    }
                    else {
                        $this.parents(".module-ce-instructors-listing").find("a.open").click();
                        $this.toggleClass("open").children("span").html("-").end().parent().next(".instructor-item").slideToggle();
                    }
                });
            }
        }

        if ($checkoutHeader.length > 0 && $cartSummary.length > 0) {
            $cartSummary.find(".cart-checkout").hide();
        }

        if ($customForm.length > 0) {
            $customForm.find(".scfSectionContent > div").each(function (i, el) {
                var $this = jQuery(this);

                switch (true) {
                    case $this.hasClass("scfSingleLineTextBorder") || $this.hasClass("scfMultipleLineTextBorder"):
                        var placeholder = $this.children("label").text();
                        $this.find(":text, textarea").attr("placeholder", placeholder);
                        break;
                    case $this.hasClass("scfDatePickerBorder"):
                        var placeholder = $this.children("label").text();
                        $this.find(".hasDatepicker").attr("placeholder", placeholder).val("");
                        $this.find(".hasDatepicker").datepicker("option", "defaultDate", 0);
                        break;
                    case $this.hasClass("scfDropListBorder"):
                        var placeholder = $this.children("label").text();
                        //$this.find(":input").prepend(new Option(placeholder,'',true,true));
                        //$this.find(":input option:first").attr("selected","selected");
                        if ($this.find(":input option:first").text() === "") {
                            $this.find(":input option:first").text(placeholder);
                        }
                        break;
                    default:
                        $this.find("label").css({ "display": "block" });
                }

                //$this.find("scfRequired").appendTo($this);
                $this.find(".scfValidatorRequired").text("*");
            });
        }

    },

    /*
    * Search Keyword Autocomplete
    */
    correctComplete: function () {
        var oldFn = jQuery.ui.autocomplete.prototype._renderItem;

        jQuery.ui.autocomplete.prototype._renderItem = function (ul, item) {
            var re = new RegExp("\\b" + this.term, "i"),
                t = item.label.replace(re, "<span style='font-weight:bold'>" + this.term + "</span>");

            return jQuery("<li></li>")
                .data("item.autocomplete", item)
                .append("<a>" + t + "</a>")
                .appendTo(ul);
        };
    },

    /*
    * Custom Select
    */
    customSelect: function () {
        var $select = jQuery("select:not('[data-processed=true]')").not(".no-custom-select"),
            cs = function () {
                return jQuery("select.selectboxdiv");
            },
            selected = function (el) {
                var el = el.tagName === "SELECT" ? jQuery(el) : jQuery(el).find("select");
                value = el.children(":selected").length > 0 ? el.children(":selected").text() : el.children().eq(0).text();
                return value !== "" ? value : "\xA0";
            },
            setupSelect = function (el, settings) {
                var $this = jQuery(el),
                    opts = {},
                    settings = settings || {},
                    value = selected(el);

                // Check if select has alread been processed
                if ($this.not("[data-processed=true]")) {
                    // Setup settings
                    opts.selectClass = settings.selectClass ? " " + settings.selectClass : "";
                    opts.wrapperClass = settings.wrapperClass ? " " + settings.wrapperClass : "";

                    // Check for <select> wrapper <div>, add if not found and append output <div>
                    if (!$this.parent(".selectbox").length) {
                        $this.wrap('<div class="selectbox' + opts.wrapperClass + '" />');
                    }

                    // Check for output <div> and add if it does not exist
                    if (!$this.siblings("div.out").length) {
                        $this.parent(".selectbox").append('<div class="out" />');
                    }

                    // Add class on <select> and set processed attribute to true 
                    $this
                        .addClass("selectboxdiv")
                        .attr("data-processed", "true");
                }

                // Set select value
                updateSelect(el);
            },
            updateSelect = function (el) {
                jQuery(el).next(".out").text(selected(el));
            };

        // Initialize <select> elements on page
        if ($select.length) {
            $select.each(function (i, el) {
                var $this = jQuery(this);

                switch (true) {
                    case $this.parents(".scfDateSelectorGeneralPanel").length > 0:
                        var wffmClass = $this.attr("class") + "Wrap shortDateSelect";
                        setupSelect(el, { wrapperClass: wffmClass });
                        break;
                    default:
                        setupSelect(el);
                }
            });
        }

        // <select> change handler
        cs().on("change keyup", function (e) {
            updateSelect(this);
        });

        // Reset Buttons
        jQuery('.reset').click(function () {
            setTimeout(function () {
                cs().trigger('change').trigger('update');
            }, 1);
        });
    },

    /*
    * Responsive Tabs
    */
    responsiveTabs: function () {
            var $tabSets = jQuery('.responsive-tabs');
	//jQuery('.home .responsive-tabs h2:first-of-type').addClass('first');
	
    if (!$tabSets.hasClass('responsive-tabs--enabled')) {	// if we haven't already called this function and enabled tabs
        $tabSets.addClass('responsive-tabs--enabled');
		
        //loop through all sets of tabs on the page
        var tablistcount = 1;

        $tabSets.each(function () {

            var $tabs = jQuery(this);

            // add tab heading and tab panel classes
            $tabs.children('h1,h2,h3,h4,h5,h6').addClass('responsive-tabs__heading');
            $tabs.children('div').addClass('responsive-tabs__panel');

            // determine if markup already identifies the active tab panel for this set of tabs
            // if not then set first heading and tab to be the active one
            var $activePanel = $tabs.find('.responsive-tabs__panel--active');
            if (!$activePanel.length) {
                var $activePanel = $tabs.find('.responsive-tabs__panel').first().addClass('responsive-tabs__panel--active');
				$activePanel.prev().addClass('responsive-tabs__heading--active');
            }

            $tabs.find('.responsive-tabs__panel').not('.responsive-tabs__panel--active').hide().attr('aria-hidden', 'true'); //hide all except active panel
            $activePanel.attr('aria-hidden', 'false');
            /* make active tab panel hidden for mobile */
            //$activePanel.addClass('responsive-tabs__panel--closed-accordion-only');

            // wrap tabs in container - to be dynamically resized to help prevent page jump
            var $tabsWrapper = jQuery('<div/>', { Class: 'responsive-tabs-wrapper' });
            $tabs.wrap($tabsWrapper);

            var highestHeight = 0;

            // determine height of tallest tab panel. Used later to prevent page jump when tabs are clicked
            $tabs.find('.responsive-tabs__panel').each(function () {
                var tabHeight = jQuery(this).height();
                if (tabHeight > highestHeight) {
                    highestHeight = tabHeight;
                }
            })

            //create the tab list
            var $tabList = jQuery('<ul/>', { Class: 'responsive-tabs__list', 'role': 'tablist' });

            //loop through each heading in set
            var tabcount = 1;
            $tabs.find('.responsive-tabs__heading').each(function () {

                var $tabHeading = jQuery(this);
                var $tabPanel = jQuery(this).next();

                $tabHeading.attr('tabindex', 0);

                // CREATE TAB ITEMS (VISIBLE ON DESKTOP)
                //create tab list item from heading
                //associate tab list item with tab panel
                var $tabListItem = jQuery('<li/>', {
                    Class: 'responsive-tabs__list__item',
                    id: 'tablist' + tablistcount + '-tab' + tabcount,
                    'aria-controls': 'tablist' + tablistcount + '-panel' + tabcount,
                    'role': 'tab',
                    tabindex: 0,
                    text: $tabHeading.text(),
                    keydown: function (objEvent) {
                        if (objEvent.keyCode == 13) { // if user presses 'enter'
                            $tabListItem.click();
                        }
                    },
                    click: function () {
                        //Show associated panel

                        //set height of tab container to highest panel height to avoid page jump
                        $tabsWrapper.css('height', highestHeight);

                        // remove hidden mobile class from any other panel as we'll want that panel to be open at mobile size
                        $tabs.find('.responsive-tabs__panel--closed-accordion-only').removeClass('responsive-tabs__panel--closed-accordion-only');

                        // close current panel and remove active state from its (hidden on desktop) heading
                        $tabs.find('.responsive-tabs__panel--active').toggle().removeClass('responsive-tabs__panel--active').attr('aria-hidden', 'true').prev().removeClass('responsive-tabs__heading--active');

                        //make this tab panel active
                        $tabPanel.toggle().addClass('responsive-tabs__panel--active').attr('aria-hidden', 'false');

                        //make the hidden heading active
                        $tabHeading.addClass('responsive-tabs__heading--active');

                        //remove active state from currently active tab list item
                        $tabList.find('.responsive-tabs__list__item--active').removeClass('responsive-tabs__list__item--active');

                        //make this tab active
                        $tabListItem.addClass('responsive-tabs__list__item--active');

                        //reset height of tab panels to auto
                        $tabsWrapper.css('height', 'auto');


                    }
                });

                //associate tab panel with tab list item
                $tabPanel.attr({
                    'role': 'tabpanel',
                    'aria-labelledby': $tabListItem.attr('id'),
                    id: 'tablist' + tablistcount + '-panel' + tabcount
                });

                // if this is the active panel then make it the active tab item
                if ($tabPanel.hasClass('responsive-tabs__panel--active')) {
                    $tabListItem.addClass('responsive-tabs__list__item--active');
                }

                // add tab item
                $tabList.append($tabListItem);


                // TAB HEADINGS (VISIBLE ON MOBILE)
                // if user presses 'enter' on tab heading trigger the click event
                $tabHeading.keydown(function (objEvent) {
                    if (objEvent.keyCode == 13) {
                        $tabHeading.click();
                    }
                })

                //toggle tab panel if click heading (on mobile)
                $tabHeading.click(function () {

                    // remove any hidden mobile class
                    $tabs.find('.responsive-tabs__panel--closed-accordion-only').removeClass('responsive-tabs__panel--closed-accordion-only');

                    // if this isn't currently active
                    if (!$tabHeading.hasClass('responsive-tabs__heading--active')) {
                        //get position of active heading 
                        if (jQuery('.responsive-tabs__heading--active').length) {
                            var oldActivePos = jQuery('.responsive-tabs__heading--active').offset().top;
                        }

                        // close currently active panel and remove active state from any hidden heading
                        $tabs.find('.responsive-tabs__panel--active').slideToggle().removeClass('responsive-tabs__panel--active').prev().removeClass('responsive-tabs__heading--active');

                        //close all tabs
                        $tabs.find('.responsive-tabs__panel').hide().attr('aria-hidden', 'true');

                        //open this panel
                        $tabPanel.slideToggle().addClass('responsive-tabs__panel--active').attr('aria-hidden', 'false');

                        // make this heading active
                        $tabHeading.addClass('responsive-tabs__heading--active');

                        var $currentActive = $tabs.find('.responsive-tabs__list__item--active');

                        //set the active tab list item (for desktop)
                        $currentActive.removeClass('responsive-tabs__list__item--active');
                        var panelId = $tabPanel.attr('id');
                        var tabId = panelId.replace('panel', 'tab');
                        jQuery('#' + tabId).addClass('responsive-tabs__list__item--active');

                        //scroll to active heading only if it is below previous one
                        var tabsPos = jQuery('.responsive-tabs').offset().top;
                        var newActivePos = jQuery('.responsive-tabs__heading--active').offset().top;
                        if (oldActivePos < newActivePos) {
                            jQuery('html, body').animate({ scrollTop: tabsPos }, 0).animate({ scrollTop: newActivePos }, 400);
                        }

                    }

                    // if this tab panel is already active
                    else {

                        // hide panel but give it special responsive-tabs__panel--closed-accordion-only class so that it can be visible at desktop size
                        $tabPanel.removeClass('responsive-tabs__panel--active').slideToggle(function () { jQuery(this).addClass('responsive-tabs__panel--closed-accordion-only') });

                        //remove active heading class
                        $tabHeading.removeClass('responsive-tabs__heading--active');

                        //don't alter classes on tabs as we want it active if put back to desktop size
                    }

                })

                tabcount++;

            })

            // add finished tab list to its container
            $tabs.prepend($tabList);

            // next set of tabs on page
            tablistcount++;
        })
    }
},
    Services: {
        tabInit: function () {
            jQuery(".services-custom ul.mt li a").each(function (index) {
                jQuery(this).attr("href", "#alpha" + index.toString());
            });
            jQuery(".services-custom > div").each(function (index) {
                jQuery(this).attr("id", "alpha" + index.toString());
            });
            jQuery('.tabs.services-custom').tabs();
            jQuery('.module-sv-alpha ul>li>a').on('click', function () {
                var hash = this.innerText;
                mtUtilities.Services.hashManager(hash);
                mtUtilities.Services.tabManager(hash);
            });
            jQuery('.tabs.services-custom ul>li>a').on('click', function () {
                var hash = this.innerText;
                mtUtilities.Services.hashManager(hash);
                mtUtilities.Services.tabManager(hash);
            });
            var hash = location.hash.replace("#", "");
            if (hash != "") {
                mtUtilities.Services.tabManager(hash);
            }
        },
        hashManager: function (hash) {
            location.hash = hash;
        },
        tabManager: function (hash) {
            jQuery('.tabs').tabs({ active: jQuery('.tabs li[serviceletter="' + hash + '"]').attr('serviceindex') });
        }
    },
    isPageEditor: function () {
        if (typeof Sitecore == "undefined") {
            return false;
        }
        if (typeof Sitecore.PageModes == "undefined" || Sitecore.PageModes == null) {
            return false;
        }
        return Sitecore.PageModes.PageEditor != null;
    },
    ValidateDate : function(date) {
        var strEventsDays = jQuery("#hdnEventsDays").val();
        if (strEventsDays != null && strEventsDays != '') {
            var arDays = strEventsDays.split(",");

            for (var i = 0; i < arDays.length; i++) {
                var day = arDays[i];

                var dayDate = new Date(day);

                //Compare Date to hilight only match Date from Date Param.
                var daysDiff = Math.floor((dayDate.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

                if (daysDiff == 0) {
                    return [true];
                }
            }
        }
        return [false];
    },
    colorSwitcherPosition: function() { //Might be able to remove with new drop down slider
         var h = jQuery(window).height();
         if (h < jQuery(".mt-wrapper").height()) {
          jQuery(".mt-toggle, .mt-wrapper").addClass('absolute');
         } else {
          jQuery(".mt-toggle, .mt-wrapper").removeClass('absolute');
         }
         jQuery(".over").animate({ 'min-height': jQuery(".mt-wrapper").height() + 200 + "px" }, 300);
    },
    resizeBanner: function() { 
         var w = jQuery('#enhanced-carousel').width();
         var h = w / 2.5; 
         if (h > 100) {
          jQuery('.enhanced-carousel').height(h);
          jQuery('.enhanced-carousel').children('.carousel-inner').children('.item').height(h);
          jQuery('.enhanced-carousel').children('.carousel-inner').children('.item').children('img').height(h);
         }
    }
}

;
/**
 * Galleria v 1.2.8 2012-08-09
 * http://galleria.io
 *
 * Licensed under the MIT license
 * https://raw.github.com/aino/galleria/master/LICENSE
 *
 */
 (function($,window,Galleria,undef){var doc=window.document,$doc=$(doc),$win=$(window),protoArray=Array.prototype,VERSION=1.47,DEBUG=true,TIMEOUT=3e4,DUMMY=false,NAV=navigator.userAgent.toLowerCase(),HASH=window.location.hash.replace(/#\//,""),PROT=window.location.protocol=="file:"?"http:":window.location.protocol,M=Math,F=function(){},FALSE=function(){return false},IE=function(){var v=3,div=doc.createElement("div"),all=div.getElementsByTagName("i");do{div.innerHTML="<!--[if gt IE "+ ++v+"]><i></i><![endif]-->"}while(all[0]);return v>4?v:doc.documentMode||undef}(),DOM=function(){return{html:doc.documentElement,body:doc.body,head:doc.getElementsByTagName("head")[0],title:doc.title}},IFRAME=window.parent!==window.self,_eventlist="data ready thumbnail loadstart loadfinish image play pause progress "+"fullscreen_enter fullscreen_exit idle_enter idle_exit rescale "+"lightbox_open lightbox_close lightbox_image",_events=function(){var evs=[];$.each(_eventlist.split(" "),function(i,ev){evs.push(ev);if(/_/.test(ev)){evs.push(ev.replace(/_/g,""))}});return evs}(),_legacyOptions=function(options){var n;if(typeof options!=="object"){return options}$.each(options,function(key,value){if(/^[a-z]+_/.test(key)){n="";$.each(key.split("_"),function(i,k){n+=i>0?k.substr(0,1).toUpperCase()+k.substr(1):k});options[n]=value;delete options[key]}});return options},_patchEvent=function(type){if($.inArray(type,_events)>-1){return Galleria[type.toUpperCase()]}return type},_video={youtube:{reg:/https?:\/\/(?:[a-zA_Z]{2,3}.)?(?:youtube\.com\/watch\?)((?:[\w\d\-\_\=]+&amp;(?:amp;)?)*v(?:&lt;[A-Z]+&gt;)?=([0-9a-zA-Z\-\_]+))/i,embed:function(){return PROT+"//www.youtube.com/embed/"+this.id},get_thumb:function(data){return PROT+"//img.youtube.com/vi/"+this.id+"/default.jpg"},get_image:function(data){return PROT+"//img.youtube.com/vi/"+this.id+"/hqdefault.jpg"}},vimeo:{reg:/https?:\/\/(?:www\.)?(vimeo\.com)\/(?:hd#)?([0-9]+)/i,embed:function(){return PROT+"//player.vimeo.com/video/"+this.id},getUrl:function(){return PROT+"//vimeo.com/api/v2/video/"+this.id+".json?callback=?"},get_thumb:function(data){return data[0].thumbnail_medium},get_image:function(data){return data[0].thumbnail_large}},dailymotion:{reg:/https?:\/\/(?:www\.)?(dailymotion\.com)\/video\/([^_]+)/,embed:function(){return PROT+"//www.dailymotion.com/embed/video/"+this.id},getUrl:function(){return"https://api.dailymotion.com/video/"+this.id+"?fields=thumbnail_240_url,thumbnail_720_url&callback=?"},get_thumb:function(data){return data.thumbnail_240_url},get_image:function(data){return data.thumbnail_720_url}},_inst:[]},Video=function(type,id){for(var i=0;i<_video._inst.length;i++){if(_video._inst[i].id===id&&_video._inst[i].type==type){return _video._inst[i]}}this.type=type;this.id=id;this.readys=[];_video._inst.push(this);var self=this;$.extend(this,_video[type]);_videoThumbs=function(data){self.data=data;$.each(self.readys,function(i,fn){fn(self.data)});self.readys=[]};if(this.hasOwnProperty("getUrl")){$.getJSON(this.getUrl(),_videoThumbs)}else{window.setTimeout(_videoThumbs,400)}this.getMedia=function(type,callback,fail){fail=fail||F;var self=this;var success=function(data){callback(self["get_"+type](data))};try{if(self.data){success(self.data)}else{self.readys.push(success)}}catch(e){fail()}}},_videoTest=function(url){var match;for(var v in _video){match=url&&_video[v].reg&&url.match(_video[v].reg);if(match&&match.length){return{id:match[2],provider:v}}}return false},_nativeFullscreen={support:function(){var html=DOM().html;return!IFRAME&&(html.requestFullscreen||html.msRequestFullscreen||html.mozRequestFullScreen||html.webkitRequestFullScreen)}(),callback:F,enter:function(instance,callback,elem){this.instance=instance;this.callback=callback||F;elem=elem||DOM().html;if(elem.requestFullscreen){elem.requestFullscreen()}else if(elem.msRequestFullscreen){elem.msRequestFullscreen()}else if(elem.mozRequestFullScreen){elem.mozRequestFullScreen()}else if(elem.webkitRequestFullScreen){elem.webkitRequestFullScreen()}},exit:function(callback){this.callback=callback||F;if(doc.exitFullscreen){doc.exitFullscreen()}else if(doc.msExitFullscreen){doc.msExitFullscreen()}else if(doc.mozCancelFullScreen){doc.mozCancelFullScreen()}else if(doc.webkitCancelFullScreen){doc.webkitCancelFullScreen()}},instance:null,listen:function(){if(!this.support){return}var handler=function(){if(!_nativeFullscreen.instance){return}var fs=_nativeFullscreen.instance._fullscreen;if(doc.fullscreen||doc.mozFullScreen||doc.webkitIsFullScreen||doc.msFullscreenElement&&doc.msFullscreenElement!==null){fs._enter(_nativeFullscreen.callback)}else{fs._exit(_nativeFullscreen.callback)}};doc.addEventListener("fullscreenchange",handler,false);doc.addEventListener("MSFullscreenChange",handler,false);doc.addEventListener("mozfullscreenchange",handler,false);doc.addEventListener("webkitfullscreenchange",handler,false)}},_galleries=[],_instances=[],_hasError=false,_canvas=false,_pool=[],_loadedThemes=[],_themeLoad=function(theme){_loadedThemes.push(theme);$.each(_pool,function(i,instance){if(instance._options.theme==theme.name||!instance._initialized&&!instance._options.theme){instance.theme=theme;instance._init.call(instance)}})},Utils=function(){return{clearTimer:function(id){$.each(Galleria.get(),function(){this.clearTimer(id)})},addTimer:function(id){$.each(Galleria.get(),function(){this.addTimer(id)})},array:function(obj){return protoArray.slice.call(obj,0)},create:function(className,nodeName){nodeName=nodeName||"div";var elem=doc.createElement(nodeName);elem.className=className;return elem},removeFromArray:function(arr,elem){$.each(arr,function(i,el){if(el==elem){arr.splice(i,1);return false}});return arr},getScriptPath:function(src){src=src||$("script:last").attr("src");var slices=src.split("/");if(slices.length==1){return""}slices.pop();return slices.join("/")+"/"},animate:function(){var transition=function(style){var props="transition WebkitTransition MozTransition OTransition".split(" "),i;if(window.opera){return false}for(i=0;props[i];i++){if(typeof style[props[i]]!=="undefined"){return props[i]}}return false}((doc.body||doc.documentElement).style);var endEvent={MozTransition:"transitionend",OTransition:"oTransitionEnd",WebkitTransition:"webkitTransitionEnd",transition:"transitionend"}[transition];var easings={_default:[.25,.1,.25,1],galleria:[.645,.045,.355,1],galleriaIn:[.55,.085,.68,.53],galleriaOut:[.25,.46,.45,.94],ease:[.25,0,.25,1],linear:[.25,.25,.75,.75],"ease-in":[.42,0,1,1],"ease-out":[0,0,.58,1],"ease-in-out":[.42,0,.58,1]};var setStyle=function(elem,value,suffix){var css={};suffix=suffix||"transition";$.each("webkit moz ms o".split(" "),function(){css["-"+this+"-"+suffix]=value});elem.css(css)};var clearStyle=function(elem){setStyle(elem,"none","transition");if(Galleria.WEBKIT&&Galleria.TOUCH){setStyle(elem,"translate3d(0,0,0)","transform");if(elem.data("revert")){elem.css(elem.data("revert"));elem.data("revert",null)}}};var change,strings,easing,syntax,revert,form,css;return function(elem,to,options){options=$.extend({duration:400,complete:F,stop:false},options);elem=$(elem);if(!options.duration){elem.css(to);options.complete.call(elem[0]);return}if(!transition){elem.animate(to,options);return}if(options.stop){elem.off(endEvent);clearStyle(elem)}change=false;$.each(to,function(key,val){css=elem.css(key);if(Utils.parseValue(css)!=Utils.parseValue(val)){change=true}elem.css(key,css)});if(!change){window.setTimeout(function(){options.complete.call(elem[0])},options.duration);return}strings=[];easing=options.easing in easings?easings[options.easing]:easings._default;syntax=" "+options.duration+"ms"+" cubic-bezier("+easing.join(",")+")";window.setTimeout(function(elem,endEvent,to,syntax){return function(){elem.one(endEvent,function(elem){return function(){clearStyle(elem);options.complete.call(elem[0])}}(elem));if(Galleria.WEBKIT&&Galleria.TOUCH){revert={};form=[0,0,0];$.each(["left","top"],function(i,m){if(m in to){form[i]=Utils.parseValue(to[m])-Utils.parseValue(elem.css(m))+"px";revert[m]=to[m];delete to[m]}});if(form[0]||form[1]){elem.data("revert",revert);strings.push("-webkit-transform"+syntax);setStyle(elem,"translate3d("+form.join(",")+")","transform")}}$.each(to,function(p,val){strings.push(p+syntax)});setStyle(elem,strings.join(","));elem.css(to)}}(elem,endEvent,to,syntax),2)}}(),removeAlpha:function(elem){if(elem instanceof jQuery){elem=elem[0]}if(IE<9&&elem){var style=elem.style,currentStyle=elem.currentStyle,filter=currentStyle&&currentStyle.filter||style.filter||"";if(/alpha/.test(filter)){style.filter=filter.replace(/alpha\([^)]*\)/i,"")}}},forceStyles:function(elem,styles){elem=$(elem);if(elem.attr("style")){elem.data("styles",elem.attr("style")).removeAttr("style")}elem.css(styles)},revertStyles:function(){$.each(Utils.array(arguments),function(i,elem){elem=$(elem);elem.removeAttr("style");elem.attr("style","");if(elem.data("styles")){elem.attr("style",elem.data("styles")).data("styles",null)}})},moveOut:function(elem){Utils.forceStyles(elem,{position:"absolute",left:-1e4})},moveIn:function(){Utils.revertStyles.apply(Utils,Utils.array(arguments))},hide:function(elem,speed,callback){callback=callback||F;var $elem=$(elem);elem=$elem[0];if(!$elem.data("opacity")){$elem.data("opacity",$elem.css("opacity"))}var style={opacity:0};if(speed){var complete=IE<9&&elem?function(){Utils.removeAlpha(elem);elem.style.visibility="hidden";callback.call(elem)}:callback;Utils.animate(elem,style,{duration:speed,complete:complete,stop:true})}else{if(IE<9&&elem){Utils.removeAlpha(elem);elem.style.visibility="hidden"}else{$elem.css(style)}}},show:function(elem,speed,callback){callback=callback||F;var $elem=$(elem);elem=$elem[0];var saved=parseFloat($elem.data("opacity"))||1,style={opacity:saved};if(speed){if(IE<9){$elem.css("opacity",0);elem.style.visibility="visible"}var complete=IE<9&&elem?function(){if(style.opacity==1){Utils.removeAlpha(elem)}callback.call(elem)}:callback;Utils.animate(elem,style,{duration:speed,complete:complete,stop:true})}else{if(IE<9&&style.opacity==1&&elem){Utils.removeAlpha(elem);elem.style.visibility="visible"}else{$elem.css(style)}}},wait:function(options){Galleria._waiters=Galleria._waiters||[];options=$.extend({until:FALSE,success:F,error:function(){Galleria.raise("Could not complete wait function.")},timeout:3e3},options);var start=Utils.timestamp(),elapsed,now,tid,fn=function(){now=Utils.timestamp();elapsed=now-start;Utils.removeFromArray(Galleria._waiters,tid);if(options.until(elapsed)){options.success();return false}if(typeof options.timeout=="number"&&now>=start+options.timeout){options.error();return false}Galleria._waiters.push(tid=window.setTimeout(fn,10))};Galleria._waiters.push(tid=window.setTimeout(fn,10))},toggleQuality:function(img,force){if(IE!==7&&IE!==8||!img||img.nodeName.toUpperCase()!="IMG"){return}if(typeof force==="undefined"){force=img.style.msInterpolationMode==="nearest-neighbor"}img.style.msInterpolationMode=force?"bicubic":"nearest-neighbor"},insertStyleTag:function(styles,id){if(id&&$("#"+id).length){return}var style=doc.createElement("style");if(id){style.id=id}DOM().head.appendChild(style);if(style.styleSheet){style.styleSheet.cssText=styles}else{var cssText=doc.createTextNode(styles);style.appendChild(cssText)}},loadScript:function(url,callback){var done=false,script=$("<scr"+"ipt>").attr({src:url,async:true}).get(0);script.onload=script.onreadystatechange=function(){if(!done&&(!this.readyState||this.readyState==="loaded"||this.readyState==="complete")){done=true;script.onload=script.onreadystatechange=null;if(typeof callback==="function"){callback.call(this,this)}}};DOM().head.appendChild(script)},parseValue:function(val){if(typeof val==="number"){return val}else if(typeof val==="string"){var arr=val.match(/\-?\d|\./g);return arr&&arr.constructor===Array?arr.join("")*1:0}else{return 0}},timestamp:function(){return(new Date).getTime()},loadCSS:function(href,id,callback){var link,length;$("link[rel=stylesheet]").each(function(){if(new RegExp(href).test(this.href)){link=this;return false}});if(typeof id==="function"){callback=id;id=undef}callback=callback||F;if(link){callback.call(link,link);return link}length=doc.styleSheets.length;if($("#"+id).length){$("#"+id).attr("href",href);length--}else{link=$("<link>").attr({rel:"stylesheet",href:href,id:id}).get(0);var styles=$('link[rel="stylesheet"], style');if(styles.length){styles.get(0).parentNode.insertBefore(link,styles[0])}else{DOM().head.appendChild(link)}if(IE&&length>=31){Galleria.raise("You have reached the browser stylesheet limit (31)",true);return}}if(typeof callback==="function"){var $loader=$("<s>").attr("id","galleria-loader").hide().appendTo(DOM().body);Utils.wait({until:function(){return $loader.height()>0},success:function(){$loader.remove();callback.call(link,link)},error:function(){$loader.remove();Galleria.raise("Theme CSS could not load after 20 sec. "+(Galleria.QUIRK?"Your browser is in Quirks Mode, please add a correct doctype.":"Please download the latest theme at http://galleria.io/customer/."),true)},timeout:5e3})}return link}}}(),_playIcon=function(container){var css=".galleria-videoicon{width:60px;height:60px;position:absolute;top:50%;left:50%;z-index:1;"+"margin:-30px 0 0 -30px;cursor:pointer;background:#000;background:rgba(0,0,0,.8);border-radius:3px;-webkit-transition:all 150ms}"+".galleria-videoicon i{width:0px;height:0px;border-style:solid;border-width:10px 0 10px 16px;display:block;"+"border-color:transparent transparent transparent #ffffff;margin:20px 0 0 22px}.galleria-image:hover .galleria-videoicon{background:#000}";Utils.insertStyleTag(css,"galleria-videoicon");return $(Utils.create("galleria-videoicon")).html("<i></i>").appendTo(container).click(function(){$(this).siblings("img").mouseup()})},_transitions=function(){var _slide=function(params,complete,fade,door){var easing=this.getOptions("easing"),distance=this.getStageWidth(),from={left:distance*(params.rewind?-1:1)},to={left:0};if(fade){from.opacity=0;to.opacity=1}else{from.opacity=1}$(params.next).css(from);Utils.animate(params.next,to,{duration:params.speed,complete:function(elems){return function(){complete();elems.css({left:0})}}($(params.next).add(params.prev)),queue:false,easing:easing});if(door){params.rewind=!params.rewind}if(params.prev){from={left:0};to={left:distance*(params.rewind?1:-1)};if(fade){from.opacity=1;to.opacity=0}$(params.prev).css(from);Utils.animate(params.prev,to,{duration:params.speed,queue:false,easing:easing,complete:function(){$(this).css("opacity",0)}})}};return{active:false,init:function(effect,params,complete){if(_transitions.effects.hasOwnProperty(effect)){_transitions.effects[effect].call(this,params,complete)}},effects:{fade:function(params,complete){$(params.next).css({opacity:0,left:0});Utils.animate(params.next,{opacity:1},{duration:params.speed,complete:complete});if(params.prev){$(params.prev).css("opacity",1).show();Utils.animate(params.prev,{opacity:0},{duration:params.speed})}},flash:function(params,complete){$(params.next).css({opacity:0,left:0});if(params.prev){Utils.animate(params.prev,{opacity:0},{duration:params.speed/2,complete:function(){Utils.animate(params.next,{opacity:1},{duration:params.speed,complete:complete})}})}else{Utils.animate(params.next,{opacity:1},{duration:params.speed,complete:complete})}},pulse:function(params,complete){if(params.prev){$(params.prev).hide()}$(params.next).css({opacity:0,left:0}).show();Utils.animate(params.next,{opacity:1},{duration:params.speed,complete:complete})},slide:function(params,complete){_slide.apply(this,Utils.array(arguments))},fadeslide:function(params,complete){_slide.apply(this,Utils.array(arguments).concat([true]))},doorslide:function(params,complete){_slide.apply(this,Utils.array(arguments).concat([false,true]))}}}}();_nativeFullscreen.listen();$.event.special["click:fast"]={propagate:true,add:function(handleObj){var getCoords=function(e){if(e.touches&&e.touches.length){var touch=e.touches[0];return{x:touch.pageX,y:touch.pageY}}};var def={touched:false,touchdown:false,coords:{x:0,y:0},evObj:{}};$(this).data({clickstate:def,timer:0}).on("touchstart.fast",function(e){window.clearTimeout($(this).data("timer"));$(this).data("clickstate",{touched:true,touchdown:true,coords:getCoords(e.originalEvent),evObj:e})}).on("touchmove.fast",function(e){var coords=getCoords(e.originalEvent),state=$(this).data("clickstate"),distance=Math.max(Math.abs(state.coords.x-coords.x),Math.abs(state.coords.y-coords.y));if(distance>6){$(this).data("clickstate",$.extend(state,{touchdown:false}))}}).on("touchend.fast",function(e){var $this=$(this),state=$this.data("clickstate");if(state.touchdown){handleObj.handler.call(this,e)}$this.data("timer",window.setTimeout(function(){$this.data("clickstate",def)},400))}).on("click.fast",function(e){var state=$(this).data("clickstate");if(state.touched){return false}$(this).data("clickstate",def);handleObj.handler.call(this,e)})},remove:function(){$(this).off("touchstart.fast touchmove.fast touchend.fast click.fast")}};$win.on("orientationchange",function(){$(this).resize()});Galleria=function(){var self=this;this._options={};this._playing=false;this._playtime=5e3;this._active=null;this._queue={length:0};this._data=[];this._dom={};this._thumbnails=[];this._layers=[];this._initialized=false;this._firstrun=false;this._stageWidth=0;this._stageHeight=0;this._target=undef;this._binds=[];this._id=parseInt(M.random()*1e4,10);var divs="container stage images image-nav image-nav-left image-nav-right "+"info info-text info-title info-description "+"thumbnails thumbnails-list thumbnails-container thumb-nav-left thumb-nav-right "+"loader counter tooltip",spans="current total";$.each(divs.split(" "),function(i,elemId){self._dom[elemId]=Utils.create("galleria-"+elemId)});$.each(spans.split(" "),function(i,elemId){self._dom[elemId]=Utils.create("galleria-"+elemId,"span")});var keyboard=this._keyboard={keys:{UP:38,DOWN:40,LEFT:37,RIGHT:39,RETURN:13,ESCAPE:27,BACKSPACE:8,SPACE:32},map:{},bound:false,press:function(e){var key=e.keyCode||e.which;if(key in keyboard.map&&typeof keyboard.map[key]==="function"){keyboard.map[key].call(self,e)}},attach:function(map){var key,up;for(key in map){if(map.hasOwnProperty(key)){up=key.toUpperCase();if(up in keyboard.keys){keyboard.map[keyboard.keys[up]]=map[key]}else{keyboard.map[up]=map[key]}}}if(!keyboard.bound){keyboard.bound=true;$doc.on("keydown",keyboard.press)}},detach:function(){keyboard.bound=false;keyboard.map={};$doc.off("keydown",keyboard.press)}};var controls=this._controls={0:undef,1:undef,active:0,swap:function(){controls.active=controls.active?0:1},getActive:function(){return self._options.swipe?controls.slides[self._active]:controls[controls.active]},getNext:function(){return self._options.swipe?controls.slides[self.getNext(self._active)]:controls[1-controls.active]},slides:[],frames:[],layers:[]};var carousel=this._carousel={next:self.$("thumb-nav-right"),prev:self.$("thumb-nav-left"),width:0,current:0,max:0,hooks:[],update:function(){var w=0,h=0,hooks=[0];$.each(self._thumbnails,function(i,thumb){if(thumb.ready){w+=thumb.outerWidth||$(thumb.container).outerWidth(true);var containerWidth=$(thumb.container).width();w+=containerWidth-M.floor(containerWidth);hooks[i+1]=w;h=M.max(h,thumb.outerHeight||$(thumb.container).outerHeight(true))}});self.$("thumbnails").css({width:w,height:h});carousel.max=w;carousel.hooks=hooks;carousel.width=self.$("thumbnails-list").width();carousel.setClasses();self.$("thumbnails-container").toggleClass("galleria-carousel",w>carousel.width);carousel.width=self.$("thumbnails-list").width()},bindControls:function(){var i;carousel.next.on("click:fast",function(e){e.preventDefault();if(self._options.carouselSteps==="auto"){for(i=carousel.current;i<carousel.hooks.length;i++){if(carousel.hooks[i]-carousel.hooks[carousel.current]>carousel.width){carousel.set(i-2);break}}}else{carousel.set(carousel.current+self._options.carouselSteps)}});carousel.prev.on("click:fast",function(e){e.preventDefault();if(self._options.carouselSteps==="auto"){for(i=carousel.current;i>=0;i--){if(carousel.hooks[carousel.current]-carousel.hooks[i]>carousel.width){carousel.set(i+2);break}else if(i===0){carousel.set(0);break}}}else{carousel.set(carousel.current-self._options.carouselSteps)}})},set:function(i){i=M.max(i,0);while(carousel.hooks[i-1]+carousel.width>=carousel.max&&i>=0){i--}carousel.current=i;carousel.animate()},getLast:function(i){return(i||carousel.current)-1},follow:function(i){if(i===0||i===carousel.hooks.length-2){carousel.set(i);return}var last=carousel.current;while(carousel.hooks[last]-carousel.hooks[carousel.current]<carousel.width&&last<=carousel.hooks.length){last++}if(i-1<carousel.current){carousel.set(i-1)}else if(i+2>last){carousel.set(i-last+carousel.current+2)}},setClasses:function(){carousel.prev.toggleClass("disabled",!carousel.current);carousel.next.toggleClass("disabled",carousel.hooks[carousel.current]+carousel.width>=carousel.max)},animate:function(to){carousel.setClasses();var num=carousel.hooks[carousel.current]*-1;if(isNaN(num)){return}self.$("thumbnails").css("left",function(){return $(this).css("left")});Utils.animate(self.get("thumbnails"),{left:num},{duration:self._options.carouselSpeed,easing:self._options.easing,queue:false})}};var tooltip=this._tooltip={initialized:false,open:false,timer:"tooltip"+self._id,swapTimer:"swap"+self._id,init:function(){tooltip.initialized=true;var css=".galleria-tooltip{padding:3px 8px;max-width:50%;background:#ffe;color:#000;z-index:3;position:absolute;font-size:11px;line-height:1.3;"+"opacity:0;box-shadow:0 0 2px rgba(0,0,0,.4);-moz-box-shadow:0 0 2px rgba(0,0,0,.4);-webkit-box-shadow:0 0 2px rgba(0,0,0,.4);}";Utils.insertStyleTag(css,"galleria-tooltip");self.$("tooltip").css({opacity:.8,visibility:"visible",display:"none"})},move:function(e){var mouseX=self.getMousePosition(e).x,mouseY=self.getMousePosition(e).y,$elem=self.$("tooltip"),x=mouseX,y=mouseY,height=$elem.outerHeight(true)+1,width=$elem.outerWidth(true),limitY=height+15;var maxX=self.$("container").width()-width-2,maxY=self.$("container").height()-height-2;if(!isNaN(x)&&!isNaN(y)){x+=10;y-=height+8;x=M.max(0,M.min(maxX,x));y=M.max(0,M.min(maxY,y));if(mouseY<limitY){y=limitY}$elem.css({left:x,top:y})}},bind:function(elem,value){if(Galleria.TOUCH){return}if(!tooltip.initialized){tooltip.init()}var mouseout=function(){self.$("container").off("mousemove",tooltip.move);self.clearTimer(tooltip.timer);self.$("tooltip").stop().animate({opacity:0},200,function(){self.$("tooltip").hide();self.addTimer(tooltip.swapTimer,function(){tooltip.open=false},1e3)})};var hover=function(elem,value){tooltip.define(elem,value);$(elem).hover(function(){self.clearTimer(tooltip.swapTimer);self.$("container").off("mousemove",tooltip.move).on("mousemove",tooltip.move).trigger("mousemove");tooltip.show(elem);self.addTimer(tooltip.timer,function(){self.$("tooltip").stop().show().animate({opacity:1});tooltip.open=true},tooltip.open?0:500)},mouseout).click(mouseout)};if(typeof value==="string"){hover(elem in self._dom?self.get(elem):elem,value)}else{$.each(elem,function(elemID,val){hover(self.get(elemID),val)})}},show:function(elem){elem=$(elem in self._dom?self.get(elem):elem);var text=elem.data("tt"),mouseup=function(e){window.setTimeout(function(ev){return function(){tooltip.move(ev)}}(e),10);elem.off("mouseup",mouseup)};text=typeof text==="function"?text():text;if(!text){return}self.$("tooltip").html(text.replace(/\s/,"&#160;"));elem.on("mouseup",mouseup)},define:function(elem,value){if(typeof value!=="function"){var s=value;value=function(){return s}}elem=$(elem in self._dom?self.get(elem):elem).data("tt",value);tooltip.show(elem)}};var fullscreen=this._fullscreen={scrolled:0,crop:undef,active:false,prev:$(),beforeEnter:function(fn){fn()},beforeExit:function(fn){fn()},keymap:self._keyboard.map,parseCallback:function(callback,enter){return _transitions.active?function(){if(typeof callback=="function"){callback.call(self)}var active=self._controls.getActive(),next=self._controls.getNext();self._scaleImage(next);self._scaleImage(active);if(enter&&self._options.trueFullscreen){$(active.container).add(next.container).trigger("transitionend")}}:callback},enter:function(callback){fullscreen.beforeEnter(function(){callback=fullscreen.parseCallback(callback,true);if(self._options.trueFullscreen&&_nativeFullscreen.support){fullscreen.active=true;Utils.forceStyles(self.get("container"),{width:"100%",height:"100%"});self.rescale();if(Galleria.MAC){if(!(Galleria.SAFARI&&/version\/[1-5]/.test(NAV))){self.$("container").css("opacity",0).addClass("fullscreen");window.setTimeout(function(){fullscreen.scale();self.$("container").css("opacity",1)},50)}else{self.$("stage").css("opacity",0);window.setTimeout(function(){fullscreen.scale();self.$("stage").css("opacity",1)},4)}}else{self.$("container").addClass("fullscreen")}$win.resize(fullscreen.scale);_nativeFullscreen.enter(self,callback,self.get("container"))}else{fullscreen.scrolled=$win.scrollTop();if(!Galleria.TOUCH){window.scrollTo(0,0)}fullscreen._enter(callback)}})},_enter:function(callback){fullscreen.active=true;if(IFRAME){fullscreen.iframe=function(){var elem,refer=doc.referrer,test=doc.createElement("a"),loc=window.location;test.href=refer;if(test.protocol!=loc.protocol||test.hostname!=loc.hostname||test.port!=loc.port){Galleria.raise("Parent fullscreen not available. Iframe protocol, domains and ports must match.");return false}fullscreen.pd=window.parent.document;$(fullscreen.pd).find("iframe").each(function(){var idoc=this.contentDocument||this.contentWindow.document;if(idoc===doc){elem=this;return false}});return elem}()}Utils.hide(self.getActiveImage());if(IFRAME&&fullscreen.iframe){fullscreen.iframe.scrolled=$(window.parent).scrollTop();window.parent.scrollTo(0,0)}var data=self.getData(),options=self._options,inBrowser=!self._options.trueFullscreen||!_nativeFullscreen.support,htmlbody={height:"100%",overflow:"hidden",margin:0,padding:0};if(inBrowser){self.$("container").addClass("fullscreen");fullscreen.prev=self.$("container").prev();if(!fullscreen.prev.length){fullscreen.parent=self.$("container").parent()}self.$("container").appendTo("body");Utils.forceStyles(self.get("container"),{position:Galleria.TOUCH?"absolute":"fixed",top:0,left:0,width:"100%",height:"100%",zIndex:1e4});Utils.forceStyles(DOM().html,htmlbody);Utils.forceStyles(DOM().body,htmlbody)}if(IFRAME&&fullscreen.iframe){Utils.forceStyles(fullscreen.pd.documentElement,htmlbody);Utils.forceStyles(fullscreen.pd.body,htmlbody);Utils.forceStyles(fullscreen.iframe,$.extend(htmlbody,{width:"100%",height:"100%",top:0,left:0,position:"fixed",zIndex:1e4,border:"none"}))}fullscreen.keymap=$.extend({},self._keyboard.map);self.attachKeyboard({escape:self.exitFullscreen,right:self.next,left:self.prev});fullscreen.crop=options.imageCrop;if(options.fullscreenCrop!=undef){options.imageCrop=options.fullscreenCrop}if(data&&data.big&&data.image!==data.big){var big=new Galleria.Picture,cached=big.isCached(data.big),index=self.getIndex(),thumb=self._thumbnails[index];self.trigger({type:Galleria.LOADSTART,cached:cached,rewind:false,index:index,imageTarget:self.getActiveImage(),thumbTarget:thumb,galleriaData:data});big.load(data.big,function(big){self._scaleImage(big,{complete:function(big){self.trigger({type:Galleria.LOADFINISH,cached:cached,index:index,rewind:false,imageTarget:big.image,thumbTarget:thumb});var image=self._controls.getActive().image;if(image){$(image).width(big.image.width).height(big.image.height).attr("style",$(big.image).attr("style")).attr("src",big.image.src)}}})});var n=self.getNext(index),p=new Galleria.Picture,ndata=self.getData(n);p.preload(self.isFullscreen()&&ndata.big?ndata.big:ndata.image)}self.rescale(function(){self.addTimer(false,function(){if(inBrowser){Utils.show(self.getActiveImage())}if(typeof callback==="function"){callback.call(self)}self.rescale()},100);self.trigger(Galleria.FULLSCREEN_ENTER)});if(!inBrowser){Utils.show(self.getActiveImage())}else{$win.resize(fullscreen.scale)}},scale:function(){self.rescale()},exit:function(callback){fullscreen.beforeExit(function(){callback=fullscreen.parseCallback(callback);if(self._options.trueFullscreen&&_nativeFullscreen.support){_nativeFullscreen.exit(callback)}else{fullscreen._exit(callback)}})},_exit:function(callback){fullscreen.active=false;var inBrowser=!self._options.trueFullscreen||!_nativeFullscreen.support,$container=self.$("container").removeClass("fullscreen");if(fullscreen.parent){fullscreen.parent.prepend($container)}else{$container.insertAfter(fullscreen.prev)}if(inBrowser){Utils.hide(self.getActiveImage());Utils.revertStyles(self.get("container"),DOM().html,DOM().body);if(!Galleria.TOUCH){window.scrollTo(0,fullscreen.scrolled)}var frame=self._controls.frames[self._controls.active];if(frame&&frame.image){frame.image.src=frame.image.src}}if(IFRAME&&fullscreen.iframe){Utils.revertStyles(fullscreen.pd.documentElement,fullscreen.pd.body,fullscreen.iframe);if(fullscreen.iframe.scrolled){window.parent.scrollTo(0,fullscreen.iframe.scrolled)}}self.detachKeyboard();self.attachKeyboard(fullscreen.keymap);self._options.imageCrop=fullscreen.crop;var big=self.getData().big,image=self._controls.getActive().image;if(!self.getData().iframe&&image&&big&&big==image.src){window.setTimeout(function(src){return function(){image.src=src}}(self.getData().image),1)}self.rescale(function(){self.addTimer(false,function(){if(inBrowser){Utils.show(self.getActiveImage())}if(typeof callback==="function"){callback.call(self)}$win.trigger("resize")},50);self.trigger(Galleria.FULLSCREEN_EXIT)});$win.off("resize",fullscreen.scale)}};var idle=this._idle={trunk:[],bound:false,active:false,add:function(elem,to,from,hide){if(!elem||Galleria.TOUCH){return}if(!idle.bound){idle.addEvent()}elem=$(elem);if(typeof from=="boolean"){hide=from;from={}}from=from||{};var extract={},style;for(style in to){if(to.hasOwnProperty(style)){extract[style]=elem.css(style)}}elem.data("idle",{from:$.extend(extract,from),to:to,complete:true,busy:false});if(!hide){idle.addTimer()}else{elem.css(to)}idle.trunk.push(elem)},remove:function(elem){elem=$(elem);$.each(idle.trunk,function(i,el){if(el&&el.length&&!el.not(elem).length){elem.css(elem.data("idle").from);idle.trunk.splice(i,1)}});if(!idle.trunk.length){idle.removeEvent();self.clearTimer(idle.timer)}},addEvent:function(){idle.bound=true;self.$("container").on("mousemove click",idle.showAll);if(self._options.idleMode=="hover"){self.$("container").on("mouseleave",idle.hide)}},removeEvent:function(){idle.bound=false;self.$("container").on("mousemove click",idle.showAll);if(self._options.idleMode=="hover"){self.$("container").off("mouseleave",idle.hide)}},addTimer:function(){if(self._options.idleMode=="hover"){return}self.addTimer("idle",function(){idle.hide()},self._options.idleTime)},hide:function(){if(!self._options.idleMode||self.getIndex()===false){return}self.trigger(Galleria.IDLE_ENTER);var len=idle.trunk.length;$.each(idle.trunk,function(i,elem){var data=elem.data("idle");if(!data){return}elem.data("idle").complete=false;Utils.animate(elem,data.to,{duration:self._options.idleSpeed,complete:function(){if(i==len-1){idle.active=false}}})})},showAll:function(){self.clearTimer("idle");$.each(idle.trunk,function(i,elem){idle.show(elem)})},show:function(elem){var data=elem.data("idle");if(!idle.active||!data.busy&&!data.complete){data.busy=true;self.trigger(Galleria.IDLE_EXIT);self.clearTimer("idle");Utils.animate(elem,data.from,{duration:self._options.idleSpeed/2,complete:function(){idle.active=true;$(elem).data("idle").busy=false;$(elem).data("idle").complete=true}})}idle.addTimer()}};var lightbox=this._lightbox={width:0,height:0,initialized:false,active:null,image:null,elems:{},keymap:false,init:function(){if(lightbox.initialized){return}lightbox.initialized=true;var elems="overlay box content shadow title info close prevholder prev nextholder next counter image",el={},op=self._options,css="",abs="position:absolute;",prefix="lightbox-",cssMap={
overlay:"position:fixed;display:none;opacity:"+op.overlayOpacity+";filter:alpha(opacity="+op.overlayOpacity*100+");top:0;left:0;width:100%;height:100%;background:"+op.overlayBackground+";z-index:99990",box:"position:fixed;display:none;width:400px;height:400px;top:50%;left:50%;margin-top:-200px;margin-left:-200px;z-index:99991",shadow:abs+"background:#000;width:100%;height:100%;",content:abs+"background-color:#fff;top:10px;left:10px;right:10px;bottom:10px;overflow:hidden",info:abs+"bottom:10px;left:10px;right:10px;color:#444;font:11px/13px arial,sans-serif;height:13px",close:abs+"top:10px;right:10px;height:20px;width:20px;background:#fff;text-align:center;cursor:pointer;color:#444;font:16px/22px arial,sans-serif;z-index:99999",image:abs+"top:10px;left:10px;right:10px;bottom:30px;overflow:hidden;display:block;",prevholder:abs+"width:50%;top:0;bottom:40px;cursor:pointer;",nextholder:abs+"width:50%;top:0;bottom:40px;right:-1px;cursor:pointer;",prev:abs+"top:50%;margin-top:-20px;height:40px;width:30px;background:#fff;left:20px;display:none;text-align:center;color:#000;font:bold 16px/36px arial,sans-serif",next:abs+"top:50%;margin-top:-20px;height:40px;width:30px;background:#fff;right:20px;left:auto;display:none;font:bold 16px/36px arial,sans-serif;text-align:center;color:#000",title:"float:left",counter:"float:right;margin-left:8px;"},hover=function(elem){return elem.hover(function(){$(this).css("color","#bbb")},function(){$(this).css("color","#444")})},appends={};var exs="";if(IE>7){exs=IE<9?"background:#000;filter:alpha(opacity=0);":"background:rgba(0,0,0,0);"}else{exs="z-index:99999"}cssMap.nextholder+=exs;cssMap.prevholder+=exs;$.each(cssMap,function(key,value){css+=".galleria-"+prefix+key+"{"+value+"}"});css+=".galleria-"+prefix+"box.iframe .galleria-"+prefix+"prevholder,"+".galleria-"+prefix+"box.iframe .galleria-"+prefix+"nextholder{"+"width:100px;height:100px;top:50%;margin-top:-70px}";Utils.insertStyleTag(css,"galleria-lightbox");$.each(elems.split(" "),function(i,elemId){self.addElement("lightbox-"+elemId);el[elemId]=lightbox.elems[elemId]=self.get("lightbox-"+elemId)});lightbox.image=new Galleria.Picture;$.each({box:"shadow content close prevholder nextholder",info:"title counter",content:"info image",prevholder:"prev",nextholder:"next"},function(key,val){var arr=[];$.each(val.split(" "),function(i,prop){arr.push(prefix+prop)});appends[prefix+key]=arr});self.append(appends);$(el.image).append(lightbox.image.container);$(DOM().body).append(el.overlay,el.box);hover($(el.close).on("click:fast",lightbox.hide).html("&#215;"));$.each(["Prev","Next"],function(i,dir){var $d=$(el[dir.toLowerCase()]).html(/v/.test(dir)?"&#8249;&#160;":"&#160;&#8250;"),$e=$(el[dir.toLowerCase()+"holder"]);$e.on("click:fast",function(){lightbox["show"+dir]()});if(IE<8||Galleria.TOUCH){$d.show();return}$e.hover(function(){$d.show()},function(e){$d.stop().fadeOut(200)})});$(el.overlay).on("click:fast",lightbox.hide);if(Galleria.IPAD){self._options.lightboxTransitionSpeed=0}},rescale:function(event){var width=M.min($win.width()-40,lightbox.width),height=M.min($win.height()-60,lightbox.height),ratio=M.min(width/lightbox.width,height/lightbox.height),destWidth=M.round(lightbox.width*ratio)+40,destHeight=M.round(lightbox.height*ratio)+60,to={width:destWidth,height:destHeight,"margin-top":M.ceil(destHeight/2)*-1,"margin-left":M.ceil(destWidth/2)*-1};if(event){$(lightbox.elems.box).css(to)}else{$(lightbox.elems.box).animate(to,{duration:self._options.lightboxTransitionSpeed,easing:self._options.easing,complete:function(){var image=lightbox.image,speed=self._options.lightboxFadeSpeed;self.trigger({type:Galleria.LIGHTBOX_IMAGE,imageTarget:image.image});$(image.container).show();$(image.image).animate({opacity:1},speed);Utils.show(lightbox.elems.info,speed)}})}},hide:function(){lightbox.image.image=null;$win.off("resize",lightbox.rescale);$(lightbox.elems.box).hide().find("iframe").remove();Utils.hide(lightbox.elems.info);self.detachKeyboard();self.attachKeyboard(lightbox.keymap);lightbox.keymap=false;Utils.hide(lightbox.elems.overlay,200,function(){$(this).hide().css("opacity",self._options.overlayOpacity);self.trigger(Galleria.LIGHTBOX_CLOSE)})},showNext:function(){lightbox.show(self.getNext(lightbox.active))},showPrev:function(){lightbox.show(self.getPrev(lightbox.active))},show:function(index){lightbox.active=index=typeof index==="number"?index:self.getIndex()||0;if(!lightbox.initialized){lightbox.init()}self.trigger(Galleria.LIGHTBOX_OPEN);if(!lightbox.keymap){lightbox.keymap=$.extend({},self._keyboard.map);self.attachKeyboard({escape:lightbox.hide,right:lightbox.showNext,left:lightbox.showPrev})}$win.off("resize",lightbox.rescale);var data=self.getData(index),total=self.getDataLength(),n=self.getNext(index),ndata,p,i;Utils.hide(lightbox.elems.info);try{for(i=self._options.preload;i>0;i--){p=new Galleria.Picture;ndata=self.getData(n);p.preload(ndata.big?ndata.big:ndata.image);n=self.getNext(n)}}catch(e){}lightbox.image.isIframe=data.iframe&&!data.image;$(lightbox.elems.box).toggleClass("iframe",lightbox.image.isIframe);$(lightbox.image.container).find(".galleria-videoicon").remove();lightbox.image.load(data.big||data.image||data.iframe,function(image){if(image.isIframe){var cw=$(window).width(),ch=$(window).height();if(image.video&&self._options.maxVideoSize){var r=M.min(self._options.maxVideoSize/cw,self._options.maxVideoSize/ch);if(r<1){cw*=r;ch*=r}}lightbox.width=cw;lightbox.height=ch}else{lightbox.width=image.original.width;lightbox.height=image.original.height}$(image.image).css({width:image.isIframe?"100%":"100.1%",height:image.isIframe?"100%":"100.1%",top:0,bottom:0,zIndex:99998,opacity:0,visibility:"visible"}).parent().height("100%");lightbox.elems.title.innerHTML=data.title||"";lightbox.elems.counter.innerHTML=index+1+" / "+total;$win.resize(lightbox.rescale);lightbox.rescale();if(data.image&&data.iframe){$(lightbox.elems.box).addClass("iframe");if(data.video){var $icon=_playIcon(image.container).hide();window.setTimeout(function(){$icon.fadeIn(200)},200)}$(image.image).css("cursor","pointer").mouseup(function(data,image){return function(e){$(lightbox.image.container).find(".galleria-videoicon").remove();e.preventDefault();image.isIframe=true;image.load(data.iframe+(data.video?"&autoplay=1":""),{width:"100%",height:IE<8?$(lightbox.image.container).height():"100%"})}}(data,image))}});$(lightbox.elems.overlay).show().css("visibility","visible");$(lightbox.elems.box).show()}};var _timer=this._timer={trunk:{},add:function(id,fn,delay,loop){id=id||(new Date).getTime();loop=loop||false;this.clear(id);if(loop){var old=fn;fn=function(){old();_timer.add(id,fn,delay)}}this.trunk[id]=window.setTimeout(fn,delay)},clear:function(id){var del=function(i){window.clearTimeout(this.trunk[i]);delete this.trunk[i]},i;if(!!id&&id in this.trunk){del.call(this,id)}else if(typeof id==="undefined"){for(i in this.trunk){if(this.trunk.hasOwnProperty(i)){del.call(this,i)}}}}};return this};Galleria.prototype={constructor:Galleria,init:function(target,options){options=_legacyOptions(options);this._original={target:target,options:options,data:null};this._target=this._dom.target=target.nodeName?target:$(target).get(0);this._original.html=this._target.innerHTML;_instances.push(this);if(!this._target){Galleria.raise("Target not found",true);return}this._options={autoplay:false,carousel:true,carouselFollow:true,carouselSpeed:400,carouselSteps:"auto",clicknext:false,dailymotion:{foreground:"%23EEEEEE",highlight:"%235BCEC5",background:"%23222222",logo:0,hideInfos:1},dataConfig:function(elem){return{}},dataSelector:"img",dataSort:false,dataSource:this._target,debug:undef,dummy:undef,easing:"galleria",extend:function(options){},fullscreenCrop:undef,fullscreenDoubleTap:true,fullscreenTransition:undef,height:0,idleMode:true,idleTime:3e3,idleSpeed:200,imageCrop:false,imageMargin:0,imagePan:false,imagePanSmoothness:12,imagePosition:"50%",imageTimeout:undef,initialTransition:undef,keepSource:false,layerFollow:true,lightbox:false,lightboxFadeSpeed:200,lightboxTransitionSpeed:200,linkSourceImages:true,maxScaleRatio:undef,maxVideoSize:undef,minScaleRatio:undef,overlayOpacity:.85,overlayBackground:"#0b0b0b",pauseOnInteraction:true,popupLinks:false,preload:2,queue:true,responsive:true,show:0,showInfo:true,showCounter:true,showImagenav:true,swipe:"auto",theme:null,thumbCrop:true,thumbEventType:"click:fast",thumbMargin:0,thumbQuality:"auto",thumbDisplayOrder:true,thumbPosition:"50%",thumbnails:true,touchTransition:undef,transition:"fade",transitionInitial:undef,transitionSpeed:400,trueFullscreen:true,useCanvas:false,variation:"",videoPoster:true,vimeo:{title:0,byline:0,portrait:0,color:"aaaaaa"},wait:5e3,width:"auto",youtube:{modestbranding:1,autohide:1,color:"white",hd:1,rel:0,showinfo:0}};this._options.initialTransition=this._options.initialTransition||this._options.transitionInitial;if(options){if(options.debug===false){DEBUG=false}if(typeof options.imageTimeout==="number"){TIMEOUT=options.imageTimeout}if(typeof options.dummy==="string"){DUMMY=options.dummy}if(typeof options.theme=="string"){this._options.theme=options.theme}}$(this._target).children().hide();if(Galleria.QUIRK){Galleria.raise("Your page is in Quirks mode, Galleria may not render correctly. Please validate your HTML and add a correct doctype.")}if(_loadedThemes.length){if(this._options.theme){for(var i=0;i<_loadedThemes.length;i++){if(this._options.theme===_loadedThemes[i].name){this.theme=_loadedThemes[i];break}}}else{this.theme=_loadedThemes[0]}}if(typeof this.theme=="object"){this._init()}else{_pool.push(this)}return this},_init:function(){var self=this,options=this._options;if(this._initialized){Galleria.raise("Init failed: Gallery instance already initialized.");return this}this._initialized=true;if(!this.theme){Galleria.raise("Init failed: No theme found.",true);return this}$.extend(true,options,this.theme.defaults,this._original.options,Galleria.configure.options);options.swipe=function(s){if(s=="enforced"){return true}if(s===false||s=="disabled"){return false}return!!Galleria.TOUCH}(options.swipe);if(options.swipe){options.clicknext=false;options.imagePan=false}(function(can){if(!("getContext"in can)){can=null;return}_canvas=_canvas||{elem:can,context:can.getContext("2d"),cache:{},length:0}})(doc.createElement("canvas"));this.bind(Galleria.DATA,function(){if(window.screen&&window.screen.width&&Array.prototype.forEach){this._data.forEach(function(data){var density="devicePixelRatio"in window?window.devicePixelRatio:1,m=M.max(window.screen.width,window.screen.height);if(m*density<1024){data.big=data.image}})}this._original.data=this._data;this.get("total").innerHTML=this.getDataLength();var $container=this.$("container");if(self._options.height<2){self._userRatio=self._ratio=self._options.height}var num={width:0,height:0};var testHeight=function(){return self.$("stage").height()};Utils.wait({until:function(){num=self._getWH();$container.width(num.width).height(num.height);return testHeight()&&num.width&&num.height>50},success:function(){self._width=num.width;self._height=num.height;self._ratio=self._ratio||num.height/num.width;if(Galleria.WEBKIT){window.setTimeout(function(){self._run()},1)}else{self._run()}},error:function(){if(testHeight()){Galleria.raise("Could not extract sufficient width/height of the gallery container. Traced measures: width:"+num.width+"px, height: "+num.height+"px.",true)}else{Galleria.raise("Could not extract a stage height from the CSS. Traced height: "+testHeight()+"px.",true)}},timeout:typeof this._options.wait=="number"?this._options.wait:false})});this.append({"info-text":["info-title","info-description"],info:["info-text"],"image-nav":["image-nav-right","image-nav-left"],stage:["images","loader","counter","image-nav"],"thumbnails-list":["thumbnails"],"thumbnails-container":["thumb-nav-left","thumbnails-list","thumb-nav-right"],container:["stage","thumbnails-container","info","tooltip"]});Utils.hide(this.$("counter").append(this.get("current"),doc.createTextNode(" / "),this.get("total")));this.setCounter("&#8211;");Utils.hide(self.get("tooltip"));this.$("container").addClass([Galleria.TOUCH?"touch":"notouch",this._options.variation,"galleria-theme-"+this.theme.name].join(" "));if(!this._options.swipe){$.each(new Array(2),function(i){var image=new Galleria.Picture;$(image.container).css({position:"absolute",top:0,left:0}).prepend(self._layers[i]=$(Utils.create("galleria-layer")).css({position:"absolute",top:0,left:0,right:0,bottom:0,zIndex:2})[0]);self.$("images").append(image.container);self._controls[i]=image;var frame=new Galleria.Picture;frame.isIframe=true;$(frame.container).attr("class","galleria-frame").css({position:"absolute",top:0,left:0,zIndex:4,background:"#000",display:"none"}).appendTo(image.container);self._controls.frames[i]=frame})}this.$("images").css({position:"relative",top:0,left:0,width:"100%",height:"100%"});if(options.swipe){this.$("images").css({position:"absolute",top:0,left:0,width:0,height:"100%"});this.finger=new Galleria.Finger(this.get("stage"),{onchange:function(page){self.pause().show(page)},oncomplete:function(page){var index=M.max(0,M.min(parseInt(page,10),self.getDataLength()-1)),data=self.getData(index);$(self._thumbnails[index].container).addClass("active").siblings(".active").removeClass("active");if(!data){return}self.$("images").find(".galleria-frame").css("opacity",0).hide().find("iframe").remove();if(self._options.carousel&&self._options.carouselFollow){self._carousel.follow(index)}}});this.bind(Galleria.RESCALE,function(){this.finger.setup()});this.$("stage").on("click",function(e){var data=self.getData();if(!data){return}if(data.iframe){if(self.isPlaying()){self.pause()}var frame=self._controls.frames[self._active],w=self._stageWidth,h=self._stageHeight;if($(frame.container).find("iframe").length){return}$(frame.container).css({width:w,height:h,opacity:0}).show().animate({opacity:1},200);window.setTimeout(function(){frame.load(data.iframe+(data.video?"&autoplay=1":""),{width:w,height:h},function(frame){self.$("container").addClass("videoplay");frame.scale({width:self._stageWidth,height:self._stageHeight,iframelimit:data.video?self._options.maxVideoSize:undef})})},100);return}if(data.link){if(self._options.popupLinks){var win=window.open(data.link,"_blank")}else{window.location.href=data.link}return}});this.bind(Galleria.IMAGE,function(e){self.setCounter(e.index);self.setInfo(e.index);var next=this.getNext(),prev=this.getPrev();var preloads=[prev,next];preloads.push(this.getNext(next),this.getPrev(prev),self._controls.slides.length-1);var filtered=[];$.each(preloads,function(i,val){if($.inArray(val,filtered)==-1){filtered.push(val)}});$.each(filtered,function(i,loadme){var d=self.getData(loadme),img=self._controls.slides[loadme],src=self.isFullscreen()&&d.big?d.big:d.image||d.iframe;if(d.iframe&&!d.image){img.isIframe=true}if(!img.ready){self._controls.slides[loadme].load(src,function(img){if(!img.isIframe){$(img.image).css("visibility","hidden")}self._scaleImage(img,{complete:function(img){if(!img.isIframe){$(img.image).css({opacity:0,visibility:"visible"}).animate({opacity:1},200)}}})})}})})}this.$("thumbnails, thumbnails-list").css({overflow:"hidden",position:"relative"});this.$("image-nav-right, image-nav-left").on("click:fast",function(e){if(options.pauseOnInteraction){self.pause()}var fn=/right/.test(this.className)?"next":"prev";self[fn]()}).on("click",function(e){e.preventDefault();if(options.clicknext||options.swipe){e.stopPropagation()}});$.each(["info","counter","image-nav"],function(i,el){if(options["show"+el.substr(0,1).toUpperCase()+el.substr(1).replace(/-/,"")]===false){Utils.moveOut(self.get(el.toLowerCase()))}});this.load();if(!options.keepSource&&!IE){this._target.innerHTML=""}if(this.get("errors")){this.appendChild("target","errors")}this.appendChild("target","container");if(options.carousel){var count=0,show=options.show;this.bind(Galleria.THUMBNAIL,function(){this.updateCarousel();if(++count==this.getDataLength()&&typeof show=="number"&&show>0){this._carousel.follow(show)}})}if(options.responsive){$win.on("resize",function(){if(!self.isFullscreen()){self.resize()}})}if(options.fullscreenDoubleTap){this.$("stage").on("touchstart",function(){var last,cx,cy,lx,ly,now,getData=function(e){return e.originalEvent.touches?e.originalEvent.touches[0]:e};self.$("stage").on("touchmove",function(){last=0});return function(e){if(/(-left|-right)/.test(e.target.className)){return}now=Utils.timestamp();cx=getData(e).pageX;cy=getData(e).pageY;if(e.originalEvent.touches.length<2&&now-last<300&&cx-lx<20&&cy-ly<20){self.toggleFullscreen();e.preventDefault();return}last=now;lx=cx;ly=cy}}())}$.each(Galleria.on.binds,function(i,bind){if($.inArray(bind.hash,self._binds)==-1){self.bind(bind.type,bind.callback)}});return this},addTimer:function(){this._timer.add.apply(this._timer,Utils.array(arguments));return this},clearTimer:function(){this._timer.clear.apply(this._timer,Utils.array(arguments));return this},_getWH:function(){var $container=this.$("container"),$target=this.$("target"),self=this,num={},arr;$.each(["width","height"],function(i,m){if(self._options[m]&&typeof self._options[m]==="number"){num[m]=self._options[m]}else{arr=[Utils.parseValue($container.css(m)),Utils.parseValue($target.css(m)),$container[m](),$target[m]()];if(!self["_"+m]){arr.splice(arr.length,Utils.parseValue($container.css("min-"+m)),Utils.parseValue($target.css("min-"+m)))}num[m]=M.max.apply(M,arr)}});if(self._userRatio){num.height=num.width*self._userRatio}return num},_createThumbnails:function(push){this.get("total").innerHTML=this.getDataLength();var src,thumb,data,$container,self=this,o=this._options,i=push?this._data.length-push.length:0,chunk=i,thumbchunk=[],loadindex=0,gif=IE<8?"http://upload.wikimedia.org/wikipedia/commons/c/c0/Blank.gif":"data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw%3D%3D",active=function(){var a=self.$("thumbnails").find(".active");if(!a.length){return false}return a.find("img").attr("src")}(),optval=typeof o.thumbnails==="string"?o.thumbnails.toLowerCase():null,getStyle=function(prop){return doc.defaultView&&doc.defaultView.getComputedStyle?doc.defaultView.getComputedStyle(thumb.container,null)[prop]:$container.css(prop)},fake=function(image,index,container){return function(){$(container).append(image);self.trigger({type:Galleria.THUMBNAIL,thumbTarget:image,index:index,galleriaData:self.getData(index)})}},onThumbEvent=function(e){if(o.pauseOnInteraction){self.pause()}var index=$(e.currentTarget).data("index");if(self.getIndex()!==index){self.show(index)}e.preventDefault()},thumbComplete=function(thumb,callback){$(thumb.container).css("visibility","visible");self.trigger({type:Galleria.THUMBNAIL,thumbTarget:thumb.image,index:thumb.data.order,galleriaData:self.getData(thumb.data.order)});if(typeof callback=="function"){callback.call(self,thumb)}},onThumbLoad=function(thumb,callback){thumb.scale({width:thumb.data.width,height:thumb.data.height,crop:o.thumbCrop,margin:o.thumbMargin,canvas:o.useCanvas,position:o.thumbPosition,complete:function(thumb){var top=["left","top"],arr=["Width","Height"],m,css,data=self.getData(thumb.index);$.each(arr,function(i,measure){m=measure.toLowerCase();if(o.thumbCrop!==true||o.thumbCrop===m){css={};css[m]=thumb[m];$(thumb.container).css(css);css={};css[top[i]]=0;$(thumb.image).css(css)}thumb["outer"+measure]=$(thumb.container)["outer"+measure](true)});Utils.toggleQuality(thumb.image,o.thumbQuality===true||o.thumbQuality==="auto"&&thumb.original.width<thumb.width*3);if(o.thumbDisplayOrder&&!thumb.lazy){$.each(thumbchunk,function(i,th){if(i===loadindex&&th.ready&&!th.displayed){loadindex++;th.displayed=true;thumbComplete(th,callback);return}})}else{thumbComplete(thumb,callback)}}})};if(!push){this._thumbnails=[];this.$("thumbnails").empty()}for(;this._data[i];i++){data=this._data[i];src=data.thumb||data.image;if((o.thumbnails===true||optval=="lazy")&&(data.thumb||data.image)){thumb=new Galleria.Picture(i);thumb.index=i;thumb.displayed=false;thumb.lazy=false;thumb.video=false;this.$("thumbnails").append(thumb.container);$container=$(thumb.container);$container.css("visibility","hidden");thumb.data={width:Utils.parseValue(getStyle("width")),height:Utils.parseValue(getStyle("height")),order:i,src:src};if(o.thumbCrop!==true){$container.css({width:"auto",height:"auto"})}else{$container.css({width:thumb.data.width,height:thumb.data.height})}if(optval=="lazy"){$container.addClass("lazy");thumb.lazy=true;thumb.load(gif,{height:thumb.data.height,width:thumb.data.width})}else{thumb.load(src,onThumbLoad)}if(o.preload==="all"){thumb.preload(data.image)}}else if(data.iframe&&optval!==null||optval==="empty"||optval==="numbers"){thumb={container:Utils.create("galleria-image"),image:Utils.create("img","span"),ready:true,data:{order:i}};if(optval==="numbers"){$(thumb.image).text(i+1)}if(data.iframe){$(thumb.image).addClass("iframe")}this.$("thumbnails").append(thumb.container);window.setTimeout(fake(thumb.image,i,thumb.container),50+i*20)}else{thumb={container:null,image:null}}$(thumb.container).add(o.keepSource&&o.linkSourceImages?data.original:null).data("index",i).on(o.thumbEventType,onThumbEvent).data("thumbload",onThumbLoad);if(active===src){$(thumb.container).addClass("active")}this._thumbnails.push(thumb)}thumbchunk=this._thumbnails.slice(chunk);return this},lazyLoad:function(index,complete){var arr=index.constructor==Array?index:[index],self=this,loaded=0;$.each(arr,function(i,ind){if(ind>self._thumbnails.length-1){return}var thumb=self._thumbnails[ind],data=thumb.data,callback=function(){if(++loaded==arr.length&&typeof complete=="function"){complete.call(self)}},thumbload=$(thumb.container).data("thumbload");if(thumb.video){thumbload.call(self,thumb,callback)}else{thumb.load(data.src,function(thumb){thumbload.call(self,thumb,callback)})}});return this},lazyLoadChunks:function(size,delay){var len=this.getDataLength(),i=0,n=0,arr=[],temp=[],self=this;delay=delay||0;for(;i<len;i++){temp.push(i);if(++n==size||i==len-1){arr.push(temp);n=0;temp=[]}}var init=function(wait){var a=arr.shift();if(a){window.setTimeout(function(){self.lazyLoad(a,function(){init(true)})},delay&&wait?delay:0)}};init(false);return this},_run:function(){var self=this;self._createThumbnails();Utils.wait({timeout:1e4,until:function(){if(Galleria.OPERA){self.$("stage").css("display","inline-block")}self._stageWidth=self.$("stage").width();self._stageHeight=self.$("stage").height();return self._stageWidth&&self._stageHeight>50},success:function(){_galleries.push(self);if(self._options.swipe){var $images=self.$("images").width(self.getDataLength()*self._stageWidth);$.each(new Array(self.getDataLength()),function(i){var image=new Galleria.Picture,data=self.getData(i);$(image.container).css({position:"absolute",top:0,left:self._stageWidth*i}).prepend(self._layers[i]=$(Utils.create("galleria-layer")).css({position:"absolute",top:0,left:0,right:0,bottom:0,zIndex:2})[0]).appendTo($images);if(data.video){_playIcon(image.container)}self._controls.slides.push(image);var frame=new Galleria.Picture;frame.isIframe=true;$(frame.container).attr("class","galleria-frame").css({position:"absolute",top:0,left:0,zIndex:4,background:"#000",display:"none"}).appendTo(image.container);self._controls.frames.push(frame)});self.finger.setup()}Utils.show(self.get("counter"));if(self._options.carousel){self._carousel.bindControls()}if(self._options.autoplay){self.pause();if(typeof self._options.autoplay==="number"){self._playtime=self._options.autoplay}self._playing=true}if(self._firstrun){if(self._options.autoplay){self.trigger(Galleria.PLAY)}if(typeof self._options.show==="number"){self.show(self._options.show)}return}self._firstrun=true;if(Galleria.History){Galleria.History.change(function(value){if(isNaN(value)){window.history.go(-1)}else{self.show(value,undef,true)}})}self.trigger(Galleria.READY);self.theme.init.call(self,self._options);$.each(Galleria.ready.callbacks,function(i,fn){if(typeof fn=="function"){fn.call(self,self._options)}});self._options.extend.call(self,self._options);if(/^[0-9]{1,4}$/.test(HASH)&&Galleria.History){self.show(HASH,undef,true)}else if(self._data[self._options.show]){self.show(self._options.show)}if(self._options.autoplay){self.trigger(Galleria.PLAY)}},error:function(){Galleria.raise("Stage width or height is too small to show the gallery. Traced measures: width:"+self._stageWidth+"px, height: "+self._stageHeight+"px.",true)}})},load:function(source,selector,config){var self=this,o=this._options;this._data=[];this._thumbnails=[];this.$("thumbnails").empty();if(typeof selector==="function"){config=selector;selector=null}source=source||o.dataSource;selector=selector||o.dataSelector;config=config||o.dataConfig;if($.isPlainObject(source)){source=[source]}if($.isArray(source)){if(this.validate(source)){this._data=source}else{Galleria.raise("Load failed: JSON Array not valid.")}}else{selector+=",.video,.iframe";$(source).find(selector).each(function(i,elem){elem=$(elem);var data={},parent=elem.parent(),href=parent.attr("href"),rel=parent.attr("rel");if(href&&(elem[0].nodeName=="IMG"||elem.hasClass("video"))&&_videoTest(href)){data.video=href}else if(href&&elem.hasClass("iframe")){data.iframe=href}else{data.image=data.big=href}if(rel){data.big=rel}$.each("big title description link layer image".split(" "),function(i,val){if(elem.data(val)){data[val]=elem.data(val).toString()}});if(!data.big){data.big=data.image}self._data.push($.extend({title:elem.attr("title")||"",thumb:elem.attr("src"),image:elem.attr("src"),big:elem.attr("src"),description:elem.attr("alt")||"",link:elem.attr("longdesc"),original:elem.get(0)},data,config(elem)))})}if(typeof o.dataSort=="function"){protoArray.sort.call(this._data,o.dataSort)}else if(o.dataSort=="random"){this._data.sort(function(){return M.round(M.random())-.5})}if(this.getDataLength()){this._parseData(function(){this.trigger(Galleria.DATA)})}return this},_parseData:function(callback){var self=this,current,ready=false,onload=function(){var complete=true;$.each(self._data,function(i,data){if(data.loading){complete=false;return false}});if(complete&&!ready){ready=true;callback.call(self)}};$.each(this._data,function(i,data){current=self._data[i];if("thumb"in data===false){current.thumb=data.image}if(!data.big){current.big=data.image}if("video"in data){var result=_videoTest(data.video);if(result){current.iframe=new Video(result.provider,result.id).embed()+function(){if(typeof self._options[result.provider]=="object"){var str="?",arr=[];$.each(self._options[result.provider],function(key,val){arr.push(key+"="+val)});if(result.provider=="youtube"){arr=["wmode=opaque"].concat(arr)}return str+arr.join("&")}return""}();if(!current.thumb||!current.image){$.each(["thumb","image"],function(i,type){if(type=="image"&&!self._options.videoPoster){current.image=undef;return}var video=new Video(result.provider,result.id);if(!current[type]){current.loading=true;video.getMedia(type,function(current,type){return function(src){current[type]=src;if(type=="image"&&!current.big){current.big=current.image}delete current.loading;onload()}}(current,type))}})}}}});onload();return this},destroy:function(){this.$("target").data("galleria",null);this.$("container").off("galleria");this.get("target").innerHTML=this._original.html;this.clearTimer();Utils.removeFromArray(_instances,this);Utils.removeFromArray(_galleries,this);if(Galleria._waiters.length){$.each(Galleria._waiters,function(i,w){if(w)window.clearTimeout(w)})}return this},splice:function(){var self=this,args=Utils.array(arguments);window.setTimeout(function(){protoArray.splice.apply(self._data,args);self._parseData(function(){self._createThumbnails()})},2);return self},push:function(){var self=this,args=Utils.array(arguments);if(args.length==1&&args[0].constructor==Array){args=args[0]}window.setTimeout(function(){protoArray.push.apply(self._data,args);self._parseData(function(){self._createThumbnails(args)})},2);return self},_getActive:function(){return this._controls.getActive()},validate:function(data){return true},bind:function(type,fn){type=_patchEvent(type);this.$("container").on(type,this.proxy(fn));return this},unbind:function(type){type=_patchEvent(type);this.$("container").off(type);return this},trigger:function(type){type=typeof type==="object"?$.extend(type,{scope:this}):{type:_patchEvent(type),scope:this};this.$("container").trigger(type);return this},addIdleState:function(elem,styles,from,hide){this._idle.add.apply(this._idle,Utils.array(arguments));return this},removeIdleState:function(elem){this._idle.remove.apply(this._idle,Utils.array(arguments));return this},enterIdleMode:function(){this._idle.hide();return this},exitIdleMode:function(){this._idle.showAll();return this},enterFullscreen:function(callback){this._fullscreen.enter.apply(this,Utils.array(arguments));return this},exitFullscreen:function(callback){this._fullscreen.exit.apply(this,Utils.array(arguments));return this},toggleFullscreen:function(callback){this._fullscreen[this.isFullscreen()?"exit":"enter"].apply(this,Utils.array(arguments));return this},bindTooltip:function(elem,value){this._tooltip.bind.apply(this._tooltip,Utils.array(arguments));return this},defineTooltip:function(elem,value){this._tooltip.define.apply(this._tooltip,Utils.array(arguments));return this},refreshTooltip:function(elem){this._tooltip.show.apply(this._tooltip,Utils.array(arguments));return this},openLightbox:function(){this._lightbox.show.apply(this._lightbox,Utils.array(arguments));return this},closeLightbox:function(){this._lightbox.hide.apply(this._lightbox,Utils.array(arguments));return this},hasVariation:function(variation){return $.inArray(variation,this._options.variation.split(/\s+/))>-1},getActiveImage:function(){var active=this._getActive();return active?active.image:undef},getActiveThumb:function(){return this._thumbnails[this._active].image||undef},getMousePosition:function(e){return{x:e.pageX-this.$("container").offset().left,y:e.pageY-this.$("container").offset().top}},addPan:function(img){if(this._options.imageCrop===false){return}img=$(img||this.getActiveImage());var self=this,x=img.width()/2,y=img.height()/2,destX=parseInt(img.css("left"),10),destY=parseInt(img.css("top"),10),curX=destX||0,curY=destY||0,distX=0,distY=0,active=false,ts=Utils.timestamp(),cache=0,move=0,position=function(dist,cur,pos){if(dist>0){move=M.round(M.max(dist*-1,M.min(0,cur)));if(cache!==move){cache=move;if(IE===8){img.parent()["scroll"+pos](move*-1)}else{var css={};css[pos.toLowerCase()]=move;img.css(css)}}}},calculate=function(e){if(Utils.timestamp()-ts<50){return}active=true;x=self.getMousePosition(e).x;y=self.getMousePosition(e).y},loop=function(e){if(!active){return}distX=img.width()-self._stageWidth;distY=img.height()-self._stageHeight;destX=x/self._stageWidth*distX*-1;destY=y/self._stageHeight*distY*-1;curX+=(destX-curX)/self._options.imagePanSmoothness;curY+=(destY-curY)/self._options.imagePanSmoothness;position(distY,curY,"Top");position(distX,curX,"Left")};if(IE===8){img.parent().scrollTop(curY*-1).scrollLeft(curX*-1);img.css({top:0,left:0})}this.$("stage").off("mousemove",calculate).on("mousemove",calculate);this.addTimer("pan"+self._id,loop,50,true);return this},proxy:function(fn,scope){if(typeof fn!=="function"){return F}scope=scope||this;return function(){return fn.apply(scope,Utils.array(arguments))}},getThemeName:function(){return this.theme.name},removePan:function(){this.$("stage").off("mousemove");this.clearTimer("pan"+this._id);return this},addElement:function(id){var dom=this._dom;$.each(Utils.array(arguments),function(i,blueprint){dom[blueprint]=Utils.create("galleria-"+blueprint)});return this},attachKeyboard:function(map){this._keyboard.attach.apply(this._keyboard,Utils.array(arguments));return this},detachKeyboard:function(){this._keyboard.detach.apply(this._keyboard,Utils.array(arguments));return this},appendChild:function(parentID,childID){this.$(parentID).append(this.get(childID)||childID);
return this},prependChild:function(parentID,childID){this.$(parentID).prepend(this.get(childID)||childID);return this},remove:function(elemID){this.$(Utils.array(arguments).join(",")).remove();return this},append:function(data){var i,j;for(i in data){if(data.hasOwnProperty(i)){if(data[i].constructor===Array){for(j=0;data[i][j];j++){this.appendChild(i,data[i][j])}}else{this.appendChild(i,data[i])}}}return this},_scaleImage:function(image,options){image=image||this._controls.getActive();if(!image){return}var complete,scaleLayer=function(img){$(img.container).children(":first").css({top:M.max(0,Utils.parseValue(img.image.style.top)),left:M.max(0,Utils.parseValue(img.image.style.left)),width:Utils.parseValue(img.image.width),height:Utils.parseValue(img.image.height)})};options=$.extend({width:this._stageWidth,height:this._stageHeight,crop:this._options.imageCrop,max:this._options.maxScaleRatio,min:this._options.minScaleRatio,margin:this._options.imageMargin,position:this._options.imagePosition,iframelimit:this._options.maxVideoSize},options);if(this._options.layerFollow&&this._options.imageCrop!==true){if(typeof options.complete=="function"){complete=options.complete;options.complete=function(){complete.call(image,image);scaleLayer(image)}}else{options.complete=scaleLayer}}else{$(image.container).children(":first").css({top:0,left:0})}image.scale(options);return this},updateCarousel:function(){this._carousel.update();return this},resize:function(measures,complete){if(typeof measures=="function"){complete=measures;measures=undef}measures=$.extend({width:0,height:0},measures);var self=this,$container=this.$("container");$.each(measures,function(m,val){if(!val){$container[m]("auto");measures[m]=self._getWH()[m]}});$.each(measures,function(m,val){$container[m](val)});return this.rescale(complete)},rescale:function(width,height,complete){var self=this;if(typeof width==="function"){complete=width;width=undef}var scale=function(){self._stageWidth=width||self.$("stage").width();self._stageHeight=height||self.$("stage").height();if(self._options.swipe){$.each(self._controls.slides,function(i,img){self._scaleImage(img);$(img.container).css("left",self._stageWidth*i)});self.$("images").css("width",self._stageWidth*self.getDataLength())}else{self._scaleImage()}if(self._options.carousel){self.updateCarousel()}var frame=self._controls.frames[self._controls.active];if(frame){self._controls.frames[self._controls.active].scale({width:self._stageWidth,height:self._stageHeight,iframelimit:self._options.maxVideoSize})}self.trigger(Galleria.RESCALE);if(typeof complete==="function"){complete.call(self)}};scale.call(self);return this},refreshImage:function(){this._scaleImage();if(this._options.imagePan){this.addPan()}return this},_preload:function(){if(this._options.preload){var p,i,n=this.getNext(),ndata;try{for(i=this._options.preload;i>0;i--){p=new Galleria.Picture;ndata=this.getData(n);p.preload(this.isFullscreen()&&ndata.big?ndata.big:ndata.image);n=this.getNext(n)}}catch(e){}}},show:function(index,rewind,_history){var swipe=this._options.swipe;if(!swipe&&(this._queue.length>3||index===false||!this._options.queue&&this._queue.stalled)){return}index=M.max(0,M.min(parseInt(index,10),this.getDataLength()-1));rewind=typeof rewind!=="undefined"?!!rewind:index<this.getIndex();_history=_history||false;if(!_history&&Galleria.History){Galleria.History.set(index.toString());return}if(this.finger&&index!==this._active){this.finger.to=-(index*this.finger.width);this.finger.index=index}this._active=index;if(swipe){var data=this.getData(index),self=this;if(!data){return}var src=this.isFullscreen()&&data.big?data.big:data.image||data.iframe,image=this._controls.slides[index],cached=image.isCached(src),thumb=this._thumbnails[index];var evObj={cached:cached,index:index,rewind:rewind,imageTarget:image.image,thumbTarget:thumb.image,galleriaData:data};this.trigger($.extend(evObj,{type:Galleria.LOADSTART}));self.$("container").removeClass("videoplay");var complete=function(){self._layers[index].innerHTML=self.getData().layer||"";self.trigger($.extend(evObj,{type:Galleria.LOADFINISH}));self._playCheck()};self._preload();window.setTimeout(function(){if(!image.ready||$(image.image).attr("src")!=src){if(data.iframe&&!data.image){image.isIframe=true}image.load(src,function(image){evObj.imageTarget=image.image;self._scaleImage(image,complete).trigger($.extend(evObj,{type:Galleria.IMAGE}));complete()})}else{self.trigger($.extend(evObj,{type:Galleria.IMAGE}));complete()}},100)}else{protoArray.push.call(this._queue,{index:index,rewind:rewind});if(!this._queue.stalled){this._show()}}return this},_show:function(){var self=this,queue=this._queue[0],data=this.getData(queue.index);if(!data){return}var src=this.isFullscreen()&&data.big?data.big:data.image||data.iframe,active=this._controls.getActive(),next=this._controls.getNext(),cached=next.isCached(src),thumb=this._thumbnails[queue.index],mousetrigger=function(){$(next.image).trigger("mouseup")};self.$("container").toggleClass("iframe",!!data.isIframe).removeClass("videoplay");var complete=function(data,next,active,queue,thumb){return function(){var win;_transitions.active=false;Utils.toggleQuality(next.image,self._options.imageQuality);self._layers[self._controls.active].innerHTML="";$(active.container).css({zIndex:0,opacity:0}).show();$(active.container).find("iframe, .galleria-videoicon").remove();$(self._controls.frames[self._controls.active].container).hide();$(next.container).css({zIndex:1,left:0,top:0}).show();self._controls.swap();if(self._options.imagePan){self.addPan(next.image)}if(data.iframe&&data.image||data.link||self._options.lightbox||self._options.clicknext){$(next.image).css({cursor:"pointer"}).on("mouseup",function(e){if(typeof e.which=="number"&&e.which>1){return}if(data.iframe){if(self.isPlaying()){self.pause()}var frame=self._controls.frames[self._controls.active],w=self._stageWidth,h=self._stageHeight;$(frame.container).css({width:w,height:h,opacity:0}).show().animate({opacity:1},200);window.setTimeout(function(){frame.load(data.iframe+(data.video?"&autoplay=1":""),{width:w,height:h},function(frame){self.$("container").addClass("videoplay");frame.scale({width:self._stageWidth,height:self._stageHeight,iframelimit:data.video?self._options.maxVideoSize:undef})})},100);return}if(self._options.clicknext&&!Galleria.TOUCH){if(self._options.pauseOnInteraction){self.pause()}self.next();return}if(data.link){if(self._options.popupLinks){win=window.open(data.link,"_blank")}else{window.location.href=data.link}return}if(self._options.lightbox){self.openLightbox()}})}self._playCheck();self.trigger({type:Galleria.IMAGE,index:queue.index,imageTarget:next.image,thumbTarget:thumb.image,galleriaData:data});protoArray.shift.call(self._queue);self._queue.stalled=false;if(self._queue.length){self._show()}}}(data,next,active,queue,thumb);if(this._options.carousel&&this._options.carouselFollow){this._carousel.follow(queue.index)}self._preload();Utils.show(next.container);next.isIframe=data.iframe&&!data.image;$(self._thumbnails[queue.index].container).addClass("active").siblings(".active").removeClass("active");self.trigger({type:Galleria.LOADSTART,cached:cached,index:queue.index,rewind:queue.rewind,imageTarget:next.image,thumbTarget:thumb.image,galleriaData:data});self._queue.stalled=true;next.load(src,function(next){var layer=$(self._layers[1-self._controls.active]).html(data.layer||"").hide();self._scaleImage(next,{complete:function(next){if("image"in active){Utils.toggleQuality(active.image,false)}Utils.toggleQuality(next.image,false);self.removePan();self.setInfo(queue.index);self.setCounter(queue.index);if(data.layer){layer.show();if(data.iframe&&data.image||data.link||self._options.lightbox||self._options.clicknext){layer.css("cursor","pointer").off("mouseup").mouseup(mousetrigger)}}if(data.video&&data.image){_playIcon(next.container)}var transition=self._options.transition;$.each({initial:active.image===null,touch:Galleria.TOUCH,fullscreen:self.isFullscreen()},function(type,arg){if(arg&&self._options[type+"Transition"]!==undef){transition=self._options[type+"Transition"];return false}});if(transition in _transitions.effects===false){complete()}else{var params={prev:active.container,next:next.container,rewind:queue.rewind,speed:self._options.transitionSpeed||400};_transitions.active=true;_transitions.init.call(self,transition,params,complete)}self.trigger({type:Galleria.LOADFINISH,cached:cached,index:queue.index,rewind:queue.rewind,imageTarget:next.image,thumbTarget:self._thumbnails[queue.index].image,galleriaData:self.getData(queue.index)})}})})},getNext:function(base){base=typeof base==="number"?base:this.getIndex();return base===this.getDataLength()-1?0:base+1},getPrev:function(base){base=typeof base==="number"?base:this.getIndex();return base===0?this.getDataLength()-1:base-1},next:function(){if(this.getDataLength()>1){this.show(this.getNext(),false)}return this},prev:function(){if(this.getDataLength()>1){this.show(this.getPrev(),true)}return this},get:function(elemId){return elemId in this._dom?this._dom[elemId]:null},getData:function(index){return index in this._data?this._data[index]:this._data[this._active]},getDataLength:function(){return this._data.length},getIndex:function(){return typeof this._active==="number"?this._active:false},getStageHeight:function(){return this._stageHeight},getStageWidth:function(){return this._stageWidth},getOptions:function(key){return typeof key==="undefined"?this._options:this._options[key]},setOptions:function(key,value){if(typeof key==="object"){$.extend(this._options,key)}else{this._options[key]=value}return this},play:function(delay){this._playing=true;this._playtime=delay||this._playtime;this._playCheck();this.trigger(Galleria.PLAY);return this},pause:function(){this._playing=false;this.trigger(Galleria.PAUSE);return this},playToggle:function(delay){return this._playing?this.pause():this.play(delay)},isPlaying:function(){return this._playing},isFullscreen:function(){return this._fullscreen.active},_playCheck:function(){var self=this,played=0,interval=20,now=Utils.timestamp(),timer_id="play"+this._id;if(this._playing){this.clearTimer(timer_id);var fn=function(){played=Utils.timestamp()-now;if(played>=self._playtime&&self._playing){self.clearTimer(timer_id);self.next();return}if(self._playing){self.trigger({type:Galleria.PROGRESS,percent:M.ceil(played/self._playtime*100),seconds:M.floor(played/1e3),milliseconds:played});self.addTimer(timer_id,fn,interval)}};self.addTimer(timer_id,fn,interval)}},setPlaytime:function(delay){this._playtime=delay;return this},setIndex:function(val){this._active=val;return this},setCounter:function(index){if(typeof index==="number"){index++}else if(typeof index==="undefined"){index=this.getIndex()+1}this.get("current").innerHTML=index;if(IE){var count=this.$("counter"),opacity=count.css("opacity");if(parseInt(opacity,10)===1){Utils.removeAlpha(count[0])}else{this.$("counter").css("opacity",opacity)}}return this},setInfo:function(index){var self=this,data=this.getData(index);$.each(["title","description"],function(i,type){var elem=self.$("info-"+type);if(!!data[type]){elem[data[type].length?"show":"hide"]().html(data[type])}else{elem.empty().hide()}});return this},hasInfo:function(index){var check="title description".split(" "),i;for(i=0;check[i];i++){if(!!this.getData(index)[check[i]]){return true}}return false},jQuery:function(str){var self=this,ret=[];$.each(str.split(","),function(i,elemId){elemId=$.trim(elemId);if(self.get(elemId)){ret.push(elemId)}});var jQ=$(self.get(ret.shift()));$.each(ret,function(i,elemId){jQ=jQ.add(self.get(elemId))});return jQ},$:function(str){return this.jQuery.apply(this,Utils.array(arguments))}};$.each(_events,function(i,ev){var type=/_/.test(ev)?ev.replace(/_/g,""):ev;Galleria[ev.toUpperCase()]="galleria."+type});$.extend(Galleria,{IE9:IE===9,IE8:IE===8,IE7:IE===7,IE6:IE===6,IE:IE,WEBKIT:/webkit/.test(NAV),CHROME:/chrome/.test(NAV),SAFARI:/safari/.test(NAV)&&!/chrome/.test(NAV),QUIRK:IE&&doc.compatMode&&doc.compatMode==="BackCompat",MAC:/mac/.test(navigator.platform.toLowerCase()),OPERA:!!window.opera,IPHONE:/iphone/.test(NAV),IPAD:/ipad/.test(NAV),ANDROID:/android/.test(NAV),TOUCH:"ontouchstart"in doc});Galleria.addTheme=function(theme){if(!theme.name){Galleria.raise("No theme name specified")}if(typeof theme.defaults!=="object"){theme.defaults={}}else{theme.defaults=_legacyOptions(theme.defaults)}var css=false,reg,reg2;if(typeof theme.css==="string"){$("link").each(function(i,link){reg=new RegExp(theme.css);if(reg.test(link.href)){css=true;_themeLoad(theme);return false}});if(!css){$(function(){var retryCount=0;var tryLoadCss=function(){$("script").each(function(i,script){reg=new RegExp("galleria\\."+theme.name.toLowerCase()+"\\.");reg2=new RegExp("galleria\\.io\\/theme\\/"+theme.name.toLowerCase()+"\\/(\\d*\\.*)?(\\d*\\.*)?(\\d*\\/)?js");if(reg.test(script.src)||reg2.test(script.src)){css=script.src.replace(/[^\/]*$/,"")+theme.css;window.setTimeout(function(){Utils.loadCSS(css,"galleria-theme-"+theme.name,function(){_themeLoad(theme)})},1)}});if(!css){if(retryCount++>5){Galleria.raise("No theme CSS loaded")}else{window.setTimeout(tryLoadCss,500)}}};tryLoadCss()})}}else{_themeLoad(theme)}return theme};Galleria.loadTheme=function(src,options){if($("script").filter(function(){return $(this).attr("src")==src}).length){return}var loaded=false,err;$(window).load(function(){if(!loaded){err=window.setTimeout(function(){if(!loaded){Galleria.raise("Galleria had problems loading theme at "+src+". Please check theme path or load manually.",true)}},2e4)}});Utils.loadScript(src,function(){loaded=true;window.clearTimeout(err)});return Galleria};Galleria.get=function(index){if(!!_instances[index]){return _instances[index]}else if(typeof index!=="number"){return _instances}else{Galleria.raise("Gallery index "+index+" not found")}};Galleria.configure=function(key,value){var opts={};if(typeof key=="string"&&value){opts[key]=value;key=opts}else{$.extend(opts,key)}Galleria.configure.options=opts;$.each(Galleria.get(),function(i,instance){instance.setOptions(opts)});return Galleria};Galleria.configure.options={};Galleria.on=function(type,callback){if(!type){return}callback=callback||F;var hash=type+callback.toString().replace(/\s/g,"")+Utils.timestamp();$.each(Galleria.get(),function(i,instance){instance._binds.push(hash);instance.bind(type,callback)});Galleria.on.binds.push({type:type,callback:callback,hash:hash});return Galleria};Galleria.on.binds=[];Galleria.run=function(selector,options){if($.isFunction(options)){options={extend:options}}$(selector||"#galleria").galleria(options);return Galleria};Galleria.addTransition=function(name,fn){_transitions.effects[name]=fn;return Galleria};Galleria.utils=Utils;Galleria.log=function(){var args=Utils.array(arguments);if("console"in window&&"log"in window.console){try{return window.console.log.apply(window.console,args)}catch(e){$.each(args,function(){window.console.log(this)})}}else{return window.alert(args.join("<br>"))}};Galleria.ready=function(fn){if(typeof fn!="function"){return Galleria}$.each(_galleries,function(i,gallery){fn.call(gallery,gallery._options)});Galleria.ready.callbacks.push(fn);return Galleria};Galleria.ready.callbacks=[];Galleria.raise=function(msg,fatal){var type=fatal?"Fatal error":"Error",css={color:"#fff",position:"absolute",top:0,left:0,zIndex:1e5},echo=function(msg){var html='<div style="padding:4px;margin:0 0 2px;background:#'+(fatal?"811":"222")+';">'+(fatal?"<strong>"+type+": </strong>":"")+msg+"</div>";$.each(_instances,function(){var cont=this.$("errors"),target=this.$("target");if(!cont.length){target.css("position","relative");cont=this.addElement("errors").appendChild("target","errors").$("errors").css(css)}cont.append(html)});if(!_instances.length){$("<div>").css($.extend(css,{position:"fixed"})).append(html).appendTo(DOM().body)}};if(DEBUG){echo(msg);if(fatal){throw new Error(type+": "+msg)}}else if(fatal){if(_hasError){return}_hasError=true;fatal=false;echo("Gallery could not load.")}};Galleria.version=VERSION;Galleria.getLoadedThemes=function(){return $.map(_loadedThemes,function(theme){return theme.name})};Galleria.requires=function(version,msg){msg=msg||"You need to upgrade Galleria to version "+version+" to use one or more components.";if(Galleria.version<version){Galleria.raise(msg,true)}return Galleria};Galleria.Picture=function(id){this.id=id||null;this.image=null;this.container=Utils.create("galleria-image");$(this.container).css({overflow:"hidden",position:"relative"});this.original={width:0,height:0};this.ready=false;this.isIframe=false};Galleria.Picture.prototype={cache:{},show:function(){Utils.show(this.image)},hide:function(){Utils.moveOut(this.image)},clear:function(){this.image=null},isCached:function(src){return!!this.cache[src]},preload:function(src){$(new Image).load(function(src,cache){return function(){cache[src]=src}}(src,this.cache)).attr("src",src)},load:function(src,size,callback){if(typeof size=="function"){callback=size;size=null}if(this.isIframe){var id="if"+(new Date).getTime();var iframe=this.image=$("<iframe>",{src:src,frameborder:0,id:id,allowfullscreen:true,css:{visibility:"hidden"}})[0];if(size){$(iframe).css(size)}$(this.container).find("iframe,img").remove();this.container.appendChild(this.image);$("#"+id).load(function(self,callback){return function(){window.setTimeout(function(){$(self.image).css("visibility","visible");if(typeof callback=="function"){callback.call(self,self)}},10)}}(this,callback));return this.container}this.image=new Image;if(Galleria.IE8){$(this.image).css("filter","inherit")}if(!Galleria.IE&&!Galleria.CHROME&&!Galleria.SAFARI){$(this.image).css("image-rendering","optimizequality")}var reload=false,resort=false,$container=$(this.container),$image=$(this.image),onerror=function(){if(!reload){reload=true;window.setTimeout(function(image,src){return function(){image.attr("src",src+(src.indexOf("?")>-1?"&":"?")+Utils.timestamp())}}($(this),src),50)}else{if(DUMMY){$(this).attr("src",DUMMY)}else{Galleria.raise("Image not found: "+src)}}},onload=function(self,callback,src){return function(){var complete=function(){$(this).off("load");self.original=size||{height:this.height,width:this.width};if(Galleria.HAS3D){this.style.MozTransform=this.style.webkitTransform="translate3d(0,0,0)"}$container.append(this);self.cache[src]=src;if(typeof callback=="function"){window.setTimeout(function(){callback.call(self,self)},1)}};if(!this.width||!this.height){(function(img){Utils.wait({until:function(){return img.width&&img.height},success:function(){complete.call(img)},error:function(){if(!resort){$(new Image).load(onload).attr("src",img.src);resort=true}else{Galleria.raise("Could not extract width/height from image: "+img.src+". Traced measures: width:"+img.width+"px, height: "+img.height+"px.")}},timeout:100})})(this)}else{complete.call(this)}}}(this,callback,src);$container.find("iframe,img").remove();$image.css("display","block");Utils.hide(this.image);$.each("minWidth minHeight maxWidth maxHeight".split(" "),function(i,prop){$image.css(prop,/min/.test(prop)?"0":"none")});$image.load(onload).on("error",onerror).attr("src",src);return this.container},scale:function(options){var self=this;options=$.extend({width:0,height:0,min:undef,max:undef,margin:0,complete:F,position:"center",crop:false,canvas:false,iframelimit:undef},options);if(this.isIframe){var cw=options.width,ch=options.height,nw,nh;if(options.iframelimit){var r=M.min(options.iframelimit/cw,options.iframelimit/ch);if(r<1){nw=cw*r;nh=ch*r;$(this.image).css({top:ch/2-nh/2,left:cw/2-nw/2,position:"absolute"})}else{$(this.image).css({top:0,left:0})}}$(this.image).width(nw||cw).height(nh||ch).removeAttr("width").removeAttr("height");$(this.container).width(cw).height(ch);options.complete.call(self,self);try{if(this.image.contentWindow){$(this.image.contentWindow).trigger("resize")}}catch(e){}return this.container}if(!this.image){return this.container}var width,height,$container=$(self.container),data;Utils.wait({until:function(){width=options.width||$container.width()||Utils.parseValue($container.css("width"));height=options.height||$container.height()||Utils.parseValue($container.css("height"));return width&&height},success:function(){var newWidth=(width-options.margin*2)/self.original.width,newHeight=(height-options.margin*2)/self.original.height,min=M.min(newWidth,newHeight),max=M.max(newWidth,newHeight),cropMap={true:max,width:newWidth,height:newHeight,false:min,landscape:self.original.width>self.original.height?max:min,portrait:self.original.width<self.original.height?max:min},ratio=cropMap[options.crop.toString()],canvasKey="";if(options.max){ratio=M.min(options.max,ratio)}if(options.min){ratio=M.max(options.min,ratio)}$.each(["width","height"],function(i,m){$(self.image)[m](self[m]=self.image[m]=M.round(self.original[m]*ratio))});$(self.container).width(width).height(height);if(options.canvas&&_canvas){_canvas.elem.width=self.width;_canvas.elem.height=self.height;canvasKey=self.image.src+":"+self.width+"x"+self.height;self.image.src=_canvas.cache[canvasKey]||function(key){_canvas.context.drawImage(self.image,0,0,self.original.width*ratio,self.original.height*ratio);try{data=_canvas.elem.toDataURL();_canvas.length+=data.length;_canvas.cache[key]=data;return data}catch(e){return self.image.src}}(canvasKey)}var pos={},mix={},getPosition=function(value,measure,margin){var result=0;if(/\%/.test(value)){var flt=parseInt(value,10)/100,m=self.image[measure]||$(self.image)[measure]();result=M.ceil(m*-1*flt+margin*flt)}else{result=Utils.parseValue(value)}return result},positionMap={top:{top:0},left:{left:0},right:{left:"100%"},bottom:{top:"100%"}};$.each(options.position.toLowerCase().split(" "),function(i,value){if(value==="center"){value="50%"}pos[i?"top":"left"]=value});$.each(pos,function(i,value){if(positionMap.hasOwnProperty(value)){$.extend(mix,positionMap[value])}});pos=pos.top?$.extend(pos,mix):mix;pos=$.extend({top:"50%",left:"50%"},pos);$(self.image).css({position:"absolute",top:getPosition(pos.top,"height",height),left:getPosition(pos.left,"width",width)});self.show();self.ready=true;options.complete.call(self,self)},error:function(){Galleria.raise("Could not scale image: "+self.image.src)},timeout:1e3});return this}};$.extend($.easing,{galleria:function(_,t,b,c,d){if((t/=d/2)<1){return c/2*t*t*t+b}return c/2*((t-=2)*t*t+2)+b},galleriaIn:function(_,t,b,c,d){return c*(t/=d)*t+b},galleriaOut:function(_,t,b,c,d){return-c*(t/=d)*(t-2)+b}});Galleria.Finger=function(){var abs=M.abs;var has3d=Galleria.HAS3D=function(){var el=doc.createElement("p"),has3d,t=["webkit","O","ms","Moz",""],s,i=0,a="transform";DOM().html.insertBefore(el,null);for(;t[i];i++){s=t[i]?t[i]+"Transform":a;if(el.style[s]!==undefined){el.style[s]="translate3d(1px,1px,1px)";has3d=$(el).css(t[i]?"-"+t[i].toLowerCase()+"-"+a:a)}}DOM().html.removeChild(el);return has3d!==undefined&&has3d.length>0&&has3d!=="none"}();var requestFrame=function(){var r="RequestAnimationFrame";return window.requestAnimationFrame||window["webkit"+r]||window["moz"+r]||window["o"+r]||window["ms"+r]||function(callback){window.setTimeout(callback,1e3/60)}}();var Finger=function(elem,options){this.config={start:0,duration:500,onchange:function(){},oncomplete:function(){},easing:function(x,t,b,c,d){return-c*((t=t/d-1)*t*t*t-1)+b}};this.easeout=function(x,t,b,c,d){return c*((t=t/d-1)*t*t*t*t+1)+b};if(!elem.children.length){return}var self=this;$.extend(this.config,options);this.elem=elem;this.child=elem.children[0];this.to=this.pos=0;this.touching=false;this.start={};this.index=this.config.start;this.anim=0;this.easing=this.config.easing;if(!has3d){this.child.style.position="absolute";this.elem.style.position="relative"}$.each(["ontouchstart","ontouchmove","ontouchend","setup"],function(i,fn){self[fn]=function(caller){return function(){caller.apply(self,arguments)}}(self[fn])});this.setX=function(){var style=self.child.style;if(!has3d){style.left=self.pos+"px";return}style.MozTransform=style.webkitTransform=style.transform="translate3d("+self.pos+"px,0,0)";return};$(elem).on("touchstart",this.ontouchstart);$(window).on("resize",this.setup);$(window).on("orientationchange",this.setup);this.setup();(function animloop(){requestFrame(animloop);self.loop.call(self)})()};Finger.prototype={constructor:Finger,setup:function(){this.width=$(this.elem).width();this.length=M.ceil($(this.child).width()/this.width);if(this.index!==0){this.index=M.max(0,M.min(this.index,this.length-1));this.pos=this.to=-this.width*this.index}},setPosition:function(pos){this.pos=pos;this.to=pos},ontouchstart:function(e){var touch=e.originalEvent.touches;this.start={pageX:touch[0].pageX,pageY:touch[0].pageY,time:+new Date};this.isScrolling=null;this.touching=true;this.deltaX=0;$doc.on("touchmove",this.ontouchmove);$doc.on("touchend",this.ontouchend)},ontouchmove:function(e){var touch=e.originalEvent.touches;if(touch&&touch.length>1||e.scale&&e.scale!==1){return}this.deltaX=touch[0].pageX-this.start.pageX;if(this.isScrolling===null){this.isScrolling=!!(this.isScrolling||M.abs(this.deltaX)<M.abs(touch[0].pageY-this.start.pageY))}if(!this.isScrolling){e.preventDefault();this.deltaX/=!this.index&&this.deltaX>0||this.index==this.length-1&&this.deltaX<0?M.abs(this.deltaX)/this.width+1.8:1;this.to=this.deltaX-this.index*this.width}e.stopPropagation()},ontouchend:function(e){this.touching=false;var isValidSlide=+new Date-this.start.time<250&&M.abs(this.deltaX)>40||M.abs(this.deltaX)>this.width/2,isPastBounds=!this.index&&this.deltaX>0||this.index==this.length-1&&this.deltaX<0;if(!this.isScrolling){this.show(this.index+(isValidSlide&&!isPastBounds?this.deltaX<0?1:-1:0))}$doc.off("touchmove",this.ontouchmove);$doc.off("touchend",this.ontouchend)},show:function(index){if(index!=this.index){this.config.onchange.call(this,index)}else{this.to=-(index*this.width)}},moveTo:function(index){if(index!=this.index){this.pos=this.to=-(index*this.width);this.index=index}},loop:function(){var distance=this.to-this.pos,factor=1;if(this.width&&distance){factor=M.max(.5,M.min(1.5,M.abs(distance/this.width)))}if(this.touching||M.abs(distance)<=1){this.pos=this.to;distance=0;if(this.anim&&!this.touching){this.config.oncomplete(this.index)}this.anim=0;this.easing=this.config.easing}else{if(!this.anim){this.anim={start:this.pos,time:+new Date,distance:distance,factor:factor,destination:this.to}}var elapsed=+new Date-this.anim.time;var duration=this.config.duration*this.anim.factor;if(elapsed>duration||this.anim.destination!=this.to){this.anim=0;this.easing=this.easeout;return}this.pos=this.easing(null,elapsed,this.anim.start,this.anim.distance,duration)}this.setX()}};return Finger}();$.fn.galleria=function(options){var selector=this.selector;if(!$(this).length){$(function(){if($(selector).length){$(selector).galleria(options)}else{Galleria.utils.wait({until:function(){return $(selector).length},success:function(){$(selector).galleria(options)},error:function(){Galleria.raise('Init failed: Galleria could not find the element "'+selector+'".')},timeout:5e3})}});return this}return this.each(function(){if($.data(this,"galleria")){$.data(this,"galleria").destroy();$(this).find("*").hide()}$.data(this,"galleria",(new Galleria).init(this,options))})};if(typeof module==="object"&&module&&typeof module.exports==="object"){module.exports=Galleria}else{window.Galleria=Galleria;if(typeof define==="function"&&define.amd){define("galleria",["jquery"],function(){return Galleria})}}})(jQuery,this);
(function ($) {
    /*
    //onDOMReady functions
    */
    
    $(document).ready(function () {
            (function() { 
                if($('.galleria').length){
                Galleria.loadTheme(window.location.protocol + "//" + window.location.host +'/assets/intel/js/galleria.classic.min.js');
                Galleria.run('.galleria');
                }
        
            }());

        $(function stay() {
            $('body').on('click', '.flyout-mobile .heading a', function () {
                $('.flyout-mobile .heading a').removeClass('active');
                $('.flyout-mobile .heading a').parent('h3').removeClass('ui-state-active');
                $(this).addClass('active');
                return true;

            });
        });

        //mtUtilities.isMobile = (Modernizr.touch && Modernizr.mq('only all and (max-width: 44.063em)')) ? true : false;

        /*Carousel Change if in Page Editor mode======================================================================*/
        if (mtUtilities.isPageEditor() == false) {
            $('.crsl-items').carousel({ overflow: true, visible: 4, itemMinWidth: 200, itemMargin: 20 });
        }

        /*Add Classes for CSS mgmt===================================================================================*/
        $(".row:nth-child(odd)").addClass("odd");
        $(".scfSectionContent").find("div:not('.out')").addClass("columns twelve");
        $(".scfSubmitButtonBorder").addClass("columns three");


        /*Mobile Nav*/
        if (mtUtilities.isMobile) {
            $("nav.main-nav").mtMobileNav({
                attachment: "before",
                action: "push",
                container: "header section.mobile-menu",
                prependSearch: "div.search-form",
                toggleBtn: "section.mobile-menu .toggle2",
                wrapperAttr: { cssClass: "mobile-nav" }
            });
        }

        /*Sliders*/


        $('.mtslide').mtslider({
            animation: "slide",
            directionNav: false,
            controlNav: false,
            slideshow: true,
            keyboard: true,
            multipleKeyboard: true,
            pauseOnAction: true,
            pauseOnHover: true,
            slideshowSpeed: 7000,
            start: function (mtslider) {
                mtslider.slides.eq(mtslider.currentSlide).find('slides li').removeAttr('tabindex');
            }
        });

        $(".slides li").keydown(function (e) {
            if (e.which == 9)
                $slideshow.mtslider('pause');
        });



        /* PROVINT-60: Comment this JS function */
        ///*Temporary hack to get styling on the left nav correct*/
        //jQuery('.nav-item.active').each(function (i, e) {
        //    var x = jQuery(this).text();
        //    jQuery(this).empty();
        //    jQuery(this).append('<span>' + x + '</span>');
        //})

        $("footer .accordion").accordion({ header: "h3.enabled", active: false, collapsible: true });
        $('.mt-next').click(function () { $('.mtslide').mtslider("next"); });
        $('.mt-prev').click(function () { $('.mtslide').mtslider("prev"); });

        $('.hero-slide').carousel();
        $('.callout-phone a').before("<span>Phone </span>");
        $('.callout-fax a').before("<span>Fax </span>");
        //$('.crsl-items').carousel({ overflow: true, visible: 3, itemMinWidth: 180, itemMargin: 10 });
        //$('.crsl-items').carousel({ visible: 3, itemMinWidth: 140, itemMargin: 15 });
        $('.crsl-items2').carousel({ visible: 2, itemMinWidth: 220, itemMargin: 15 });
        $('.crsl-items3').carousel({ visible: 3, itemMinWidth: 180, itemMargin: 15 });
        $('.crsl-items3-a').carousel({ visible: 3, itemMinWidth: 180, itemMargin: 15 });
        $('.crsl-items4').carousel({ visible: 4, itemMinWidth: 140, itemMargin: 20 });
        $('.crsl-items4-a').carousel({ visible: 4, itemMinWidth: 200, itemMargin: 10 });
        $('.base-container .grid-1-quarter:visible').each(function (i) {
            if (i % 4 == 0) $(this).addClass('first');
        });

        $('.plus').append('<span>&#43;</span>');

        /*Accordions */
        $(".accordion > div").each(function () {
            var prev = $(this).prev();
            if (prev.is('h3')) {
                prev.addClass('enabled');
            }
        });
        $(".accordion").accordion({
            header: "h3.enabled",
            collapsible: true,
            autoHeight: false,
            heightStyle: "content",
            clearStyle: true
        });

        /*Placeholder Polyfill*/
        $("input, textarea").placehold();

        /*Mobile Callouts*/
        $(".collapse-for-mobile").mtMobileCallouts();

        /*Services Tabs*/
        if ($('.tabs.services-custom').length > 0) {
            mtUtilities.Services.tabInit();
        }


        /*INIT UTILITIES========================================================================================
        This Section is for calling Utilities that help with page building & administration
    
        */


        mtUtilities.responsiveTabs();


        /*EVENT LISTENERS =====================================================================================================
        This section holds all of the Event listeners for a page  
    
        */

        //Tree expand/collapse listener===============================================================================
        $('.expand_button').on('click', function () {
            $('ul.tree.first').expand();
            return false;
        });
        $('.collapse_button').on('click', function () {
            $('ul.tree.first').collapse();
            return false;
        });


        /*Global reset button Listener====================================================================================*/
        var $resetBtn = $(".button.reset-button, .button.reset, .lt-ie10 .reset");
        $resetBtn.on("click", function (e) {
            e.preventDefault();
            var $this = $(this);
            $this.parents(".core-search,.core-search-again").find(":input").not(":button, :submit, :reset, :hidden").val("").removeAttr("checked").removeAttr("selected").trigger("change").trigger("blur");
        });



        /*Footer Click Event Listener===============================================================================*/
        $("footer h3 > a").on("click", function (e) {
            var ul = $(this).parent().next("ul");

            e.preventDefault();
            if (ul.hasClass("open")) { ul.toggleClass("open"); }
            else {
                $("footer ul").removeClass("open");
                ul.toggleClass("open");
            }
        });

        /*Advanced Search Toggle=====================================================================================*/
        $(".toggle-hide-show").click(function () {
            $(".form-toggle").slideToggle(function () {
                // Animation complete.
                $('.srch-txt-toggle').toggle(); // Patrick Add
            });
        });


        $(".flyout-mobile").appendTo(".flyout-mobile-move");
        //$(".location-contact-us").appendTo(".location-contact-us-move");

        //setTimeout(function () {
        //    $('.location-contact-us-move .header-mobile a.status').trigger('click');
        //}, 5);

        //$(".header-mobile").click(function(){
        //    return $(this).toggleClass("active"),
        //        $(this).parent().children(".location-contact-us-move .inner").slideToggle(), !1
        //});




        /*Left Nav Toggle===========================================================================================*/
        $('.prox').click(function () {
            $(this).toggleClass('active');
            $('.left-nav').toggle(200);
            return false;
        });

        $(window).on("resize", function () {
            mtUtilities.colorSwitcherPosition();
            mtUtilities.resizeBanner();
        });

    });

    /*Function called on panel ajax, refreshes Select to our custom select*/
    function pageLoad(sender, args) {
        mtUtilities.customSelect();
    }
})(jQuery);

function decorateAnalyticsCrossDomainParameters(destinationUrl) {
    var globalTrackingId = 'UA-51066651-1';
    var trackers, linker;
    //decorate the destinationUrl
    //universal analytics only
    if (ga !== undefined && typeof ga.getAll === 'function') {
        trackers = ga.getAll();
        for (i = 0; i < trackers.length; i++) {
            if (trackers[i].b.data.get('trackingId') ===
            globalTrackingId)
            { linker = new window.gaplugins.Linker(trackers[i]); destinationUrl = linker.decorate(destinationUrl); }
        }
    }
    // return decorated Url
    return destinationUrl;
}

(function ($) {
    /* PROVINT-79 FLYOUT SCRIPT */
    $(document).ready(function () {
        $('.hero .flyout .heading a').on('click', function () {
            var target = $(this).attr('rel');

			$('.hero .flyout .heading a').removeClass('active');
			if($('#' + target).is(':visible')) $(this).removeClass('active'); 
			else $(this).addClass('active'); 
			$('#' + target).fadeToggle(800);
            $('#' + target).show().siblings("div").hide();
			
            // Added to redirect when link has href and remove hash from URL
            if (target != undefined) { return false; }
            else { return true; }
        });

       
        /*$('.flyout-mobile .accordion > h3').each(function(){
        if($(this).next().prop('tagName') != 'DIV'){
        $(this).addClass('link-only');
        }
        
        $("#accordion").accordion({ disabled: true });
        $(".trigger").click(function() {
        $("#accordion").accordion("enable").accordion("activate", parseInt($(this).data("index"), 10)).accordion("disable");
        });
        
        });
        */


        $('body').on('click', '.flyout-mobile .heading a', function () {
            var target = $(this).attr('rel');

            $(this).parents('h3').next('.flyout-content').slideToggle().siblings("div").slideUp();
            // Added to redirect when link has href and remove hash from URL
            if (target != undefined) { return false; }
            else { return true; }
        });

        $(function stay() {
            $('body').on('click', '.flyout-mobile .heading a', function () {
                $('.flyout-mobile .heading a').removeClass('active');
                $('.flyout-mobile .heading a').parent('h3').removeClass('ui-state-active');
                $(this).addClass('active');
                return true;

            });
        });

        $(".close").click(function (e) {
            e.preventDefault();
            $(this).parent().fadeOut();
            $('.flyout .heading a, .flyout-mobile .heading a').removeClass('active');
            //$('iframe').attr('src', $('iframe').attr('src'));
            return false;

        });
        var locContactUs = $('.location-contact-us').html();
        $('.location-contact-us-move').html(locContactUs);

        setTimeout(function () {
            $('.location-contact-us-move .header-mobile a.status').trigger('click');
        }, 5);
        $(".header-mobile").click(function () {
            $(this).toggleClass('active');
            $(this).parent().children(".location-contact-us-move .inner").slideToggle();
            return false;
        });

    });
})(jQuery);
/* END PROVINT-79 FLYOUT SCRIPT */;


mapHover = function (stateImageId, hoverActionImage) {
   test = document.getElementById(stateImageId);
   test.src = hoverActionImage;
};


jQuery(document).ready(function () {


    jQuery('#wa-facts').popup(
    {
        type: 'tooltip',
        tooltipanchor: '#or-img',
        autozindex: 'true',
        horizontal: 'leftedge',
       vertical: 'topedge',
        transition: 'all 0.5s'

    });
   
 jQuery('#or-facts').popup(
    {
        type: 'tooltip',
        tooltipanchor: '#or-img',

        horizontal: 'leftedge',
        vertical: 'topedge',
        transition: 'all 0.5s'

    });

    jQuery('#ca-facts').popup(
    {
        type: 'tooltip',
        tooltipanchor: '#or-img',

        horizontal: 'leftedge',
        vertical: 'topedge',
        transition: 'all 0.5s'

    });

    jQuery('#mt-facts').popup(
    {
        type: 'tooltip',
        tooltipanchor: '#or-img',

        horizontal: 'leftedge',
        vertical: 'topedge',
        transition: 'all 0.5s'

    });

    jQuery('#ak-facts').popup(
    {
        type: 'tooltip',
        tooltipanchor: '#map-background',
        horizontal: 'center',
        vertical: 'center',
        transition: 'all 0.5s'

    });


}); ;
/*!
 * jQuery Popup Overlay
 *
 * @version 1.7.6
 * @requires jQuery v1.7.1+
 * @link http://vast-engineering.github.com/jquery-popup-overlay/
 */
;(function ($) {

    var $window = $(window);
    var options = {};
    var zindexvalues = [];
    var lastclicked = [];
    var scrollbarwidth;
    var bodymarginright = null;
    var opensuffix = '_open';
    var closesuffix = '_close';
    var stack = [];
    var transitionsupport = null;
    var opentimer;
    var iOS = /(iPad|iPhone|iPod)/g.test(navigator.userAgent);

    var methods = {

        _init: function (el) {
            var $el = $(el);
            var options = $el.data('popupoptions');
            lastclicked[el.id] = false;
            zindexvalues[el.id] = 0;

            if (!$el.data('popup-initialized')) {
                $el.attr('data-popup-initialized', 'true');
                methods._initonce(el);
            }

            if (options.autoopen) {
                setTimeout(function() {
                    methods.show(el, 0);
                }, 0);
            }
        },

        _initonce: function (el) {
            var $el = $(el);
            var $body = $('body');
            var $wrapper;
            var options = $el.data('popupoptions');
            var css;

            bodymarginright = parseInt($body.css('margin-right'), 10);
            transitionsupport = document.body.style.webkitTransition !== undefined ||
                                document.body.style.MozTransition !== undefined ||
                                document.body.style.msTransition !== undefined ||
                                document.body.style.OTransition !== undefined ||
                                document.body.style.transition !== undefined;

            if (options.type == 'tooltip') {
                options.background = false;
                options.scrolllock = false;
            }

            if (options.backgroundactive) {
                options.background = false;
                options.blur = false;
                options.scrolllock = false;
            }

            if (options.scrolllock) {
                // Calculate the browser's scrollbar width dynamically
                var parent;
                var child;
                if (typeof scrollbarwidth === 'undefined') {
                    parent = $('<div style="width:50px;height:50px;overflow:auto"><div/></div>').appendTo('body');
                    child = parent.children();
                    scrollbarwidth = child.innerWidth() - child.height(99).innerWidth();
                    parent.remove();
                }
            }

            if (!$el.attr('id')) {
                $el.attr('id', 'j-popup-' + parseInt((Math.random() * 100000000), 10));
            }

            $el.addClass('popup_content');

            $body.prepend(el);

            $el.wrap('<div id="' + el.id + '_wrapper" class="popup_wrapper" />');

            $wrapper = $('#' + el.id + '_wrapper');

            $wrapper.css({
                opacity: 0,
                visibility: 'hidden',
                position: 'absolute'
            });

            // Make div clickable in iOS
            if (iOS) {
                $wrapper.css('cursor', 'pointer');
            }

            if (options.type == 'overlay') {
                $wrapper.css('overflow','auto');
            }

            $el.css({
                opacity: 0,
                visibility: 'hidden',
                display: 'inline-block'
            });

            if (options.setzindex && !options.autozindex) {
                $wrapper.css('z-index', '100001');
            }

            if (!options.outline) {
                $el.css('outline', 'none');
            }

            if (options.transition) {
                $el.css('transition', options.transition);
                $wrapper.css('transition', options.transition);
            }

            // Hide popup content from screen readers initially
            $el.attr('aria-hidden', true);

            if ((options.background) && (!$('#' + el.id + '_background').length)) {

                $body.prepend('<div id="' + el.id + '_background" class="popup_background"></div>');

                var $background = $('#' + el.id + '_background');

                $background.css({
                    opacity: 0,
                    visibility: 'hidden',
                    backgroundColor: options.color,
                    position: 'fixed',
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                });

                if (options.setzindex && !options.autozindex) {
                    $background.css('z-index', '100000');
                }

                if (options.transition) {
                    $background.css('transition', options.transition);
                }
            }

            if (options.type == 'overlay') {
                $el.css({
                    textAlign: 'left',
                    position: 'relative',
                    verticalAlign: 'middle'
                });

                css = {
                    position: 'fixed',
                    width: '100%',
                    height: '100%',
                    top: 0,
                    left: 0,
                    textAlign: 'center'
                };

                if(options.backgroundactive){
                    css.position = 'relative';
                    css.height = '0';
                    css.overflow = 'visible';
                }

                $wrapper.css(css);

                // CSS vertical align helper
                $wrapper.append('<div class="popup_align" />');

                $('.popup_align').css({
                    display: 'inline-block',
                    verticalAlign: 'middle',
                    height: '100%'
                });
            }

            // Add WAI ARIA role to announce dialog to screen readers
            $el.attr('role', 'dialog');

            var openelement =  (options.openelement) ? options.openelement : ('.' + el.id + opensuffix);

            $(openelement).each(function (i, item) {
                $(item).attr('data-popup-ordinal', i);

                if (!item.id) {
                    $(item).attr('id', 'open_' + parseInt((Math.random() * 100000000), 10));
                }
            });

            // Set aria-labelledby (if aria-label or aria-labelledby is not set in html)
            if (!($el.attr('aria-labelledby') || $el.attr('aria-label'))) {
                $el.attr('aria-labelledby', $(openelement).attr('id'));
            }

            // Show and hide tooltips on hover
            if(options.action == 'hover'){
                options.keepfocus = false;

                // Handler: mouseenter, focusin
                $(openelement).on('mouseenter', function (event) {
                    methods.show(el, $(this).data('popup-ordinal'));
                });

                // Handler: mouseleave, focusout
                $(openelement).on('mouseleave', function (event) {
                    methods.hide(el);
                });

            } else {

                // Handler: Show popup when clicked on `open` element
                $(document).on('click', openelement, function (event) {
                    event.preventDefault();

                    var ord = $(this).data('popup-ordinal');
                    setTimeout(function() { // setTimeout is to allow `close` method to finish (for issues with multiple tooltips)
                        methods.show(el, ord);
                    }, 0);
                });
            }

            if (options.closebutton) {
                methods.addclosebutton(el);
            }

            if (options.detach) {
                $el.hide().detach();
            } else {
                $wrapper.hide();
            }
        },

        /**
         * Show method
         *
         * @param {object} el - popup instance DOM node
         * @param {number} ordinal - order number of an `open` element
         */
        show: function (el, ordinal) {
            var $el = $(el);

            if ($el.data('popup-visible')) return;

            // Initialize if not initialized. Required for: $('#popup').popup('show')
            if (!$el.data('popup-initialized')) {
                methods._init(el);
            }
            $el.attr('data-popup-initialized', 'true');

            var $body = $('body');
            var options = $el.data('popupoptions');
            var $wrapper = $('#' + el.id + '_wrapper');
            var $background = $('#' + el.id + '_background');

            // `beforeopen` callback event
            callback(el, ordinal, options.beforeopen);

            // Remember last clicked place
            lastclicked[el.id] = ordinal;

            // Add popup id to popup stack
            setTimeout(function() {
                stack.push(el.id);
            }, 0);

            // Calculating maximum z-index
            if (options.autozindex) {

                var elements = document.getElementsByTagName('*');
                var len = elements.length;
                var maxzindex = 0;

                for(var i=0; i<len; i++){

                    var elementzindex = $(elements[i]).css('z-index');

                    if(elementzindex !== 'auto'){

                      elementzindex = parseInt(elementzindex, 10);

                      if(maxzindex < elementzindex){
                        maxzindex = elementzindex;
                      }
                    }
                }

                zindexvalues[el.id] = maxzindex;

                // Add z-index to the background
                if (options.background) {
                    if (zindexvalues[el.id] > 0) {
                        $('#' + el.id + '_background').css({
                            zIndex: (zindexvalues[el.id] + 1)
                        });
                    }
                }

                // Add z-index to the wrapper
                if (zindexvalues[el.id] > 0) {
                    $wrapper.css({
                        zIndex: (zindexvalues[el.id] + 2)
                    });
                }
            }

            if (options.detach) {
                $wrapper.prepend(el);
                $el.show();
            } else {
                $wrapper.show();
            }

            opentimer = setTimeout(function() {
                $wrapper.css({
                    visibility: 'visible',
                    opacity: 1
                });

                $('html').addClass('popup_visible').addClass('popup_visible_' + el.id);
                $wrapper.addClass('popup_wrapper_visible');
            }, 20); // 20ms required for opening animation to occur in FF

            // Disable background layer scrolling when popup is opened
            if (options.scrolllock) {
                $body.css('overflow', 'hidden');
                if ($body.height() > $window.height()) {
                    $body.css('margin-right', bodymarginright + scrollbarwidth);
                }
            }

            if(options.backgroundactive){
                //calculates the vertical align
                $el.css({
                    top:(
                        $window.height() - (
                            $el.get(0).offsetHeight +
                            parseInt($el.css('margin-top'), 10) +
                            parseInt($el.css('margin-bottom'), 10)
                        )
                    )/2 +'px'
                });
            }

            $el.css({
                'visibility': 'visible',
                'opacity': 1
            });

            // Show background
            if (options.background) {
                $background.css({
                    'visibility': 'visible',
                    'opacity': options.opacity
                });

                // Fix IE8 issue with background not appearing
                setTimeout(function() {
                    $background.css({
                        'opacity': options.opacity
                    });
                }, 0);
            }

            $el.data('popup-visible', true);

            // Position popup
            methods.reposition(el, ordinal);

            // Remember which element had focus before opening a popup
            $el.data('focusedelementbeforepopup', document.activeElement);

            // Handler: Keep focus inside dialog box
            if (options.keepfocus) {
                // Make holder div focusable
                $el.attr('tabindex', -1);

                // Focus popup or user specified element.
                // Initial timeout of 50ms is set to give some time to popup to show after clicking on
                // `open` element, and after animation is complete to prevent background scrolling.
                setTimeout(function() {
                    if (options.focuselement === 'closebutton') {
                        $('#' + el.id + ' .' + el.id + closesuffix + ':first').focus();
                    } else if (options.focuselement) {
                        $(options.focuselement).focus();
                    } else {
                        $el.focus();
                    }
                }, options.focusdelay);

            }

            // Hide main content from screen readers
            $(options.pagecontainer).attr('aria-hidden', true);

            // Reveal popup content to screen readers
            $el.attr('aria-hidden', false);

            callback(el, ordinal, options.onopen);

            if (transitionsupport) {
                $wrapper.one('transitionend', function() {
                    callback(el, ordinal, options.opentransitionend);
                });
            } else {
                callback(el, ordinal, options.opentransitionend);
            }
        },

        /**
         * Hide method
         *
         * @param {object} el - popup instance DOM node
         */
        hide: function (el) {
            if(opentimer) clearTimeout(opentimer);

            var $body = $('body');
            var $el = $(el);
            var options = $el.data('popupoptions');
            var $wrapper = $('#' + el.id + '_wrapper');
            var $background = $('#' + el.id + '_background');

            $el.data('popup-visible', false);


            if (stack.length === 1) {
                $('html').removeClass('popup_visible').removeClass('popup_visible_' + el.id);
            } else {
                if($('html').hasClass('popup_visible_' + el.id)) {
                    $('html').removeClass('popup_visible_' + el.id);
                }
            }

            // Remove last opened popup from the stack
            stack.pop();

            if($wrapper.hasClass('popup_wrapper_visible')) {
                $wrapper.removeClass('popup_wrapper_visible');
            }

            if (options.keepfocus) {
                // Focus back on saved element
                setTimeout(function() {
                    if ($($el.data('focusedelementbeforepopup')).is(':visible')) {
                        $el.data('focusedelementbeforepopup').focus();
                    }
                }, 0);
            }

            // Hide popup
            $wrapper.css({
                'visibility': 'hidden',
                'opacity': 0
            });
            $el.css({
                'visibility': 'hidden',
                'opacity': 0
            });

            // Hide background
            if (options.background) {
                $background.css({
                    'visibility': 'hidden',
                    'opacity': 0
                });
            }

            // Reveal main content to screen readers
            $(options.pagecontainer).attr('aria-hidden', false);

            // Hide popup content from screen readers
            $el.attr('aria-hidden', true);

            // `onclose` callback event
            callback(el, lastclicked[el.id], options.onclose);

            if (transitionsupport && $el.css('transition-duration') !== '0s') {
                $el.one('transitionend', function(e) {

                    if (!($el.data('popup-visible'))) {
                        if (options.detach) {
                            $el.hide().detach();
                        } else {
                            $wrapper.hide();
                        }
                    }

                    // Re-enable scrolling of background layer
                    if (options.scrolllock) {
                        setTimeout(function() {
                            $body.css({
                                overflow: 'visible',
                                'margin-right': bodymarginright
                            });
                        }, 10); // 10ms added for CSS transition in Firefox which doesn't like overflow:auto
                    }

                    callback(el, lastclicked[el.id], options.closetransitionend);
                });
            } else {
                if (options.detach) {
                    $el.hide().detach();
                } else {
                    $wrapper.hide();
                }

                // Re-enable scrolling of background layer
                if (options.scrolllock) {
                    setTimeout(function() {
                        $body.css({
                            overflow: 'visible',
                            'margin-right': bodymarginright
                        });
                    }, 10); // 10ms added for CSS transition in Firefox which doesn't like overflow:auto
                }

                callback(el, lastclicked[el.id], options.closetransitionend);
            }

        },

        /**
         * Toggle method
         *
         * @param {object} el - popup instance DOM node
         * @param {number} ordinal - order number of an `open` element
         */
        toggle: function (el, ordinal) {
            if ($(el).data('popup-visible')) {
                methods.hide(el);
            } else {
                setTimeout(function() {
                    methods.show(el, ordinal);
                }, 0);
            }
        },

        /**
         * Reposition method
         *
         * @param {object} el - popup instance DOM node
         * @param {number} ordinal - order number of an `open` element
         */
        reposition: function (el, ordinal) {
            var $el = $(el);
            var options = $el.data('popupoptions');
            var $wrapper = $('#' + el.id + '_wrapper');
            var $background = $('#' + el.id + '_background');

            ordinal = ordinal || 0;

            // Tooltip type
            if (options.type == 'tooltip') {
                $wrapper.css({
                    'position': 'absolute'
                });

                var $tooltipanchor;
                if (options.tooltipanchor) {
                    $tooltipanchor = $(options.tooltipanchor);
                } else if (options.openelement) {
                    $tooltipanchor = $(options.openelement).filter('[data-popup-ordinal="' + ordinal + '"]');
                } else {
                    $tooltipanchor = $('.' + el.id + opensuffix + '[data-popup-ordinal="' + ordinal + '"]');
                }

                var linkOffset = $tooltipanchor.offset();

                // Horizontal position for tooltip
                if (options.horizontal == 'right') {
                    $wrapper.css('left', linkOffset.left + $tooltipanchor.outerWidth() + options.offsetleft);
                } else if (options.horizontal == 'leftedge') {
                    $wrapper.css('left', linkOffset.left + $tooltipanchor.outerWidth() - $tooltipanchor.outerWidth() +  options.offsetleft);
                } else if (options.horizontal == 'left') {
                    $wrapper.css('right', $window.width() - linkOffset.left  - options.offsetleft);
                } else if (options.horizontal == 'rightedge') {
                    $wrapper.css('right', $window.width()  - linkOffset.left - $tooltipanchor.outerWidth() - options.offsetleft);
                } else {
                    $wrapper.css('left', linkOffset.left + ($tooltipanchor.outerWidth() / 2) - ($el.outerWidth() / 2) - parseFloat($el.css('marginLeft')) + options.offsetleft);
                }

                // Vertical position for tooltip
                if (options.vertical == 'bottom') {
                    $wrapper.css('top', linkOffset.top + $tooltipanchor.outerHeight() + options.offsettop);
                } else if (options.vertical == 'bottomedge') {
                    $wrapper.css('top', linkOffset.top + $tooltipanchor.outerHeight() - $el.outerHeight() + options.offsettop);
                } else if (options.vertical == 'top') {
                    $wrapper.css('bottom', $window.height() - linkOffset.top - options.offsettop);
                } else if (options.vertical == 'topedge') {
                    $wrapper.css('bottom', $window.height() - linkOffset.top - $el.outerHeight() - options.offsettop);
                } else {
                    $wrapper.css('top', linkOffset.top + ($tooltipanchor.outerHeight() / 2) - ($el.outerHeight() / 2) - parseFloat($el.css('marginTop')) + options.offsettop);
                }

            // Overlay type
            } else if (options.type == 'overlay') {

                // Horizontal position for overlay
                if (options.horizontal) {
                    $wrapper.css('text-align', options.horizontal);
                } else {
                    $wrapper.css('text-align', 'center');
                }

                // Vertical position for overlay
                if (options.vertical) {
                    $el.css('vertical-align', options.vertical);
                } else {
                    $el.css('vertical-align', 'middle');
                }
            }
        },

        /**
         * Add-close-button method
         *
         * @param {object} el - popup instance DOM node
         */
        addclosebutton: function (el) {
            var genericCloseButton;

            if ($(el).data('popupoptions').closebuttonmarkup) {
                genericCloseButton = $(options.closebuttonmarkup).addClass(el.id + '_close');
            } else {
                genericCloseButton = '<button class="popup_close ' + el.id + '_close" title="Close" aria-label="Close"><span aria-hidden="true">×</span></button>';
            }

            if ($el.data('popup-initialized')){
                $el.append(genericCloseButton);
            }

        }

    };

    /**
     * Callback event calls
     *
     * @param {object} el - popup instance DOM node
     * @param {number} ordinal - order number of an `open` element
     * @param {function} func - callback function
     */
    var callback = function (el, ordinal, func) {
        var options = $(el).data('popupoptions');
        var openelement =  (options.openelement) ? options.openelement : ('.' + el.id + opensuffix);
        var elementclicked = $(openelement + '[data-popup-ordinal="' + ordinal + '"]');
        if (typeof func == 'function') {
            func.call($(el), el, elementclicked);
        }
    };

    // Hide popup if ESC key is pressed
    $(document).on('keydown', function (event) {
        if(stack.length) {
            var elementId = stack[stack.length - 1];
            var el = document.getElementById(elementId);

            if ($(el).data('popupoptions').escape && event.keyCode == 27) {
                methods.hide(el);
            }
        }
    });

    // Hide popup on click
    $(document).on('click', function (event) {
        if(stack.length) {
            var elementId = stack[stack.length - 1];
            var el = document.getElementById(elementId);
            var closeButton = ($(el).data('popupoptions').closeelement) ? $(el).data('popupoptions').closeelement : ('.' + el.id + closesuffix);

            // Click on Close button
            if ($(event.target).closest(closeButton).length) {
                event.preventDefault();
                methods.hide(el);
            }

            // Click outside of popup
            if ($(el).data('popupoptions').blur && !$(event.target).closest('#' + elementId).length && event.which !== 2 && $(event.target).is(':visible')) {
                methods.hide(el);

                if ($(el).data('popupoptions').type === 'overlay') {
                    event.preventDefault(); // iOS will trigger click on the links below the overlay when clicked on the overlay if we don't prevent default action
                }
            }
        }
    });

    // Keep keyboard focus inside of popup
    $(document).on('focusin', function(event) {
        if(stack.length) {
            var elementId = stack[stack.length - 1];
            var el = document.getElementById(elementId);

            if ($(el).data('popupoptions').keepfocus) {
                if (!el.contains(event.target)) {
                    event.stopPropagation();
                    el.focus();
                }
            }
        }
    });

    /**
     * Plugin API
     */
    $.fn.popup = function (customoptions) {
        return this.each(function () {

            $el = $(this);

            if (typeof customoptions === 'object') {  // e.g. $('#popup').popup({'color':'blue'})
                var opt = $.extend({}, $.fn.popup.defaults, customoptions);
                $el.data('popupoptions', opt);
                options = $el.data('popupoptions');

                methods._init(this);

            } else if (typeof customoptions === 'string') { // e.g. $('#popup').popup('hide')
                if (!($el.data('popupoptions'))) {
                    $el.data('popupoptions', $.fn.popup.defaults);
                    options = $el.data('popupoptions');
                }

                methods[customoptions].call(this, this);

            } else { // e.g. $('#popup').popup()
                if (!($el.data('popupoptions'))) {
                    $el.data('popupoptions', $.fn.popup.defaults);
                    options = $el.data('popupoptions');
                }

                methods._init(this);

            }

        });
    };

    $.fn.popup.defaults = {
        type: 'overlay',
        autoopen: false,
        background: true,
        backgroundactive: false,
        color: 'black',
        opacity: '0.5',
        horizontal: 'center',
        vertical: 'middle',
        offsettop: 0,
        offsetleft: 0,
        escape: true,
        blur: true,
        setzindex: true,
        autozindex: false,
        scrolllock: false,
        closebutton: false,
        closebuttonmarkup: null,
        keepfocus: true,
        focuselement: null,
        focusdelay: 50,
        outline: false,
        pagecontainer: null,
        detach: false,
        openelement: null,
        closeelement: null,
        transition: null,
        tooltipanchor: null,
        beforeopen: null,
        onclose: null,
        onopen: null,
        opentransitionend: null,
        closetransitionend: null
    };

})(jQuery);
;
(function ($) {

    $(function () {
        {
            var formElement = $('div.scfForm');

            if (formElement.length > 0) {
                var copyAddress = $(".disableBox input");
                // Load form elements to be copied
                var PAddress = jQuery(".custom_wffm_billing").find("label:contains('Address')").next().find("input:text"),
                    PCity = jQuery(".custom_wffm_billing").find("label:contains('City')").next().find("input:text"),
                    PState = jQuery(".custom_wffm_billing").find("label:contains('State')").next().find("select"),
                    PZipCode = jQuery(".custom_wffm_billing").find("label:contains('Zip Code')").next().find("input:text"),
                    enableCopyCheck = function () {
                        var complete = true;
                        console.log(PState.find(":selected").val());
                        switch (true) {
                            case PAddress.val() === "": complete = false;
                            case PCity.val() === "": complete = false;
                            case PState.find(":selected").val() === "": complete = false;
                            case PZipCode.val() === "": complete = false;
                        }
                        if (complete) copyAddress.prop("disabled", false);
                        else copyAddress.prop("disabled", true)
                    },
                    updateBillingAddress = function () {
                        // Set Copy Values Values
                        var addressSource = PAddress.val() || false,
                            citySource = PCity.val() || false,
                            stateSource = PState.find(":selected").val() || false,
                            zipcodeSource = PZipCode.val() || false;

                        // Load form elements to copy into
                        var BAddress = jQuery("label:contains('Billing Address')").next().find("input:text"),
                            BCity = jQuery("label:contains('Billing City')").next().find("input:text"),
                            BState = jQuery("label:contains('Billing State')").next().find("select"),
                            BZipCode = jQuery("label:contains('Billing Zip Code')").next().find("input:text");

                        // Perform action based on copyAddress check status
                        if (copyAddress.is(':checked')) {
                            // Checked: copy patient address to billing address 
                            BAddress.val(PAddress.val()).attr("readonly", true).toggleClass('disable');
                            BCity.val(PCity.val()).attr("readonly", true).toggleClass('disable');
                            BState.val(PState.find(":selected").val()).attr("readonly", true).trigger("change").toggleClass('disable');
                            BZipCode.val(PZipCode.val()).attr("readonly", true).toggleClass('disable');
                        } else {
                            // Unchecked: clear info from billing address
                            BAddress.attr("readonly", false).toggleClass('disable');
                            BCity.attr("readonly", false).toggleClass('disable');
                            BState.attr("readonly", false).toggleClass('disable');
                            BZipCode.attr("readonly", false).toggleClass('disable');
                        }
                    };


                // Initially disable Address Copy Checkbox
                enableCopyCheck();

                // Watch for changes to address elements and enable/disbale copy button as required
                PAddress.on("change blur", enableCopyCheck);
                PCity.on("change blur", enableCopyCheck);
                PState.on("change blur", enableCopyCheck);
                PZipCode.on("change blur", enableCopyCheck);

                // Check if box is already on, if so trigger change event
                if (copyAddress.is(':checked')) updateBillingAddress;

                // copyAddress checkbox event handler
                copyAddress.on("change", updateBillingAddress);
            }
            // End of form Check
        }

    });

})(jQuery);
;
